#include<iostream>
using namespace std;

class student{
  private:
         string name,name1;
         int id;
  
  public:
        void getdata(){
            id=12000776;
             cout<<"enter the name \n";
              cin>>name;
              id++;
        };
       void display(){
        cout<<"your name is "<<name<<endl;
        cout<<"your id is "<<id<<endl;
       }
       
    
};




int main(){
    int n;
    cout<<"enter the number of student for which you want to generate the user id\n";
    cin>>n;
    student s1[n];
    
    for (int i = 0; i < n; i++ ){
        s1[i].getdata();
        s1[i].display();
    }

     
    
    
}