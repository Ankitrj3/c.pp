#include<iostream>
using namespace std;

int main(){
    int n;
    cout<<"enter the size of array\n";
    cin>>n;
    
    int arr[n];
    
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<"array before deletion\n";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    
    cout<<"enter the position in which u need to perform deletion\n";
    int d;
    cin>>d;
    
    for(int i=d;i<n;i++){
        arr[i]=arr[i+1];
    }
    n--;
    cout<<"array after deletion\n";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    
    return 0;
}