#include<iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int m;
    cin>>m;
    
    int arr[n][m];
    cout<<"enter the value in matrix\n";
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cin>>arr[i][j];
        }
    }
    cout<<"matrix before transpose\n";
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cout<<arr[i][j]<<" ";
        }
    }cout<<endl;
    cout<<"matrix after transpose\n";
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cout<<arr[j][i]<<" ";
        }
    }cout<<endl;
 bool a=true;
    for(int i=0;i<n;i++){
        for(int j=0; j<m; j++){
            if(arr[i][j]!=arr[j][i]){
               
               a=false; 
                break;
            }
        }
        // if(!a){
        //     break;
        // }
    }
   if(a){
    cout<<"it symetric\n";
   }else{
    cout<<"not symetric\n";
   }
    return 0;
}