#include<iostream>
using namespace std;

struct node{
    int data;
    node *left;
    node *right;
    node(int value){
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

void insert(node* &root,int value){
    if(root==nullptr){
        root = new node(value);
        return;
    }    
    if(value<root->data){
        insert(root->left,value);
    }else{
        insert(root->right,value);
    }
}
void inorder(node* &root){
    if(root!=nullptr){
        inorder(root->left);
        cout<<root->data<<" ";
        inorder(root->right);
        
    }
}

int main(){
    int n;
    
    cin>>n;
    
    node *root = nullptr;
    int value;
    for(int i=0; i<n; i++){
        cin>>value;
        insert(root,value);
    }
    inorder(root);
    return 0;
}