// You are using GCC
#include<iostream>
using namespace std;

struct node{
    int data;
    node *next;
};
node *head = nullptr;
node *temp = nullptr;

void ilast(){
    node *newnode = new node();
    cin>>newnode->data;
    
    if(head == nullptr){
        head = temp = nullptr;
    }else{
        temp -> next = newnode;
        temp = newnode;
    }
}
void display(){
   node *temp = head;
    while(temp!=nullptr){
        cout<<temp->data;
        temp = temp->next;
    }
}

int main(){
    
    while(1){
        int n;
        cin>>n;
        if(n==-1){
            break;
        }else{
            ilast();
        }
    }
    display();
    
    return 0;
}