#include<iostream>
using namespace std;

int main(){
    
    int n;
    cin>>n;
    int arr[n];
    
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
int pro = 1;
bool a=true;
    for(int i=0;i<n;i++){
        if(arr[i]%2==0){
            pro*=arr[i];
            a=false;
        }
    }
    if(a==false){
    cout<<"product is "<<pro;
    }else{
        cout<<"invalid\n";
    }
    return 0;
}