#include<iostream>
using namespace std;

class rect{
    int l;
    int b;
    public:
    void getdata(){
        cin>>l>>b;
    }
    int compare(rect t){
        if(this->l==t.l&&this->b==t.b){
            return 1;
        }else{
            return 0;
        }
    }
};


int main(){
   
   rect ob,ob1;
  ob.getdata();
  ob1.getdata();
   int t = ob.compare(ob1);
   if(t==1){
    cout<<"same";
   }else{
    cout<<"not same";
   }
    return 0;
}