#include<iostream>
using namespace std;

int main(){
    
    int n;
    cout<<"insert the size of array";
    cin>>n;
    
    int arr[n];
    cout<<"insert the element in the array\n";
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    
    int pos;
    int element;
    cout<<"enter the element \n";
    cin>>element;
    cout<<"enter the position\n";
    cin>>pos;
    n++;
    for(int i=n; i>pos; i--){
        arr[i]=arr[i-1];
    }
    arr[pos] = element;
    
    cout<<"array after the insertion \n";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}
