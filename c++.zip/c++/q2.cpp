// Single File Programming Question

// Problem Statement




// Kumar is studying data structures and is currently learning about Binary Search Trees (BST). He wants to implement the operations of creating and displaying a Binary Search Tree.




// Write a program that takes a sequence of positive integers as input and constructs a Binary Search Tree using these integers. After constructing the BST, the program should display the nodes of the BST in ascending order.

// Input format :

// The input consists of a series of positive integers greater than zero, separated by a space.

// The input ends when -1 is entered.

// The integers represent the elements to be inserted into the binary search tree.

// Output format :

// The output displays the elements of the binary search tree in ascending order (sorted order), separated by space.




// Refer to the sample output for the formatting specifications.

// Code constraints :

// The input integers > 0.

// The number of elements in the binary search tree will be at most 100.

// Sample test cases :
// Input 1 :
// 1
// 2
// 3
// 4
// 5
// -1
// Output 1 :
// 1 2 3 4 5 
// Input 2 :
// 7
// 6
// 4
// 5
// 3
// -1
// Output 2 :
// 3 4 5 6 7 
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case. Single File Programming Question

// Problem Statement




// Gayu is studying data structures, and she wants to implement a program that performs various operations on a Binary Search Tree (BST).




// Gayu to create a Binary Search Tree (BST) and perform the following operations:




// Create BST: Gayu can create a BST by providing the number of nodes (n) and a list of n integer values. The program constructs the BST using these values.
// Print Postorder: Gayu can print the elements of the BST in postorder traversal, which means that the program will display the values in the left subtree, then the right subtree, and finally the root of each subtree.
// Exit: Gayu can exit the program.
// Input format :

// The first input consists of the choice.

// If the choice is 1, enter the number of elements (n) and the space-separated elements (i) to be inserted into the tree.

// If the choice is 2, print the post-order traversal.

// If the choice is 3, exit.

// If the choice is greater than 3, print "Wrong choice".

// (By default, all the test cases have all the choices from 1–3, but the n and i values keep changing.)




// Refer to the sample input for a better understanding.

// Output format :

// The first line of output consists of the following format:

// "BST with %d nodes is ready to use!\n", where %d is the number of nodes in the BST.

// The second line of output consists of the following format:

// "BST Traversal in POSTORDER\n"

// The third line of output consists of the following format:

// A space-separated list of integers representing the elements of the BST in postorder traversal.

// The fourth line of output consists of the following format:

// If input an invalid choice (other than 1, 2, or 3),

// "Wrong choice\n"




// Refer to the sample output for a better understanding.

// Code constraints :

// The BST can have duplicate elements.

// The maximum number of nodes (n) is 15.

// The integer values can be in the range of 1 to 102.

// Sample test cases :
// Input 1 :
// 1
// 5
// 12 78 96 34 55
// 2
// 3
// Output 1 :
// BST with 5 nodes is ready to use!
// BST Traversal in POSTORDER
// 55 34 96 78 12 

// Input 2 :
// 1
// 9
// 7 9 6 3 2 1 4 5 8
// 2
// 5
// 3
// Output 2 :
// BST with 9 nodes is ready to use!
// BST Traversal in POSTORDER
// 1 2 5 4 3 6 8 9 7 
// Wrong choice

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.


#include<iostream>
using namespace std;

struct node{
    int data;
    node * left;
    node * right;
    
    node(int value){
        data=value;
        left = nullptr;
        right = nullptr;
    }
};
struct node *head = nullptr;

void insert(node* &root, int value){
    if(root==nullptr){
        root = new node(value);
        return ;
    }
    if(value<root->data){
        insert(root->left,value);
    }else{
        insert(root->right,value);
    }
}
void post(node* &root){
    if(root!=nullptr){
        post(root->left);
        post(root->right);
        cout<<root->data<<" ";
    }
}

int main(){
    int n;
    int j;
    int value;
    struct node * root = nullptr;
    while(1){
        cin>>n;
        switch(n){
            case 1:
            cin>>j;
            cout<<"BST with "<< j<<" nodes is ready to use!\n";
            for(int i=0;i<j;i++){
                cin>>value;
                insert(root,value);
            }cout<<endl;
            break;
            case 2:
            cout<<"BST Traversal in POSTORDER\n";
            post(root);
            cout<<endl;
            break;
            case 3:
            return 0;
            break;
            
            default:
            cout<<"Wrong choice\n";
            break;
            
        }
    }
    return 0;
}