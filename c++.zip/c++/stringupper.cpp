#include<iostream>
#include<string>
#include<cctype>
using namespace std;

int main(){
    string s1;
    getline(cin,s1);
    
    for(int i=0; i<s1.length(); i++){
    s1[0] = toupper(s1[0]);}
    
    cout<<s1;
    
    return 0;
}