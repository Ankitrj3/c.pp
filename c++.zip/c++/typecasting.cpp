#include<iostream>
using namespace std;

int main(){
float k=24.34;
 int a=112;
 cout<<(int)k<<endl;
 cout<<(float)a/9;}