// #include<bits/stdc++.h>
// using namespace std;

// int main(){
//     float rj=12.23;
//     void *ank;
//     ank = &rj;
    
//     cout<<*(float*)ank;
// }

#include<bits/stdc++.h>
using namespace std;

int main(){
    //the addresss which we can not changed
    int k = 12;
    int * const p= &k;
    cout<<*p;
    
    
    
    return 0;
}