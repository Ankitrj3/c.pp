#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};
struct node *  head = NULL;
struct node *  temp = NULL;

void reverseLinkedList() {
    struct node* current = head;
    struct node* prev = NULL;
    struct node* next = NULL;

    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    head = prev; 
}

int main(){
    int n;
    cin>>n;

    for(int i=0; i<n; i++){
        struct node * newnode = new node();
        cin>>newnode->data;

        if(head == NULL){
            head = temp = newnode;
        }
        else{
            temp->next=newnode;
            temp=newnode;
        }
    }

    reverseLinkedList();
    temp=head;
    int pos=2 , i=1;
    struct node * newnode = new node();
    cin>>newnode->data;
    while(i<pos-1){
        temp=temp->next;
        i++;
    }
    newnode->next=temp->next;
    temp->next=newnode;
    

    temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
        
    }
    

    return 0;
}