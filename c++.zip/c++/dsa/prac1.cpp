//merging array
// sorting that array
// spliting the array again at original form

// You are using GCC
#include<iostream>
using namespace std;

int main(){
    int z;
    cin>>z;
    int arr[z];
    for(int i=0; i<z; i++){
        cin>>arr[i];
    }
    
    int m;
    cin>>m;
    int arr1[m];
    for(int i=0; i<m; i++){
        cin>>arr1[i];
    }
    
    int s=z+m;
    
    int arr2[s];
    
    for(int i=0; i<z; i++){
        arr2[i]=arr[i];
    }
    for(int i=0; i<m; i++){
        arr2[z+i]=arr1[i];
    }
    
    //sorting the array
    
    for(int i=0; i<s-1; i++){
        for(int j=i+1; j<s; j++){
            if(arr2[j]<arr2[i]){
                int temp=arr2[j];
                arr2[j]=arr2[i];
                arr2[i]=temp;
            }
        }
    }
    
    
    for(int i=0; i<z; i++){
        cout<<arr2[i]<<" ";
    }
    cout<<endl;
    for(int i=z; i<s; i++){
        cout<<arr2[i]<<" ";
    }
    return 0;
}