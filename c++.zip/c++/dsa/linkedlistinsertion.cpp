
#include<iostream>
using namespace std;

class node{
public:
    int val;
    node* next;
    
    node(int data){ //constructor to asign the value
        val = data;
        next = NULL;
    }
};
//insertation in head;
void insertAtHead(node* &head, int val){
    
    node* newnode = new node(val);
    newnode->next = head;
    head = newnode;
    
}

//insertion in tail
void insertAtTail(node* &head ,int val){
    node *newnode = new node(val);
    
    node* temp = head;
    while(temp->next !=NULL){
        temp = temp ->next;
    }
    //temp reached to last node
    temp->next=newnode;
}

void display(node *head){
    
    node *temp = head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp = temp->next;
    }
    cout<<"NULL"<<endl;
}

int main(){
    
    node *head = NULL;
    insertAtHead(head,2);
    display(head);
    insertAtHead(head,20);
    display(head);

    insertAtTail(head,3);
    display(head);
   
}

