#include<iostream>
using namespace std;

void swap(int *x, int *y){
    int temp = *x;
    *x=*y;
    *y=temp;
    cout<<*x<<*y<<endl;
}

int main(){
    int a , b;
    cout<<"enter a and b\n";
    cin>>a>>b;
    cout<<"before swapping "<<endl;
    cout<<a<<" "<<b<<endl;
    
    cout<<"after swapping "<<endl;
    swap(&a, &b);
    cout<<a<< " "<<b;
    return 0;
}