#include<iostream>
using namespace std;
int main(){
    int a;
    cin>>a;
    int b;
    cin>>b;
    int *x,*y;
    x=&a;
    y=&b;
    x=y;//value y is going to copy in x pointer
    // cout<<*x<<endl;
    // cout<<*y<<endl;
    int sum = *x + *y;
    cout<<sum;
    return 0;
}