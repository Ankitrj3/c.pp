#include <iostream>
using namespace std;

const int MAX_ROWS = 100;
const int MAX_COLS = 100;

int main() {
    int a, b;
    cin >> a >> b;

    if (a <= 0 || a > MAX_ROWS || b <= 0 || b > MAX_COLS) {
        cout << "Invalid matrix size." << endl;
        return 1;
    }

    int arr[MAX_ROWS][MAX_COLS];


    for (int i = 1; i <= a; i++) {
        for (int j = 1; j <= b; j++) {
            cin >> arr[i][j];
        }
    }

    int row1, row2;
    cin >> row1 >> row2;

    if (row1 < 1 || row1 > a || row2 < 1 || row2 > a) {
        cout << "Invalid row numbers." << endl;
        return 1;
    }

    
    int temp[MAX_COLS];
    for (int i = 1; i <= b; i++) {
        temp[i] = arr[row1][i];
        arr[row1][i] = arr[row2][i];
        arr[row2][i] = temp[i];
    }

    
    for (int i = 1; i <= a; i++) {
        for (int j = 1; j <= b; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
