#include <iostream>
#include <string>
using namespace std;

// Function to perform selection sort
void selectionSort(string arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        swap(arr[i], arr[minIndex]);
    }
}

int main() {
    int numStudents;
    cout << "Enter the number of students: ";
    cin >> numStudents;

    cin.ignore(); // Clear newline from previous input

    string studentNames[numStudents];
    
    // Input student names
    for (int i = 0; i < numStudents; i++) {
        cout << "Enter name of student " << i + 1 << ": ";
        getline(cin, studentNames[i]);
    }

    // Perform selection sort
    for (int i = 0; i < numStudents - 1; i++) {
        selectionSort(studentNames, numStudents);
        
        cout << "After iteration " << i + 1 << ": ";
        for (int j = 0; j < numStudents; j++) {
            cout << studentNames[j] << " ";
        }
        cout << endl;
    }

    cout << "Sorted student names: ";
    for (int i = 0; i < numStudents; i++) {
        cout << studentNames[i] << " ";
    }
    cout << endl;

    return 0;
}
