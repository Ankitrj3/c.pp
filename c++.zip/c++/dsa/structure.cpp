#include<iostream>
using namespace std;

    // structure is a public access
    // structure can define different datatypes

    struct emp{
        string name;
        int age;
        float sal;
    };

    int main(){
        emp e1;
        cout<<"enter full name\n";
        cin>>e1.name;
        cout<<"enter age\n";
        cin>>e1.age;
        cout<<"enter salary\n";
        cin>>e1.sal;
        cout<<"displaying the information\n";
        cout<<"name"<<e1.name<<endl;
        cout<<"age"<<e1.age<<endl;
        cout<<"salary"<<e1.sal<<endl;

        return 0;
    


}