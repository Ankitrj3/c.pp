// You are using GCC
#include<iostream>
using namespace std;
unsigned long long fibonacci(int num);
int main(){
    
    int n;
    cin>>n;
    
    int a=0;
    int b=1;
    int c;
    for(int i=1; i<n; i++){
        c=a+b;
        a=b;
        b=c;
       
    }
    cout<<b;
    return 0;
}