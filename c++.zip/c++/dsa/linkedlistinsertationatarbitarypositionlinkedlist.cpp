#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    
    node(int data) { //constructor to assign the value
        val = data;
        next = NULL;
    }
};

//insertion at head
void insertAtHead(node* &head, int val) {
    node* newnode = new node(val);
    newnode->next = head;
    head = newnode;
}

//insertion at tail
void insertAtTail(node* &head, int val) {
    node* newnode = new node(val);
    
    node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    //temp reached the last node
    temp->next = newnode;
}

//insertion at a specific position
void insertAtPosition(node* &head, int val, int pos) {
    if (pos == 0) {
        insertAtHead(head, val);
        return;
    }
    
    node* newnode = new node(val);
    node* temp = head;
    int currentpos = 0;
    while (currentpos < pos - 1 && temp != NULL) {
        temp = temp->next;
        currentpos++;
    }
    
    if (temp == NULL) {
        cout << "Invalid position\n";
        return;
    }
    
    //temp is pointing to the node at pos - 1
    newnode->next = temp->next;
    temp->next = newnode;
}

void display(node* head) {
    node* temp = head;
    while (temp != NULL) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main() {
    node* head = NULL;
    
    insertAtHead(head, 2);
    display(head);
    
    insertAtHead(head, 20);
    display(head);

    insertAtTail(head, 3);
    display(head);

    insertAtPosition(head, 50, 1);
    display(head);

    return 0;
}
