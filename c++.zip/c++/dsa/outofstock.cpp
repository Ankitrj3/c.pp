// You are using GCC
#include<iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    
    int arr[n];
    
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    
    cout<<"Removing out-of-stock products\n";
    int nonzero = 0;
    for(int i=0; i<n; i++){
        if(arr[i]!=0){
            arr[nonzero]=arr[i];
            nonzero++;
        }
    }
    n=nonzero;
    cout<<"Updated array of product IDs:";
    for(int i=0; i<n; i++){
        cout<<arr[i]<<" "; 
    }
}