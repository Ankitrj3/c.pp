#include<iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    cout<<"Reserved Tickets:";
    for(int i=0; i<n; i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
    int element;
    cin>>element;
    
   int foundindex=-1;
    for(int i=0; i<n; i++){

        if(arr[i]==element){
            foundindex=i;
            break;
        }
    }
    
    if(foundindex != -1){
        for(int i=foundindex; i<n-1; i++){
            arr[i]=arr[i+1];
        }
        n--;
        cout<<"Ticket with ID "<<element<<" has been canceled."<<endl;
        cout<<"Reserved Tickets:";
        for(int i=0; i<n; i++){
            cout<<arr[i]<<" ";
        }cout<<endl;
        
    }else{
        cout<<"Ticket with ID "<<element<<" not found in the reservation."<<endl;
        cout<<"Reserved Tickets:";
        for(int i=0; i<n; i++){
            cout<<arr[i]<<" ";
            
        }cout<<endl;
    }
    return 0;
}