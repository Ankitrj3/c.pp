// // referance variable declaration

// #include<iostream>
// using namespace std;

// int main(){
    
//     int a;
//     cin>>a;
//     int &b=a;
//     int &c=b;
//     cout<<"a "<<a<<endl;
//     cout<<"b "<<b<<endl;
//     cin>>c;
    
//     cout<<"a "<<a<<endl;
//     cout<<"b "<<b<<endl;

//     cout<<"c "<<c<<endl;
//     return 0;
// }

#include<iostream>
using namespace std;

void swap(int &x,int &y){
    int temp = x;
    x = y;
    y = temp;
}

int main(){

    int a,b;
    cin>>a>>b;
    cout<<"before swaping the number"<<endl;
    cout<<"a "<<a<<" "<<"b "<<b<<endl;
    swap(a,b);
    cout<<"after swaping the number:"<<endl;
    cout<<"a "<<a<<" "<<"b "<<b;
    return 0;
}