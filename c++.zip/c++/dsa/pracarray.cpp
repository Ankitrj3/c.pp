#include<iostream>
using namespace std;

int main(){

    int arr[]={12,34,12,342,3212,34,23212,242}; 
    
    for(int i=0; i<8; i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}