#include<iostream>//it mean input and output from keyboard and display
using namespace std;

int main(){
   /* 
    int arr[4];
    for(int i ; i<4 ; i++){
        cout<<"enter the marks of "<<i<<"th"<<endl;
        cin>>arr[i];
    }
    for(int i;i<4;i++){
        cout<<"your entered marks are"<<arr[i]<<"marks "<<i<<"th student"<<endl ;
    }*/

    int k;
    cout<<"enter the size of the array ";
    cin>>k;
    int arr[k];
    for(int i =0; i<k; i++){
        cin>>arr[i];
    }cout<<endl;
    cout<<"printing the value of array"<<endl;
    for(int i =0; i<k; i++){
        cout<<arr[i]<<endl;
    }cout<<endl;
    return 0;

}