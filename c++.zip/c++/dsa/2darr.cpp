#include<iostream>
using namespace std;

int main(){
    int arr[2][2]={{2,3},{23,45}};

    for(int i = 0; i<2; i++){
        for(int j = 0; j<2; j++){
            cout<<"the matrix is "<<arr[i][j];
        
        }
        cout<<endl;
    }
    

     
}