#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};
struct node *head=NULL;
struct node *tail=NULL;

int main(){
    int choice;
    cout<<"enter the choice\n";
    cin>>choice;
    
    while(choice){
        struct node * newnode = new node();
        cout<<"enter the data\n";
        cin>>newnode->data;
        
        if(head==NULL){
            head = tail = newnode;
        }else{
            tail ->next=newnode;
            tail = newnode;
        }
       tail->next=head;
        cout<<"enter the choice\n";
        cin>>choice;
    }
    struct node *temp = head;
    
    while( temp->next!=head){
        cout<<temp->data<<" ";
        temp = temp->next;
    }
    if(temp!=NULL){
        cout<<temp->data;
    }
    
    return 0;
}