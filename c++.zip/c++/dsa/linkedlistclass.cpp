// #include<iostream>
// using namespace std;

// class node{
// public:
//     int val;
//     node* next;
    
//     node(int data){ //constructor to asign the value
//         val = data;
//         next = NULL;
//     }
// };

// int main(){
    
//     node* n= new node(1);
//     cout<<n->val<<" "<<n->next<<endl;
// }


#include<iostream>
using namespace std;

class node{
public:
    int val;
    node* next;
    
    node(int data){ //constructor to asign the value
        val = data;
        next = NULL;
    }
};

void insertAtHead(node* &head, int val){
    
    node* newnode = new node(val);
    newnode->next = head;
    head = newnode;
    
}

void display(node *head){
    
    node *temp = head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp = temp->next;
    }
    cout<<"NULL"<<endl;
}

int main(){
    
    node *head = NULL;
    insertAtHead(head,2);
    display(head);
    insertAtHead(head,20);
    display(head);
   
}

