#include<iostream>
using namespace std;

struct node{
   int data;
   struct node *next;
};
struct node *head=NULL;
struct node *temp=NULL;

int main(){
    struct node *one = new node();
    struct node *two = new node();
    struct node *three = new node();

    head = one;
    one -> next = two;
    two -> next = three;
    three -> next = NULL;

    one -> data = 12;
    two -> data = 34;
    three -> data = 231;

    temp = head;

    while(temp!=NULL){
        cout<<temp -> data<<" ";
        temp=temp -> next;
    }
}