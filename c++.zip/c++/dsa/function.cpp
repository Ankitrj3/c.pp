#include<iostream>
using namespace std;


//functions in cpp


int sum(int a, int b){//this formal parameters 
// int sum(int , int);//this is acceptable
   int c = a+b;
   return c;
}
void g();//declare the function

int main(){

   int num1,num2;

   cout<<"enter the num1"<<endl;
   cin>>num1;

// num1 and num2 are actual parameters

   cout<<"enter the num2"<<endl;
   cin>>num2;
    
   cout<<"the sum of two number is "<<sum(num1,num2)<<endl;//calling the funtion// function prototype // type function name (arguments);
    
   g();//calling the funtion 


   return 0;//it mean your program has been successfully run
}

void g(){//defining the function
    cout<<"hello anlkit\n";
}