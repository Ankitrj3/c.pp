#include <iostream>
using namespace std;

int binarysearch(int arr[], int a, int key) {
    int start = 0;
    int end = a - 1;

    while (start <= end) {
        int mid = (start + end) / 2;

        if (arr[mid] == key) {
            return mid;
        } else if (arr[mid] < key) {
            start = mid + 1;  // Update the start index
        } else {
            end = mid - 1;    // Update the end index
        }
    }
    return -1;
}

int main() {
    int a, key, result;
    cout << "Enter the size of the array: ";
    cin >> a;
    int arr[a];
    cout << "Enter the values in ascending order:\n";
    for (int i = 0; i < a; i++) {
        cin >> arr[i];
    }

    cout << "Enter the element you want to search: ";
    cin >> key;

    result = binarysearch(arr, a, key);

    if (result != -1) {
        cout << "Element found at index: " << result << endl;
    } else {
        cout << "Element is not present in the array." << endl;
    }

    return 0;
}
