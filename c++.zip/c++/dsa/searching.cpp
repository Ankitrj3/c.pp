#include<iostream>
using namespace std;
int main(){
    int arr[]={12,45,23,78,89,90,34};
    int size;
    size=sizeof(arr)/sizeof(arr[0]);

    int element,i;
    bool a=false;
    cout<<"the array is\n";
    for(i=0; i<size; i++){
        cout<<arr[i]<<endl;    }
    cout<<"from the array enter the index number to find search the element \n";
    cin>>element;
    for(i=0; i<size; i++){
        if(arr[i]==element){
            cout<<"element found at  "<<" "<<i<<" "<<"this index number\n";
            a=true;
            break;
        }
    }
    if(a==false){
        cout<<"Invalid\n";
    }
    return 0;
}