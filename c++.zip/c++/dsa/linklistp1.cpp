// #include<iostream>
// using namespace std;

// struct node{
//     int data;
//     struct node *next;
// };
//     struct node *head = NULL;
//     struct node *temp = NULL;


// int main(){
//     struct node *num1 = new node();
//     struct node *num2 = new node();
//     struct node *num3 = new node();
//     struct node *num4 = new node();

//     head = num1;
//     num1->next=num2;
//     num2->next=num3;
//     num3->next=num4;
//     num4->next=NULL;  

//     num1->data=12;
//     num2->data=13;
//     num3->data=14;
//     num4->data=15;
    
//     temp = head;

//     while(temp != NULL){
//         cout<<temp->data<<" ";
//         temp=temp->next;
//         cout<<temp;
//     }
//     return 0;
// }


#include<iostream>
using namespace std;

struct node{
  int data;
  struct node *next;
};

struct node *temp=NULL;
struct node *head=NULL;

int main(){
    int choice ;
    cout<<"enter the choice 1/0\n";
    cin>>choice;
    
    while(choice){
        struct node *newnode = new node();
        cout<<"enter the data\n";
        cin>>newnode->data;
        if(head == NULL){
            head = newnode;
            temp = newnode;
        }else{
            temp->next=newnode;
            temp=newnode;
        }
    }
    
    temp = head;
    while(temp!=NULL){
        cout<<temp->data;
        temp=temp->next;
    }
}