#include<iostream>
using namespace std;

int main(){
    int arr[]={12,34,23,12,23};
    int size,pos,i;
    size=sizeof(arr)/sizeof(arr[0]);
    cout<<"the size of aaray is\n"
    cout<<size<<endl;
    cout<<"previous array is\n";
    for(i=0; i<size; i++){
        cout<<arr[i]<<endl;
    }
    cout<<"enter the index to delete the value\n";
    cin>>pos;
    for (i=pos; i<size; i++){
        arr[i]=arr[i+1];
    }
    size--;
    cout<<"the new array after deletation\n";
    for(i=0; i<size; i++){
        cout<<arr[i]<<endl;
    }
}