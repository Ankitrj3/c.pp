#include<iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = NULL;
    }
};

void insertAtTail(Node* &head, int val) {
    Node* newnode = new Node(val);

    if (head == NULL) {
        head = newnode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newnode;
}

void display(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

void deleteAtHead(Node* &head) {
    if (head == NULL) {
        return;
    }
    Node* toDelete = head;
    head = head->next;
    delete toDelete;
}

void deleteAtPosition(Node* &head, int pos) {
    if (head == NULL) {
        return;
    }
    if (pos == 0) {
        deleteAtHead(head);
        return;
    }
    Node* temp = head;
    for (int i = 0; i < pos - 1 && temp != NULL; i++) {
        temp = temp->next;
    }
    if (temp == NULL || temp->next == NULL) {
        return;
    }
    Node* toDelete = temp->next;
    temp->next = temp->next->next;
    delete toDelete;
}

int main() {
    Node* head = NULL;
    insertAtTail(head, 2);
    insertAtTail(head, 20);
    insertAtTail(head, 3);
    insertAtTail(head, 30);

    cout << "Original linked list: ";
    display(head);

    deleteAtHead(head);
    cout << "Linked list after deleting at head: ";
    display(head);

    deleteAtPosition(head, 1);
    cout << "Linked list after deleting at position 1: ";
    display(head);

    return 0;

}
