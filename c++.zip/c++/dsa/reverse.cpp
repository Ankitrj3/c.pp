// You are using GCC
#include<iostream>
using namespace std;
void reverseNumber(int &a){
    int reverse =0;
    while(a>0){
        int d=a%10;
        reverse = reverse*10+d;
        a/=10;
    }
        cout<<reverse;
}
int main(){
    
    int a;
    cin>>a;
    reverseNumber(a);
}