#include<iostream>
using namespace std;
int main(){
//     int k;
//     cout<<"enter the size of array"<<endl;
//     cin>>k;
//     int jk[k];
//     for (int i =1; i<=k; i++){
//         cin>>jk[i];
//     }
    
//    for (int i =1; i<=k; i++){
//     if(jk[i]>25){
//         cout<<"the number is more than 25 in array"<<endl;
//     }else{
//         cout<<jk[i]<<endl;
//     }}


// int jk[4]={1,2,3,4};
//     int count = sizeof(jk)/sizeof(jk[0]);//amount of element in the array
//     cout<<count<<endl;
//     int size=sizeof(jk);//it will return the size of array
//     cout<<size<<endl;


// int arr[7]={12,34,5,6,7,23,26};
// int sum=0;
// for (int i=0 ; i<=7; i++){
//     if(arr[i]>9){
//         sum = sum + arr[i];
//     }
// }
// cout<<"the sum of array is "<<sum;




//insertion operation in array


// int arr[100],i/*loop*/,count/*size*/;
// cout<<"enter the size of element in array"<<endl;
// cin>>count;

// cout<<"enter the elements of the array"<<endl;

// for(i=0; i<=count ; i++){
//     cin>>arr[i];    
// }

// cout<<"printing the previous value"<<endl;
// for(i=0; i<count; i++){
//     cout<<arr[i]<<endl;
// }
// //main logic of insertion
int index =2;
count++;
for(i=count; i>index; i--){
    arr[i]=arr[i-1];
}
arr[index]=12;

cout<<"after insertion"<<endl;
for(i=0; i<=count; i++){

    cout<<arr[i]<<endl;
}


  return 0;

}