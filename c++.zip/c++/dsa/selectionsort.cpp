#include<iostream>
using namespace std;

int main(){
    int n;
    cout<<"enter the size of array\n";
    cin>>n;
    int arr[n];
    cout<<"enter the values\n";
    for(int i=1; i<n; i++){
        cin>>arr[i];
    }cout<<endl;

    cout<<"printing the unsorted array\n";
    for(int i=1; i<n; i++){
        cout<<arr[i]<<" ";
    }cout<<endl;

    for(int i =0 ; i<n-1; i++){
        for(int j=i+1; j<n; j++){
            if(arr[j]<arr[i]){
            int temp=arr[j];
            arr[j]=arr[i];
            arr[i]=temp;
        }
    }
    }

    cout<<"printing the value after sorting\n";
    for(int i=1; i<n; i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}


// You are using GCC
#include<iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int arr[n];
    
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    
    cout<<"Student's height order before sorting:";
    for(int i=0; i<n;i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
    
    for(int i=0; i<n-1; i++){
        cout<<"Height order of students after iteration "<<i+1<<":";
        
        int minindex=i;
        for(int j=i+1; j<n; j++){
            if(arr[j]<arr[minindex]){
                minindex=j;
            }
        }
        int temp = arr[minindex];
        arr[minindex]=arr[i];
        arr[i]=temp;
            for(int itra=0; itra<n; itra++){
                cout<<arr[itra]<<" ";            
            }
            cout<<endl;
        }
    
    cout<<"After final comparison of all students, the height order becomes:";
    for(int i=0; i<n; i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    return 0;
}