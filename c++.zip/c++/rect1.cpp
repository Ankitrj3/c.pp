#include<iostream>
using namespace std;

class rectrangle{
  private:
         int len,wid,area;
         static int count;
         
  public:
        void getdata(void){
            cout<<"enter the value of length and width"<<endl;
            cin>>len>>wid;
            count++;
        }
        
        void areaofrectrangle(void){
            area = len*wid;
           cout<<"the area of rectrangle "<<"is"<<area;
            }
        
        static void getcount(){
            cout<<"the user find area of rectrangle  "<<count<<"  times"<<endl;
        }
        
};

int rectrangle :: count;

int main(){

int n;
cout<<"enter number of rectrangle to find the areaofrectrangle\n ";
cin>>n;
rectrangle ob[n];
    
for(int i=0; i<n; i++){
    ob[i].getdata();
    
}
    
rectrangle::getcount();   
for(int i=0; i<n; i++){
  
  ob[i].areaofrectrangle();
}  
    
    return 0;
}