#include<iostream>
using namespace std;

void divide(float x,float y,float z){
    cout<<"we are inside the function\n";
    if(x-y!=0){
        cout<<z/(x-y)<<endl;
    }else{
        throw(x-y);
    }
}
int main(){
    try{
        divide(12,34,23);
        divide(10,10,20);
    }
    catch(float x){
        cout<<"exeception came "<<x<<endl;
    }
};