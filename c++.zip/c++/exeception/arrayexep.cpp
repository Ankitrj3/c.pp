#include<iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int sum=0;
    int arr[n];
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    
    try{
    for(int i=0; i<n; i++){
        if(arr[i]<0){
            throw arr[i];
        }else{
            sum+=arr[i];
        } 
    }
cout<<sum;
}catch(int x){
    cout<<"number can not be negative "<<x<<endl;    
}

    
    return 0;
}