#include<iostream>
using namespace std;

int main(){
    float a=10;
    float b,c;
    cin>>b;
    try{
        if(b==0){
            throw b;
        }else{
            c=a/b;
            cout<<c;
        }
    }
    catch(float x){
        cout<<"the number can not divide by 0\n";
        cout<<"your entered number is "<<x;
    }
    
    cout<<"hello world\n";
    return 0;
}