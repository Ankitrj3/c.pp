// You are using GCC
#include<iostream>
using namespace std;

int main(){
    int a;
    cin>>a;
    int arr[a];
    for(int i=0; i<a; i++){
        cin>>arr[i];
    }
    int b;
    cin>>b;
    int arr1[b];
    for(int i=0; i<b; i++){
        cin>>arr1[i];
    }
    int s1,s2,s3;
    s1=a;
    s2=b;
    s3=s1+s2;
    
    int arr2[s3];
    
    for(int i=0; i<s1; i++){
        arr2[i]=arr[i];
    }
    for(int i=0; i<s2; i++){
        arr2[s1+i]=arr1[i];
    }
    int maxnum=arr2[0];
    for(int i=0; i<s3; i++){
    if(arr2[i]>maxnum){
        maxnum=arr2[i];
    }
    }    
    cout<<maxnum;
    return 0;
}