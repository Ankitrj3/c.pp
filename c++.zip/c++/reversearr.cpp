#include<iostream>
using namespace std;
int main(){
    int s,size;
    cin>>s;
    int arr[s];
    
    for(int i=0; i<s; i++){
        cin>>arr[i];
    }
    size=sizeof(arr)/sizeof(arr[0]);
    for(int i=size; i<arr[0]; i--){
        cout<<"Updated array:"<<" "<<arr[i];
    }
    return 0;
}