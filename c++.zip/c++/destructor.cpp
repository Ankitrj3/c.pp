#include<iostream>

using namespace std;

class counter{
    int id;

public: 
    counter(int i):id(i){
        cout<<"constuctor of object id ="<<id<<endl;
    }
    ~counter(){//~ this is symbol used in cpp for destructor or this also known as tailed symbol
        cout<<"destructor with id ="<<id<<endl;
    }
};

int main(){
    counter c1(1);
    counter c2(2);
    counter c3(3);
    cout<<"end of main"<<endl;//it will delete like stack lifo;
    return 0;
}