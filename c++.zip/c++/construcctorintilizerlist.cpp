#include<iostream>

using namespace std;

// intilizer list

class Box{
    int l,b,h;
    
public:
    Box():l(0),b(0),h(0){
        
    }
    Box(int x, int y, int z):l(x),b(y),h(z){
        
    }
    int volume(){
        return (l*b*h);
    }
};
int main(){
    Box ob1(12,34,30);
    Box ob2;
    
    cout<<"the volume of first object "<<ob1.volume()<<endl;
    cout<<"the volume of second object "<<ob2.volume();
    
    return 0;
}