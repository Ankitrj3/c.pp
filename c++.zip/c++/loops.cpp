#include<iostream>
using namespace std;

int main(){
    //loops
    //int k=2;
    /*while(k<34){
        cout<<"your number of loops is"<<k<<endl;
        k=k+1;
    }*/
    /*int j=0;
    //do while atleast one when our condition is wrong
    do{
        cout<<"your loops run"<<j<<endl;
        j=j+1;
    }while(j>34);*/

    for(int i = 0; i<=50; i=i+1){
        cout<<"ankit"<<i<<endl;
    }
    return 0;
}