// Sunank needs to create a program to calculate the area of triangles based on their base and height. He reads the number of triangles 'n' and their dimensions from a file named "triangle.txt". After reading the data, his program calculates the area of each triangle and displays it.



// Formula: Area of a triangle = 0.5 * base * height



// Note: The base and height values are written with two precisions within the file, and then those values are read and results are calculated.

// Input format :
// The first line consists of an integer n, representing the number of triangles.

// For each of the 'n' triangles, the input consists of two floating-point numbers in each line: base (b) and height (h).

// Output format :
// If n is greater than 10, the output prints "Exceeding limit!".

// Otherwise, for each triangle, the output prints a floating-point value representing the area rounded to two decimal places in each line.

// Code constraints :
// 1 <= n <= 10

// 1 <= b, h <= 500

// Code constraints :
// 1 <= n <= 10

// 1 <= b, h <= 500

// Sample test cases :
// Input 1 :
// 4
// 15.5 45.5
// 10.0 15.70
// 8.5 7.77
// 6.77 60.5
// Output 1 :
// 352.62
// 78.50
// 33.02
// 204.79
// Input 2 :
// 11
// 20.5 35.2
// 25.0 40.6
// 18.8 45.7
// 35.0 50.3
// 19.3 42.1
// 24.6 38.9
// 30.7 47.2
// 45.5 55.8
// 15.4 36.1
// 40.0 60.0
// 50.2 70.9
// Output 2 :
// Exceeding limit!

#include<iostream>
#include<iomanip>
#include<fstream>

using namespace std;

int main(){
    
    int n;
    double b,h;
    
    cin>>n;
    if(n>10){
        cout<<"Exceeding limit\n";
        return 0;
    }
    
    ofstream write ;
    write.open("num.txt");
    for(int i=0; i<n; i++){
        cin>>b>>h;
        if(b<1 || h>500){
            cout<<"Exceeding limit\n";
            return 0;
        }
        double area = 0.5*b*h;
        
        write<<fixed<<setprecision(2)<<area<<endl;
    }
    write.close();
    
    ifstream read;
    read.open("num.txt");
    double j;
    while(read>>j){
        cout<<fixed<<setprecision(2)<<j<<endl;
        
    }
    read.close();
}