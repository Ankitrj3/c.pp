#include<iostream>
#include<fstream>

using namespace std;

int main(){
    int n;
    int data;
    string c;
    cout<<"enter the number of data\n";
    cin>>n;

    ofstream fw;
    fw.open("ank.txt");

    cout<<"enter data\n";
    for(int i=0; i<n; i++){
        cin>>data;
        fw<<data<<endl;
    }
    fw.close();

    ifstream fr;
    fr.open("ank.txt");

    if(fr.fail()!=0){
        cout<<"file not found\n";
    }else{
        cout<<"printing the data\n";
        while(fr.eof()==0){//we are using eof function end of file
             getline(fr,c);//while using loops and eof function we can print all the file
             cout<<c<<endl;
        }
    }


    return 0;
}