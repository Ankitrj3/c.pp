// Rita wants to write a program that calculates the factorial of a non-negative integer and saves the numbers from 1 to the factorial value in a file named "numbers.txt". The program should take an input of a non-negative integer, calculate its factorial, and display the factorial value. It should then create the file "numbers.txt" and populate it with the numbers from 1 to the factorial value. Finally, the program should output the message "Success" if everything goes well.



// Note: This is a sample question asked in a Wipro interview.

// Input format :
// The input consists of the non-negative integer as a long long type (n)

// Output format :
// The output displays the following format:

// The factorial value of n.

// The message "Success" indicates the successful creation of the file.



// Refer to the sample output for formatting specifications.

// Code constraints :
// 1 <= n <= 10

// Sample test cases :
// Input 1 :
// 5
// Output 1 :
// 120
// Success

// You are using GCC
#include<iostream>
#include<fstream>

using namespace std;

int main(){
    int n;
    cin>>n;
    double fact = 1.0; 
    ofstream write;
    write.open("number.txt");
    if(n<1){
        cout<<"Success";
        return 0;
    }
    for(int i=1; i<=n; i++){
        fact*=i;
    }
    cout<<fact<<endl;
    write<<fact<<endl;
    write.close();
    cout<<"Success";
    
    return 0;
}
