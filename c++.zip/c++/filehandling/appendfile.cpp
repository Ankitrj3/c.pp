// #include<iostream>
// #include<fstream>

// using namespace std;

// int main(){
//     string s;
//     ofstream rd;
//     ifstream wr;
//     rd.open("append.txt",ios::app);
//     rd<<"hello mr ankit ";
//     rd.close();
     
    
//     wr.open("append.txt",ios::in);
//     getline(wr,s);
//     cout<<s;
//     wr.close();

//     return 0;
// }

#include<iostream>
#include<fstream>
using namespace std;

int main(){
    ofstream write;
    write.open("appent.txt");
    write<<"HI MR. ";
    write.close();
    
    ofstream wr;
    wr.open("appent.txt",ios::app);
    string j;
    cin>>j;
    wr<<j;
    wr.close();
    
    ifstream read;
    read.open("appent.txt");
    string k;
    getline(read,k);
    cout<<k;
    
    read.close();
    
    
    return 0;
}