// Rajesh is tasked with developing a program to process a list of integers from user input. The program should read the number of integers n, followed by the values. It should then categorize these integers into two separate files: even numbers in one file ("even.txt") and odd numbers in another file ("odd.txt"). Finally, the program should display the contents of both files, one after the other.



// Note: This is a sample question asked in a Capgemini interview.

// Input format :
// The first line of input consists of the number of inputs 'n'.

// The next line consists of 'n' inputs separated by space.

// Output format :
// The output displays the even and odd numbers on a separate line.



// Refer to the sample output for format specifications.

// Code constraints :
// 1 <= n <= 100

// Sample test cases :
// Input 1 :
// 10
// 1 2 3 4 5 6 7 8 9 10
// Output 1 :
// 2 4 6 8 10 
// 1 3 5 7 9 
// Input 2 :
// 8
// 34 6 93 45 43 11 63 12
// Output 2 :
// 34 6 12 
// 93 45 43 11 63 

