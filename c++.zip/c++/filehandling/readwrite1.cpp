#include<iostream>
#include<fstream>
// read write used to read binary data using write we can writ the data
using namespace std;

class student {
    char name[30];
    int rollno;
    float marks;
public:
     void getdata(){
        cout<<"enter the name\n";
        cin>>name;
        cout<<"enter the rollno\n";
        cin>>rollno;
        cout<<"enter the marks\n";
        cin>>marks;
     }
     void putdata(){
        cout<<"your name is "<<name;
        cout<<"your roll no is "<<rollno;
        cout<<"your marks is "<<marks;
     }
};

int main(){
    student ob1,ob2;
    cout<<sizeof(ob1)<<endl;
    ob1.getdata();
    ofstream ob("data.dat",ios::binary);
    ob.close();
    
    fstream file;
    file.open("data.dat",ios::in|ios::out);
    file.write((char *)&ob1,sizeof(ob1));
    file.seekg(0);

    file.read((char *)&ob2,sizeof(ob2));
    ob2.putdata();
    file.close();
    
    return 0;
}