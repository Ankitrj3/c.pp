#include<iostream>
#include<fstream>

using namespace std;

int main() {
    ofstream ob("xyz.txt");
    
    ob << "a" << " " << 12 << endl;
    ob << "b" << " " << 14 << endl;
    ob << "c" << " " << 13 << endl;
    
    ob.close();

    return 0;
}
