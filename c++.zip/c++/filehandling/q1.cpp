// Ragul wants to write a program to calculate the sum of a series of numbers and store them in a file. He wants to take input from the user for the number of elements in the series and the values of each element. Calculate the sum of the numbers and store them in a file named "sample.txt".



// Note: This is a sample question asked in a TCS interview.

// Input format :
// The first line of the input consists of the number of values to be given(n).

// The second line of the input consists of numbers.

// Output format :
// The output displays the sum of the integers.

// Code constraints :
// 1 <= n <= 100

// Sample test cases :
// Input 1 :
// 5
// 1 2 3 4 5
// Output 1 :
// 15
// Input 2 :
// 3
// 3 2 1
// Output 2 :
// 6
// You are using GCC
#include<iostream>
#include<fstream>

using namespace std;

int main(){
    int k;
    cin>>k;
    int j;
    int sum=0;
    ofstream write;
    write.open("sample.txt");
    
    for(int i=0; i<k; i++){
        cin>>j;
        sum+=j;
    }
        write<<sum;
    write.close();
    
    ifstream read;
    read.open("sample.txt");
    int n;
    read>>n;
    cout<<n;
    
    return 0;
}


