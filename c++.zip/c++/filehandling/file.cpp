#include<iostream>
#include<fstream>
using namespace std;

// Sample test cases :
// Input 1 :
// 5
// 1 2 3 4 5
// Output 1 :
// 15
// Input 2 :
// 3
// 3 2 1
// Output 2 :
// 6
// You are using GCC

int main(){
    int n;
    cin>>n;
    
    int sum =0;
    
    int val;
    ofstream wr("ankit.txt");
    for(int i=0; i<n; i++){
        cin>>val;
        sum+=val;
    }
        wr<<sum;
    wr.close();

    ifstream rd("ankit.txt");
    int j;
    rd>>j;
    cout<<j;
    rd.close();
    return 0;
}