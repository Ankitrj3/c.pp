// Ambika wants to write a program that demonstrates file handling operations, such as appending data to an existing file and reading the contents of a file. The program should prompt the user to enter a string, append it to an existing file named "sample.txt", and then display the contents of the file on the console.



// File Name: sample.txt



// Note: The file name sample.txt contains the text "Time is a Great Teacher BUT Unfortunately It Kills All Its Pupils".



// Note: This is a sample question asked in an HCL.

// Input format :
// The input consists of a string.

// Output format :
// The output displays provide the following format:



// If the file "sample.txt" is successfully opened and the data is appended, the program will display the message "Data appended successfully."

// After appending the data, the program will display the contents of the file "sample.txt" on the console, word by word, separated by spaces.



// Refer to the sample output for format specifications.

// Sample test cases :
// Input 1 :
// String
// Output 1 :
// Data appended successfully
// Time is a Great Teacher BUT Unfortunately It Kills All Its Pupils String 


// You are using GCC
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string input;
   
    getline(cin, input);

    ofstream file("sample.txt", ios::app); 
    file<<"Time is a Great Teacher BUT Unfortunately It kills All Its Pupils ";
    if (!file) {
        cerr << "Error opening file." << endl;
        return 1; 
    }

    file << " " << input << endl; 
    file.close(); 

    cout << "Data appended successfully" << endl;

    ifstream read("sample.txt"); 

    if (!read) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    string word;
    while (read >> word) {
        cout << word << " ";
    }
    cout << endl;

    read.close(); 

    return 0;
}

