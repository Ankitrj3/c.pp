// seekg seekp tellg tellp

#include<iostream>
#include<fstream>

using namespace std;

int main(){

    string s;
    ofstream wr;
    fstream file;

    wr.open("hello.txt",ios::out);
    wr<<"hello world";
    wr.close();

    file.open("hello.txt",ios::in|ios::out);
    cout<<file.tellg()<<endl;
    cout<<file.tellp()<<endl;
    file.seekg(6);
    //we can use ios::beg,ios::cur,ios::end as a second argument 
    file.seekp(6);
    cout<<file.tellg()<<endl;
    cout<<file.tellp()<<endl;
    file>>s;
    cout<<s;

    return 0;
}