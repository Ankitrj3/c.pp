#include<iostream>
#include<fstream>
#include<cstring>

using namespace std;
int  main(){

    char s[90];
    cout<<"enter the string\n";
    cin.getline(s,90);
    int l = strlen(s);

    fstream f;
    f.open("readdata.txt", ios::in | ios::out);
    for(int i=0; i<l; i++){
        f.put(s[i]);
    }
    f.seekg(0);
    char ch;
    while(f){
        f.get(ch);
        cout<<ch;
    }
    return 0;
}