ch = fin.get();
    // cout<<ch<<endl;