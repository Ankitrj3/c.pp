#include<iostream>
#include<fstream>

using namespace std;

int main(){
    
    string r;
    ofstream fw("ankit.txt");
    fw<<"Data is present  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s";
    fw.close();

    cout<<"data saved\n";
    ifstream fr("ankit.txt");
    getline(fr,r);
    cout<<r;
    fr.close();
    return 0;
}