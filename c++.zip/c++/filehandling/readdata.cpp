#include<iostream>
#include<fstream>

using namespace std;

int main(){
    char ch;
    string s;
    char s1[30];
    ifstream fin("data.txt");

    // get() for single character
    // >> for sigle word
    // getline() for a line
    // loop for all the data in file
    
    ch = fin.get();//for single char;
    cout<<ch<<endl;
    
    // fin>>s;//for single word
    // cout<<s<<endl;

    // fin.getline(s1,30);//print one line of file from first
    // cout<<s1;
    
    getline(fin,s);
    cout<<s;

    fin.close();

    return 0;
}

// fundtion in file handling 
// open()
// close()
// getline()
// get()
// put()
// read()
// write()
// tellg()
// tellp()
// seekg()
// seekp()
// fail()
// eof()