
#include<iostream>
#include<fstream>
using namespace std;

int main(){
    
    ofstream write;
    write.open("normal.txt",ios::app|ios::out);
    write<<"hello world ankit";
    write.close();
    
    fstream read("normal.txt",ios::in);
    cout<<read.tellg();
    cout<<read.tellp();
    read.seekg(5);
    read.seekp(5);
    cout<<read.tellg();
    cout<<read.tellp();
    string j;    
    getline(read,j);
    cout<<j;
    
}