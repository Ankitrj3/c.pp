#include<iostream>
#include<fstream>

using namespace std;

int main(){
    int rollno , marks;
    int n;
    cout<<"enter n:\n";
    cin>>n;
    ofstream fout("data.txt");
    fout<<"Data\n";

    for(int i=0; i<n; i++){
        cout<<"enter rollno and marks:\n";
        cin>>rollno>>marks;
        fout<<"your roll no is "<< rollno<<" "<<marks<<endl;
    }
    fout.close();
    return 0;
}