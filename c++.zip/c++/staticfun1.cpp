// You are using GCC
#include<iostream>
using namespace std;
class Demo{
    public:
    int xin,yin;
    static int x,y;
    static void get(){
        x=10; y=20;
    }
    static void fun(){
        cout<<"Value of X:"<<x<<endl;
        cout<<"Value of Y:"<<y<<endl;
    }
};
int Demo :: x=10;
int Demo :: y=20;

int main(){
    Demo ob;
    cin>>ob.xin>>ob.yin;
    Demo::get();
    Demo::fun();
    cout<<"Value of X:"<<ob.xin<<endl;
    cout<<"Value of Y:"<<ob.yin;
    
    return 0;
}