// You are using GCC
#include<iostream>
using namespace std;
int main(){
    int s,size;
    cin>>s;
    char arr[s];
    char arr1[s];
    for(int i=0; i<s; i++){
        cin>>arr[i];
    }
    size=sizeof(arr)/sizeof(arr[0]);
    for(int i=0; i<s; i++){
        arr1[i]=arr[s-i-1];
    }
    cout<<"Updated array:";
    for(int i =0 ; i<s; i++){
        cout<<" "<<arr1[i];
    }
    return 0;
}