#include<iostream>
using namespace std;
struct Node{
    int data;
    struct Node*next;
};
struct Node*temp, * head;
int main()
{
    int choice;
    cout<<"Enter choice: (1,0)";
    cin>>choice;
    while(choice)
    {
        struct Node*newnode = new Node();
        cout<<"Enter data: ";
        cin>>newnode->data;
        if(head==NULL)
        {
            temp=newnode;
            head=newnode;
        }
        else
        {
            temp->next=newnode;
            temp=newnode;
        }
        cout<<"Enter choice: (1,0)";
        cin>>choice;
    }
    int pos,i=1;
    cout<<endl;
    cout<<"Before Insertion: ";
    temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;
    cout<<"Enter position where you want to delete: ";
    cin>>pos;
    temp= head;
    while(i<pos-1)
    {
        temp=temp->next;
        i++;
    }
    struct Node* newnode;
    newnode=  temp->next;
    temp->next=  newnode->next;
    delete newnode;
    cout<<"After deletion: ";
    temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    return 0;
}