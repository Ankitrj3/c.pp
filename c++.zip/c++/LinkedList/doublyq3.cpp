#include <iostream>
using namespace std;

struct node {
    int data;
    struct node* prev,* next;
};

struct node* head = NULL;

void traverse() {
    struct node* temp;
    if (head == NULL)
        cout << "List is empty\n";
    else {
        temp = head;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
    }
    cout << endl;
}

void insertAtFront(int n) {
    struct node* temp = new node();
    // temp = new struct node;
    temp->data = n;
    temp->prev = NULL;
    temp->next = head;
    if (head != NULL)
        head ->prev = temp;
    head = temp;
    cout << "Node Inserted\n";
}

int main() {
    int n;
    while (cin >> n) {
        insertAtFront(n);
        traverse();
    }
    return 0;
}