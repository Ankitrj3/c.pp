#include<iostream>
using namespace std;
struct node {
    int data;
    struct node* next;
};

struct node* createCircularLinkedList(int n) {
    struct node* head = NULL;
    struct node* temp = NULL;

    for (int i = 0; i < n; i++) {
        struct node* newnode = new node();
        newnode->data = i + 1;
        newnode->next = NULL;

        if (head == NULL) {
            head = newnode;
            temp = newnode;
        } else {
            temp->next = newnode;
            temp = newnode;
        }
    }

    // Make the last node point to the header node
    temp->next = head;

    return head;
}

void printCircularLinkedList(struct node* head) {
    struct node* temp = head;

    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    cout << endl;
}

struct node* findIntersection(struct node* head1, struct node* head2) {
    struct node* ptr1 = head1;
    struct node* ptr2 = head2;

    // Find the point where the two linked lists intersect
    while (ptr1 != ptr2) {
        ptr1 = ptr1->next;
        ptr2 = ptr2->next;

        if (ptr1 == head1) {
            ptr1 = head2;
        }

        if (ptr2 == head2) {
            ptr2 = head1;
        }
    }

    // Return the intersecting node
    return ptr1;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        struct node* head1 = createCircularLinkedList(n);

        int m;
        cin >> m;

        struct node* head2 = createCircularLinkedList(m);

        // Find the intersection of the two linked lists
        struct node* intersectingNode = findIntersection(head1, head2);

        // Print the intersecting elements
        if (intersectingNode != NULL) {
            cout << "Intersection: ";
            printCircularLinkedList(intersectingNode);
        } else {
            cout << "No intersection" << endl;
        }
    }

    return 0;
}
