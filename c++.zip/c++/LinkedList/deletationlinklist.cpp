// Code constraints :
// The maximum number of elements in the list is 10^5.

// Each element is an integer.

// Sample test cases :
// Input 1 :
// 5
// 1 2 3 4 5
// Output 1 :
// 5 4 3 2 1 
// 4 3 2 1 
// 4 3 2 
// Input 2 :
// 3
// 9 8 7
// Output 2 :
// 7 8 9 
// 8 9 
// 8

#include<iostream>
using namespace std;

struct node{
   int data;
   struct node * next;
};
struct node * head = NULL;

void insertAthead(){
    
    struct node *newnode = new node();
    cin>>newnode->data;
    
    if(head == NULL){
        head = newnode;
        head -> next = NULL;
    }else{
        newnode->next=head;
        head = newnode;
        
    }
}

void deleteAtbeg(){
    if(head==NULL){
        cout<<"empty linked list";
    }else{
        struct node *todelete = head;
        head = head -> next;
        delete todelete;
    }
}
void deleteatanypostion(){
       int da;
       cout<<"enter the data which u want ot delete\n";
       cin>>da;

       temp = head;
       while(temp->next->data!=da){
           temp = temp -> next;
       }
       struct node *todelete = temp->next;
       temp->next=temp->next->next;
       delete todelete;
}

void deleteAtend(){
    
   struct node* current = head;
    struct node* prev = NULL;

    while (current->next != NULL) {
        prev = current;
        current = current->next;
    }

    prev->next = NULL;

  
    delete current;
    
}


void display(){
    struct node * current = head;
    while(current!=NULL){
        cout<<current->data<<" ";
        current=current->next;
    }
}


int main(){
    int n;
    cin>>n;
    
    for(int i=0; i<n; i++){
        insertAthead();
    }
    display();
    cout<<endl;
    deleteAtbeg();
    display();
    cout<<endl;
    deleteAtend();
    display();
    
    return 0;
}











