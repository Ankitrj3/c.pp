#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};
struct node * head=NULL;
struct node * temp=NULL;
int main(){
    int n;
    cin>>n;
    
    for(int i=1; i<=n; i++){
        struct node * newnode = new node();
        cin>>newnode->data;
        
        if(head==NULL){
            head = newnode;
        }else{
            newnode->next=head;
            head = newnode;
        }
    }
    temp = head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp = temp->next;
    }
    
   
    // insertation at second position
    int  pos=2,i=1;

    temp = head;
    struct node * newnode = new node();
    cin>>newnode->data;
    while(i<pos-1){
        temp = temp->next;
        i++;
    }
    newnode->next=temp->next;
    temp->next=newnode;
    
     temp= head;
    
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    
    
    return 0;
}