#include<iostream>
using namespace std;

struct node{
    string data;
    struct node *next;
};
struct node *head = NULL;
struct node *temp = NULL;

void reverselinkedlist(){
    struct node *next = NULL;
    struct node *prev = NULL;
    struct node *current = head;
    
    while(current != NULL){
    next = current -> next;
    current -> next = prev;
    prev = current;
    current = next; 
    }
    head = prev;
}
int main(){
    int n;
    cin>>n;
    
if(n==0){
    cout<<"Document:\n";
    cout<<"Updated Document:\n";
    
} else{   
    for(int i=0; i<n; i++){
        struct node *newnode = new node;
        cin>>newnode->data;
        
        if(head == NULL){
            temp = head = newnode;
        }else{
            temp->next=newnode;
            temp=newnode;
        }
    }
    reverselinkedlist();
    
    
    temp = head;
    cout<<"Document: ";
    while(temp != NULL ){
        cout<<temp->data<<" ";
        temp=temp->next;
    }cout<<endl;
    
    //cretaing node and taking input from the user
    struct node *newnode = new node();
    cin>>newnode->data;
    cout<<"Updated Document:";
    //printing the previous node
    temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    
    // inserting at last node
    struct node *tail=NULL;

    if(head != NULL){
        head = tail = newnode;
    }else{
        tail->next=newnode;
        tail=newnode;
    }
    tail=head;

    // printing the last node
    while(tail != NULL){
        cout<<tail->data<<" ";
        tail= tail->next;
    }
    
   }
   return 0;
}