// Implement a vehicle parking management system that supports rotating the parking positions of the vehicles using a doubly-linked list. Given the current parking positions of the vehicles and a rotation number, update the parking positions by rotating the vehicles counter-clockwise.



// Note: This is a sample question asked in the Amazon recruitment.

// Input format :
// The input consists of the following:



// The number of vehicles parked in the parking lot, n (integer).

// n characters representing the unique identification of each vehicle.

// The rotation number, k (integer).

// Output format :
// The output consists of the following:



// The current parking positions of the vehicles before rotation.

// The updated parking positions of the vehicles after rotating them counter-clockwise by k positions.

// Code constraints :
// The parking system can accommodate any number of vehicles.
// The rotation number, N, is a positive integer and is smaller than the total number of parked vehicles.

// Sample test cases :
// Input 1 :
// 5
// a  b  c  d  e
// 2
// Output 1 :
// Current Parking Positions:
// a-->b-->c-->d-->e-->NULL
// Updated Parking Positions:
// c-->d-->e-->a-->b-->NULL
// Input 2 :
// 8
// a  b  c  d  e  f  g  h
// 4
// Output 2 :
// Current Parking Positions:
// a-->b-->c-->d-->e-->f-->g-->h-->NULL
// Updated Parking Positions:
// e-->f-->g-->h-->a-->b-->c-->d-->NULL
// Input 3 :
// 2
// A B
// 0
// Output 3 :
// Current Parking Positions:
// A-->B-->NULL
// Updated Parking Positions:
// A-->B-->NULL

#include<iostream>
using namespace std;

struct node{
    string data;
    struct node *next ;
};
struct node *head = NULL;
struct node *temp = NULL;

void insertATtail(){
    struct node *newnode = new node();
    cout<<"enter the data";
    cin>>newnode->data;

    if(head == NULL){
        head = temp = newnode;
    }else{
        temp->next=newnode;
        temp=newnode;
    }
}

void display(){
    temp = head;
    struct node *current=temp;
    while(current!=NULL){
        cout<<current->data<<"-->";
        current=current->next;
    }
}

int main(){

    int n;

    while(cin>>n){
        switch(n){
         case 1:
         insertATtail();
         break;

         case 2:
         display();
         break;

         case 3:
         return 0;
         break;
          
         default:
         cout<<"invalid\n";
        }
    }
}