// [10:23 pm, 27/09/2023] Abdul Sir Lpu: You are tasked with developing a program for a task management system that utilizes a doubly linked list to track and manage tasks. Each node in the doubly linked list represents a task with a unique ID. The program should allow for inserting tasks at the front, deleting tasks from the front and end of the list, and displaying the updated list of tasks after each operation.



// Implement a doubly linked list where elements can be inserted at the front and deleted from the front and end of the list. 



// Note: This is a sample question asked in an Infosys interview.

// Input format :
// The first line contains an integer n, representing the number of elements to insert.

// The next line contains n space-separated integers representing the elements to be inserted at the front of the linked list.

// Output format :
// The output consists of three parts:

// After inserting all the elements at the front, display the elements in the linked list.

// After deleting the node at the front, display the updated linked list.

// After deleting the node at the end, display the final linked list.
// [10:23 pm, 27/09/2023] Abdul Sir Lpu: Refer to the sample output for formatting specifications.

// Code constraints :
// The maximum number of elements in the list is 10^5.

// Each element is an integer.

// Sample test cases :
// Input 1 :
// 5
// 1 2 3 4 5
// Output 1 :
// 5 4 3 2 1 
// 4 3 2 1 
// 4 3 2 
// Input 2 :
// 3
// 9 8 7
// Output 2 :
// 7 8 9 
// 8 9 
// 8




