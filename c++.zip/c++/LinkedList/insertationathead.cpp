#include <iostream>
using namespace std;

struct node {
    int data;
    struct node* next;
};

struct node* head = NULL;
struct node* temp = NULL;

void reverse() {
    struct node* next = NULL;
    struct node* prev = NULL;
    struct node* current = head;

    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    head = prev;
}

int main() {
    int n;
    cin >> n;
    cout << "Created Linked list: ";
    
    for (int i = 1; i <= n; i++) {
        struct node* newnode = new node();
        cin >> newnode->data;

        if (head == NULL) {
            head = temp = newnode;
        } else {
            temp->next = newnode;
            temp = newnode;
        }
    }

    // Reverse the linked list after creating it
    reverse();

    temp = head; 
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
    
    struct node *newnode = new node();
    cin>>newnode->data;
    //insert at head;
    cout<<"Final List: ";
    if(head==NULL){
        head = newnode;
    }else{
        newnode->next = head;
        head = newnode;
    }
    while(head){
        cout<<head->data<<" ";
        head=head->next;
    }
    return 0;
}
