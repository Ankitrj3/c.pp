#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *next;
};
struct node *head=NULL;
struct node *temp=NULL;

void insertAthead(int n){
    
    for(int i=1; i<=n; i++){
        struct node *newnode = new node();
        cout<<"enter the data to insert at head\n";
        cin>>newnode->data;

        if(head == NULL){
            head = newnode;
        }else{
            newnode->next=head;
            head = newnode;
        }

    }

    temp = head;
}

void insertATtail(){
     struct node *tail=head;
     struct node *newnode = new node();
     cout<<"enter the data to insert at last\n";
     cin>>newnode->data;

     if(head == NULL){
        head = tail = newnode;
     }else{
        newnode -> next = tail;
        tail = newnode;
     }
     tail = head;

     while(tail!=NULL){
        cout<<tail->data<<"->";
        tail=tail->next;
     }
}

void insertAtanypos(){
      int i=1;
      int pos;
      cout<<"enter the position of data\n";
      cin>>pos;

      while(i<pos-1){
        temp = temp->next;
        i++;
      }
      temp = head;
      cout<<"enter the data to insert at any position\n";
      struct node *newnode = new node();
      temp = head;
      cin>>newnode->data;
      newnode -> next = temp->next;
      temp->next = newnode;

      temp = head;
}
void deleteathead(){
    struct node *todelete = head;
    head = head->next;
    delete todelete;
}
void deleteatanypostion(){
       int da;
       cout<<"enter the data which u want ot delete\n";
       cin>>da;

       temp = head;
       while(temp->next->data!=da){
           temp = temp -> next;
       }
       struct node *todelete = temp->next;
       temp->next=temp->next->next;
       delete todelete;
}
void dpos(){
    struct node *temp=head;
    int pos=2;
    int i=1;
    while(i<pos-1){
        temp=temp->next;
        i++;
    }
    struct node *todelete = temp->next;
    temp->next=temp->next->next;
    delete todelete;
}

void display(){
       struct node *current = head;

       while(current != NULL){
        cout<<current->data<<"->";
        current=current->next;
       }
       cout<<endl;
}
int main(){
       int n;
       cout<<"enter the number elements \n";
       cin>>n;

       insertAthead(n);
       display();
    //    insertATtail();
    //    insertAtanypos();
     
    //  deleteathead();
    deleteatanypostion();
     display();

    return 0;
}