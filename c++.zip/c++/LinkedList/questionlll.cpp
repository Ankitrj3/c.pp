// You need to write a program to maintain a student roster using a singly linked list. 



// Each student is represented by a node in the linked list, which contains the student's name. Implement an insertNode() function, which inserts a new student node with the given name at the specified position in the roster. The position is 1-based, meaning the first student is at position 1.



// If the specified position is 1, the new student node should become the new head of the roster. If the specified position is greater than the current size of the roster, the new student node should be appended at the end. 



// After performing the insertion, you should print the contents of the roster.



// Note: This is a sample question asked in an Amazon interview.

// Input format :
// The first line of input consists of an integer n, representing the number of students currently in the roster.

// The next n lines of input consist of the names of the students on the roster, separated by a line.

// The last line of input consists of a string name, representing the name of the new student to be inserted, and an integer, representing the position at which the new student should be inserted, separated by space.

// Output format :
// The first line of output should print the current linked list elements, separated by space.

// The next line of output should print the updated linked list elements after the insertion at the given position, separated by space.



// Refer to the sample output for formatting specifications.

// Code constraints :
// The student names consist of at most 100 characters.

// The number of students on the roster should not exceed 100.

// Sample test cases :
// Input 1 :
// 4
// John
// Alice
// Bob
// Emma
// Michael 3
// Output 1 :
// Current Linked List:
// John Alice Bob Emma 
// Updated Linked List:
// John Alice Michael Bob Emma 
// Input 2 :
// 4
// Emma
// Daniel
// Sophia
// Oliver
// Charlotte 1
// Output 2 :
// Current Linked List:
// Emma Daniel Sophia Oliver 
// Updated Linked List:
// Charlotte Emma Daniel Sophia Oliver 
// Input 3 :
// 0
// Emma 1
// Output 3 :
// Current Linked List:

// Updated Linked List:
// Emma 

// You are using GCC
#include<iostream>
using namespace std;

struct node{
    string data;
    struct node * next;
};
struct node *head =NULL;
struct node *temp =NULL;

int main(){
    int n; 
    cin>>n;
    for(int i=1; i<=n; i++){
        struct node* newnode =new node();
        cin>>newnode->data;
        
        if(head == NULL){
            head = temp = newnode;
        }else{
            temp->next=newnode;
            temp=newnode;
        }
    }
        cout<<"Current Linked List:\n";
        temp = head;
        while(temp!=NULL){
            cout<<temp->data<<" ";
            temp=temp->next;
        }cout<<endl;
        temp = head;
        
        int pos , i=1;
        struct node * newnode = new node();
        cin>>newnode->data;
        cin>>pos;
        cout<<"Updated Linked List:\n";
        
        if(pos == 1){
            if(head==NULL){
              head = newnode;
            }else{
                newnode->next=head;
                head=newnode;
            }
            while(head){
            cout<<head->data;
            head=head->next;
        }
    }
    
        else{
            temp = head;
            while(i<pos-1){
                temp = temp->next;
                i++;
            }
            newnode->next=temp->next;
            temp->next=newnode;
            
            temp = head;
            while(temp!=NULL){
                cout<<temp->data<<" ";
                temp=temp->next;
            }
        }    
    return 0;
}