// Vijay wants to create a program that allows him to manipulate a linked list.



// He wants to be able to perform the following operations:

// 1: Append Left: Append a node at the beginning(left) of the linked list.

// 2: Append Right: Append a node at the end(right) of the linked list.

// 3: Print: Print the contents of the linked list.

// 4: Exit: Exit the program.



// Note: This is a sample question asked in Accenture recruitment.

// Input format :
// For inserting a node at the beginning of the linked list, input: 1 followed by the value

// For inserting at the end of the linked list, input: 2 followed by the value

// To display the current linked list, input: 3

// To exit the program, input: 4

// Output format :
// The program displays the following outputs based on the inputs provided:

// If the choice is 3: "Linked List: [values separated by space]"

// If the choice is 4: The program exits.

// If the choice is invalid: "Invalid choice"

// Code constraints :
// The input values for the linked list nodes will be non-negative integers.

// Sample test cases :
// Input 1 :
// 1 10
// 2 20
// 3
// 4
// Output 1 :
// Linked List: 10 20
// Input 2 :
// 1 10
// 1 20
// 1 30
// 2 35
// 3 
// 4
// Output 2 :
// Linked List: 30 20 10 35
// Input 3 :
// 5
// 4
// Output 3 :
// Invalid choice


#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};
struct node *head =NULL;

void appendLeft(int data){
    struct node* newnode =new node();
    newnode->data = data;
    newnode->next = head;
    head = newnode;
}

void appendRight(int data){
    struct node* newnode =new node();
    newnode->data = data;
    newnode->next = NULL;
    
    if(head == NULL){
        head = newnode;
    }else{
        struct node* temp = head;
        while(temp->next != NULL){
            temp = temp->next;
        }
        temp->next = newnode;
    }
}

void printList(){
    struct node* temp = head;
    cout<<"Linked List: ";
    while(temp != NULL){
        cout<<temp->data<<" ";
        temp = temp->next;
    }
    cout<<endl;
}

int main(){
    int choice;
    int data;
    
    while(1){
       
        cin>>choice;
        
        switch(choice){
            case 1:
                
                cin>>data;
                appendLeft(data);
                break;
            case 2:
               
                cin>>data;
                appendRight(data);
                break;
            case 3:
                printList();
                break;
            case 4:
                exit(0);
                break;
            default:
                cout<<"Invalid choice"<<endl;
                break;
        }
    }
    
    return 0;
}
