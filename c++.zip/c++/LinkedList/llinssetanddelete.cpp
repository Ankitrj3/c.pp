#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *next;
};
struct node *head =NULL;
struct node *temp =NULL;

void ihead(){
    struct node *newnode = new node();
    cin>>newnode->data;
    
    if(head==NULL){
        head = newnode;
    }else{
        newnode->next=head;
        head = newnode;
    }
    temp=head;
}

void ipos(){
    int pos;
    cin>>pos;
    int i=1;
    temp=head;
    struct node *newnode = new node();
    cin>>newnode->data;
    temp=head;
    while(i<pos-1){
        temp = temp->next;
        i++;
    }
    newnode->next = temp->next;
    temp->next = newnode;
    temp=head;
}

void iend(){
    struct node *newnode = new node();
    cin>>newnode->data;
    temp=head;
    while(temp->next!=NULL){
        temp = temp -> next;
    }
    newnode->next = temp->next;
    temp->next = newnode;
    temp=head;
}

void display(){
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }cout<<endl;
    
}

void dhead(){
    struct node *todelete = head;
    head = head->next;
    delete todelete;
    temp=head;
}
void dpos(){
    
    int k;
    cin>>k;
    temp =head;
    while(temp->next->data!=k){
        temp = temp-> next;
    }
    struct node *todelete = temp->next;
    temp->next=temp->next->next;
    delete todelete;
    temp=head;
}

void dend(){
    temp=head;
    struct node *current = temp;
    struct node *prev = NULL;
    temp=head;
    while(current->next!=NULL){
        prev = current;
        current=current->next;
    }
    prev -> next = NULL;
    delete current;
}

int main(){
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
    ihead();}
    
    display();
    
    dend();
    display();
    // dhead();
    // display();
    
    dpos();
    display();
    
    // ipos();
    // display();
    
    // iend();
    // display();
}


