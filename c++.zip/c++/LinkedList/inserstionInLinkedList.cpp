#include<iostream>
using namespace std;
struct Node{
    int data;
    struct Node*next;
};
struct Node*temp, * head;
int main()
{
    int choice;
    cout<<"Enter choice: (1,0)";
    cin>>choice;
    while(choice)
    {
        struct Node*newnode = new Node();
        cout<<"Enter data: ";
        cin>>newnode->data;
        if(head==NULL)
        {
            temp=newnode;
            head=newnode;
        }
        else
        {
            temp->next=newnode;
            temp=newnode;
        }
        cout<<"Enter choice: (1,0)";
        cin>>choice;
    }
    int pos,i=1;
    cout<<endl;
    cout<<"Before Insertion: ";
    temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;
    cout<<"Enter position where you want to insert: ";
    cin>>pos;
    temp= head;
    while(i<pos-1)
    {
        temp=temp->next;
        i++;
    }
    struct Node* newnode= new  Node();
    cout<<"Enter data: ";
    cin>>newnode->data;
    newnode->next =  temp->next;
    temp->next=  newnode;
    cout<<"After insertion: ";
    temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    return 0;
}



// #include<iostream>
// using namespace std;

// struct node {
//     int data;
//     struct node * next;
// };
// struct node *head = NULL;
// struct node *temp = NULL;
// void insertAthead(){
    
//     struct node *newnode = new node();
//     cin>>newnode->data;
    
//     if(head == NULL){
//         head = newnode;
//         head -> next = NULL;
//     }
//     else {
//         newnode -> next = head;
//         head = newnode;
//     }
//     temp = head;



// }

// void insertAtend(){
//     struct node *newnode = new node();
//     cin>>newnode->data;
    
//     temp = head;
//     while(temp->next!=NULL){
//         temp = temp ->  next;
//     }
//     newnode->next=temp->next;
//     temp->next = newnode;
    
//     temp = head;
    
// }

// void insertatanypos(){
//     int k=2;
//     int i=1;
    
    
//     struct node *newnode = new node();
//     cin>>newnode->data;
//     temp = head;
//     while(i<k-1){
//         temp = temp -> next;
//         i++;
//     }
//     temp = head;
//     newnode->next = temp->next;
//     temp->next = newnode;
//     temp = head;
    
// }
// void display(){
    
//     while(temp!=0){
//         cout<<temp->data<<" ";
//        temp=temp->next;
//     }cout<<endl;
// }

// int main(){
//     int n;
//     cin>>n;
    
//     for(int i=0; i<n; i++){
         
//     insertAthead();
   
//     }
//     display();
//     insertAtend();
//     display();
//     insertatanypos();
//     display();
   
   
   
   
   
    
    
//     return 0;
// }