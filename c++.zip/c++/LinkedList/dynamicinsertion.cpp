#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * next ;
};
struct node *head = nullptr;

void ihead(int value){
    struct node *newnode = new node();
    newnode->data=value;

    if(head == nullptr){
        head = newnode;
    }else{
        newnode->next = head ;
        head = newnode;
    }
    cout<<"NODE INSERTED\n";

}
void display(){
    struct  node * temp = head;
    while(temp!=nullptr){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
    
    int value;

    while(cin>>value){
        ihead(value);
        display();
    }

    return 0;
}