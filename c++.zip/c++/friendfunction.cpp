// // friend function is used to access private members of class
// // friend function is not the part of class

// #include<iostream>
// using namespace std;

// class sample{
//     int a;
//     int b;

// public:
//      void getdata(){
//         a=12;
//         b=54;
//      }
//     void putdata(){
//         cout<<a<<endl;
//         cout<<b<<endl;
//     }
// friend float mean(sample ob);//friend function
// };
// float mean(sample ob){//friend function
//     float avg;
//     avg=(ob.a+ob.b)/2;
//     return avg;
// }

// int main(){
//     sample ob;
//     ob.getdata();
//     ob.putdata();
//     int res=mean(ob);
//     cout<<"the averasge is "<<res;
// }


// You are using GCC
#include<iostream>
#include<iomanip>
using namespace std;

class fuel{
    string name;
    double petrol;
    double km;
    double rate;
    
public:
      void getdata(){
          cin>>name;
          cin>>petrol;
          cin>>km;
          cin>>rate;
      }
friend double calculateFuelCost(fuel ob);    
};

double calculateFuelCost(fuel ob){
    double perkm;
    perkm=ob.petrol/100;
    double totalkm;
    totalkm = perkm*ob.km;
    double cost;
    cost=totalkm * ob.rate;
    
    return cost;
}

int main(){
    fuel ob;
    ob.getdata();
    cout<<fixed<<setprecision(2)<<calculateFuelCost(ob);
}