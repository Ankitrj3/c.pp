#include<iostream>
#include<cctype>
#include<string>

using namespace std;

class student{
    int roll;
    string name;
public:
     student(){
         roll = 0;
         name ="";
     }
     student (int r,string s){
         roll = r;
         name = s;
     }
     student(student& s3){
         roll = s3.roll;
         name = s3.name;
     }
     void display(){
         cout<<"roll no "<<roll<<endl;
         cout<<"name "<<name<<endl;
     }
};

int main(){
    student s1(10,"rahul");
    student s2;
    student s3(s1);
    s1.display();
    s2.display();
    s3.display();
    
    return 0;
}