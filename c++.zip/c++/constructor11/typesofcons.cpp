#include<iostream>
using namespace std;

class complex{
    int a,b;
    public:
     complex(int x,int y){
        a=x;b=y;
        cout<<a<<" "<<b<<" ";
     }
     complex(int j){
        a=j;
        cout<<a<<" ";
     }
     complex(){
        cout<<"default constructor"<<" ";
     }

     complex(complex & ob5){
        a= ob5.a;
        b= ob5.b;
     }
     void display(){
        cout<<a<<" "<<b;
     }
};

int main(){
    complex c1(12,34);
    complex c2(122);
    complex c3;
    complex ob5(c1);//copy constructor
    ob5.display();
}