#include<iostream>
using namespace std;

class complex{
    int a,b;
    public:
       complex(){
          cout<<"hello constructor";
       }
};

int main(){

    complex ob,ob2;

}