#include<iostream>
using namespace std;

int main(){
    //std::cout<<"hello world"<<std::endl;
    //std::cout<<"hello ankit";
    
    //declaring the variables
    int k=23,p=34,l=21;
    short m=3;
    long s;
    long long w;
    float o=34.4;
    double const fu=23.455;//const keyword used to crete constant variable which cannot be changed
    long double dk;
    //fu=23.33; //i was trying to change the value of constant variable
    //printing the values using cout
    cout<<k<<endl;
    cout<<p<<endl;
    cout<<l<<endl;
    cout<<m<<endl;
    cout<<o<<endl;
    cout<<fu;

    return 0;

}