// Single File Programming Question

// Problem statement




// Sheela is developing a billing system for a supermarket. The supermarket has a loyalty program where customers earn reward points based on the total amount spent during their shopping. To calculate reward points, she needs to implement a function that takes an array of transaction amounts and finds the sum of the digits of each transaction amount.




// If the sum of digits is more than one digit, further add the digits until a single-digit result is obtained. Finally, the total reward points earned by the customer will be the sum of these single-digit results.




// The program defines a base class "SummationCalculator" with a pure virtual function "sum" and a derived class "SimpleSummationCalculator" that overrides the "sum" function to calculate the sum of the digits. Write a program to accomplish this task.







// Function Prototype: int sum(int a[ ],int n);




// Example:

// Input:

// 5

// 111 234 121 900 101

// Output:

// 9

// Explanation:

// 111 = 1 + 1 + 1 = 3

// 234 = 2 + 3 + 4 = 9

// 121 = 1 + 2 + 1 = 4

// 900 = 9 + 0 + 0 = 9

// 101 = 1 + 0 + 1 = 2




// The sum of the digits of all the given numbers is 3 + 9 + 4 + 9 + 2 = 27.

// So, the final output is 2+ 7 = 9.




// Input format :

// The first line of the input consists of a single value, n.

// The next line consists of an array of elements separated by a space.

// Output format :

// The output prints the sum of the digits of all the numbers in the array.

// Code constraints :

// Array size < 100

// Array elements < 1000

// Sample test cases :
// Input 1 :
// 5
// 111 234 121 900 101
// Output 1 :
// 9

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.


#include <iostream>
#include <string>
#include <sstream>

using namespace std;

class SummationCalculator {
public:
    virtual int sum(int a[], int n) = 0;
};

class SimpleSummationCalculator : public SummationCalculator {
public:
    int sum(int a[], int n) {
        int totalSum = 0;
        for (int i = 0; i < n; i++) {
            totalSum += getSingleDigitSum(a[i]);
        }
        return getSingleDigitSum(totalSum);
    }

private:
    int getSingleDigitSum(int number) {
        while (number > 9) {
            int sum = 0;
            while (number > 0) {
                sum += number % 10;
                number /= 10;
            }
            number = sum;
        }
        return number;
    }
};

int main() {
    int n;
    cin >> n;

    int arr[n];
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    SimpleSummationCalculator calculator;
    int totalRewardPoints = calculator.sum(arr, n);

    cout << totalRewardPoints << endl;

    return 0;
}
