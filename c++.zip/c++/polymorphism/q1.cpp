// Single File Programming Question

// Problem statement




// Ria is developing a simple educational game for children to test their knowledge of uppercase and lowercase letters. The game will present four letters, and the children will input their answers for each letter. Her task is to implement a program that calculates the score based on the following rules:




// For every correct uppercase letter input, the player earns 10 points.
// For every correct lowercase letter input, the player loses 5 points.
// The game presents four letters, and the player will provide their answers one by one.
// After receiving all four answers, the program will display the final score.




// Create a base class called QuizGame with the virtual method void game(). Define this method in the derived class called StudentScore to calculate the total score based on the number of correct and incorrect answers.

// Input format :

// The input consists of four characters separated by a space.

// Output format :

// The output prints the total score.




// Refer to the sample output for formatting specifications.

// Code constraints :

// The input should be a valid letter from the English alphabet (A to Z or a to z).

// Sample test cases :
// Input 1 :
// A F K R
// Output 1 :
// Score : 40
// Input 2 :
// A b D f
// Output 2 :
// Score : 10
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.


// You are using GCC
#include<iostream>
using namespace std;

class gam{
    public:
  
    virtual void game(){
        
    }
};

int main(){
    
    int n=4;
    char a;
    int score =0;
    for(int i=0; i<n; i++){
        cin>>a;
        if(a>='A' && a<='Z'){
            score+=10;
        }
        else if(a>='a' && a<='z'){
            score-=5;
        }
    }
    cout<<"Score : "<<score;
    return 0;
}