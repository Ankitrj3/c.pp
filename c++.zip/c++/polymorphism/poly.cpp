#include<iostream>
using namespace std;

class base{
    public:
   virtual void show(){
        cout<<"base class\n";
    }
};
class dev1 : public base{
    public:
    void show(){
        cout<<"derived class 1\n";
    }
};
class dev2 : public base{
     public:
     void show(){
        cout<<"derived class 2\n";
     }
};
int main(){
    dev1 d;
    dev2 d1;
    base *ptr;

    ptr = &d;
    ptr->show();

    ptr = &d1;
    ptr->show();
    return 0;
}