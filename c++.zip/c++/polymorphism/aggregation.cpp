#include <iostream>
#include <cstring>
using namespace std;

class department {
    char name[20];

public:
    department() {
        strcpy(name, "abc");
    }
    ~department() {
        cout << "department class destroyed" << endl;
    }
};

class professor {
    int pid;
    int exp;
    department d;

public:
    professor(int a, int b) {
        pid = a;
        exp = b;
    }

    ~professor() {
        cout << "professor class destroyed." << endl;
    }
};

int main() {
    {
        professor p(1, 2);
    }
    cout << "At this point, the professor gets deleted, and the department will be destroyed." << endl;

    return 0;
}
