#include<iostream>
using namespace std;

class shape{
    public:
      virtual float cal_Area() = 0;
};
class square:public shape{
    float a;
    public:
    square(float l){
        a=l;
    }
    float cal_Area(){
        return a*a;
    }
};
class circle:public shape{
     float r;
    public:
    circle(float x){
        r=x;
    }
    float cal_Area(){
        return 3.14*r*r;
    }
};
int main(){
    shape *shape;
    square s(3.4);
    circle c(7.8);
    shape = &s;
    int a1 = shape->cal_Area();
    shape = &c;
    int a2 = shape->cal_Area();
    cout<<a1<<endl;
    cout<<a2<<endl;

    return 0;

}