#include<iostream>
using namespace std;

class shape{
    public:
    double a;
    virtual void area(){
        a=0;
    }
};
class circle : public shape{
    double r;
    public :
    circle(double x){
        r=x;
    }
    void area(){
        a=3.14*r*r;
        cout<<"area circle "<<a<<endl;
    }
};
class triangle : public shape {
    double base,height;
    public:
    triangle(double  b, double h){
        base = b;
        height = h;
    }
    void area(){
        a = 0.5*base*height;
        cout<<"area triangle "<<a<<endl;
    }
};

int main(){
    shape *p;
    p = new circle(2.5);
    p->area();
    p = new triangle(1.5,3.6);
    p->area();

    return 0;
}