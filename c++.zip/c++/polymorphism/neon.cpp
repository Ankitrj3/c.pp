// Single File Programming Question

// Problem statement




// Marc is working as a software developer for a scientific research institute, and his team is currently investigating various types of interesting numbers. One such type is the "Neon Number." A neon number is a special type of positive integer where the sum of the digits of its square is equal to the original number.




// Your task is to develop a program that can efficiently determine whether a given positive integer is a neon number or not,  while also implementing a virtual destructor for appropriate memory management.




// For Example,

// N = 9

// Then, 9^2=81 =>8+1=9

// So, 9 is a neon number.

// Input format :

// The first line of the input represents the neon number.

// Output format :

// The output displays whether the number is a neon number or not.




// Refer to the sample output for formatting specifications.

// Code constraints :

// N < 20

// Sample test cases :
// Input 1 :
// 8
// Output 1 :
// 8 it's Not a Neon Number.

// Input 2 :
// 1
// Output 2 :
// 1  it's a Neon Number.

// Input 3 :
// 6543
// Output 3 :
// Enter a valid number.

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.



#include <iostream>
#include <cmath>
using namespace std;

class Number {
public:
    virtual ~Number() {}

    virtual bool isNeon(int num) = 0;
};

class NeonNumber : public Number {
public:
    virtual bool isNeon(int num) override {
        int square = num * num;
        int sum = 0;

        while (square > 0) {
            sum += square % 10;
            square /= 10;
        }

        return sum == num;
    }

    virtual ~NeonNumber() {
        cout << "NeonNumber destructor called" << endl;
    }
};

int main() {
    Number* num = new NeonNumber();
    int n;

    cout << "Enter a positive integer: ";
    cin >> n;

    if (num->isNeon(n)) {
        cout << n << " is a neon number." << endl;
    } else {
        cout << n << " is not a neon number." << endl;
    }

    delete num;  // Calls the NeonNumber destructor

    return 0;
}
