#include<iostream>
using namespace std;
int main(){
    int size,num,pos,i;
    int arr[]={89,34,23,12,56};
    size=sizeof(arr)/sizeof(arr[0]);
    cout<<"prevoius array was\n";
    for(i=0; i<5; i++){
        cout<<arr[i]<<"\n";
    }cout<<endl;

    cout<<"enter the value which you want to enter\n";
    cin>>num;
    cout<<"enter the position where you want to insert\n";
    cin>>pos;
    size++;
    for(i=size-1; i>pos; i--){
        arr[i]=arr[i-1];
    }
    arr[pos]=num;
    cout<<"new array"<<endl;
    for(i=0; i<size; i++){
        cout<<arr[i]<<"\n";
    }

    return 0;
}

// // insertion character
// // You are using GCC
// #include<iostream>
// using namespace std;

// int main(){
//     int n;
//     char a;
//     int pos;
//     int size;
//     char b;
    
//     cin>>n;
//     char arr[n];
//     for(int i = 0; i<n; i++ ){
//        cin>>arr[i];
//     }
    
//     size=sizeof(arr)/sizeof(arr[0]);
    
//     cin>>pos;
//     cin>>b;
//     size++;
//     for(int i=size-1; i>pos; i--){
//         arr[i]=arr[i-1];
//     }
//     arr[pos]=b;
    
    
//     cout<<"Updated array after insertion: ";
//     for(int i=0; i<size; i++){
//         cout<<arr[i]<<" ";
//     }
    
//     return 0;
// }