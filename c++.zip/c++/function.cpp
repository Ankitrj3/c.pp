#include<iostream>
using namespace std;
//call by value
int add(int a , int b){
    int result;
    result = a+b;
    return result;
}

int main(){
    int a,b;
    cout<<"enter the 2 numbers to find the sum of two numbers"<<endl;
    cout<<"enter 1st number"<<endl;
    cin>>a;
    cout<<"enter 2nd number"<<endl;
    cin>>b;
    cout<<"result of sum of two numbers by using functions"<<add(a,b);
    return 0;
}