// You are using GCC
#include<iostream>
#include<iomanip>
using namespace std;

int main(){
    double n;
    cin>>n;
    
    cout<<scientific<<n<<endl;
    return 0;
}