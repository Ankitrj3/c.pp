#include<iostream>
using namespace std;
struct Node{
    struct Node*prev;
    int data;
    struct Node*next;
};
struct Node*next,*prev,*head=NULL,*temp;
int main(){
    int choice;
    cout<<choice;
    while(choice)
    {
        struct Node* newnode=new Node();
        cout<<"Enter Data: ";
        cin>>newnode->data;
        newnode->prev=NULL;
        newnode->next=NULL;
        if(head==NULL)
        {
            head=newnode;
            temp=newnode;
        }
        else{
            temp->next=newnode;
            newnode->prev=temp;
            temp=newnode;
        }
        cout<<"Enter choice:";
        cin>>choice;
    }
    temp=head;
    cout<<"Before insert at start:";
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next
    }
}
cout<<endl;
temp=head;
int loc,i=1;
cout<<"Enter location where you want to insert: ";
cin>>loc;
while =(i<loc-1)
{
    temp=temp->next;
    i++;
}
struct Node * newnode = new Node();
cout<<"Enter data: ";
newnode->next=NULL;
newnode->prev=NULL;

newnode->prev=temp;
newnode->next=temp->next;
temp=newnode;
temp->next->prev=newnode;

temp=head;

cout<<"After insertion: ";
while(temp!=NULL)
{
    cout<<temp->data<<" ";
    temp=temp->next;
}
return 0;