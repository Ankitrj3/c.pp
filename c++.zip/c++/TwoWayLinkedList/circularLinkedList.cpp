#include<iostream>
using namespace std;
struct Node{
    struct Node * prev;
    int data;
    struct Node*next;
};
struct Node * head, * temp;
int main(){
    int choice;
    cout<<"Enter your choice"<<endl;
    cin>>choice;
    while(choice)
    {
        struct Node * newnode =new Node();
        cout<<"Enter data: ";
        cin>>newnode->data;
        newnode->next=NULL;
        newnode->prev=NULL;
        if(head==NULL)
        {
            head=newnode;
            temp=newnode;
        }
        else{
            temp->next=newnode;
            newnode->prev=temp;
            newnode->next=head;
            head->prev = newnode;
            temp=newnode;
        }
        cout<<"Do you want to continue: ";
        cin>>choice;
    }
    temp=head;
    int count=0;
    while(temp!=head->prev)
    {
        cout<<temp->data<<" ";
        count++;
        temp= temp->next;
    }
    // cout<<temp->data<<" ";
    //  temp=head;
    // struct Node * headernode = new Node();
   
    // headernode->data=count;
    // headernode->next=head;
    // headernode->prev=NULL;
    // while(temp->next!=head)
    // {
    //     cout<<temp->data<<" ";
    //     temp=temp->next;
    // }
    return 0;
}