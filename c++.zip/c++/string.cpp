#include<iostream>
#include<string>
using namespace std;

int main(){
           string name="ankit ranjan";
           cout<<"your name is "<<name<<endl;

           cout<<"your length of string is "<<name.length()<<endl;
           cout<<"your substring of string is "<<name.substr(1,6);
}