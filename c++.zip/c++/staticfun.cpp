
// static function
#include<iostream>
using namespace std;

class Test{
  private:
     int code;
     int static count;

      void setcode(){
        code=++count;
      }
      void showcode(){
        cout<<"object number : " <<code<<endl;
      }
      void static showcount(){
        cout<<"object count:"<<count<<endl;
      }
};


int Test :: count;

int main(){
    Test t1,t2,t3;
    t1.setcode();
    t2.setcode();
    t3.setcode();

    // Test :: showcount();
    // Test t3;
    // T3.setcode();


    Test :: showcount();//calling the function to print to print number of object 
    t1.showcode();
    t2.showcode();
    t3.showcode();

    return 0;
}