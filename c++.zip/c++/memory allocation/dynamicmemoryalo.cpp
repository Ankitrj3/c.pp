#include<iostream>
using namespace std;

int main(){
     int *a;
     int n;
     cout<<"enter the size of memory allocated\n";
     cin>>n;
     a=new int[n];

     if(a==NULL){
        cout<<"Memory is not allocated\n";
        exit(1);
     }else{
        cout<<"enter data in memory\n";
        for(int i=0 ; i<n ; i++){
            cin>>*(a+i);
        }
        cout<<"data in memory\n";
        for(int i=0 ; i<n ; i++){
            cout<<*(a+i)<<" ";
        }
        delete []a;
     }
    return 0;
}