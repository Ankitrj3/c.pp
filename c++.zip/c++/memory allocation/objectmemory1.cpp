#include<iostream>
using namespace std;

class student{
    int rollno;
    string name;
    float marks;
    public:
    void getdata(){
        cin>>rollno;
        cin>>name;
        cin>>marks;
    }
    void putdata(){
        cout<<rollno<<endl;
        cout<<name<<endl;
        cout<<marks<<endl;
    }
};

int main(){
    
    student *p = new student;
    cout<<"how much object u want to create\n";
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        p[i].getdata();
    }
    for(int i=0; i<n; i++){
        p[i].putdata();
    }
    
   
    delete [] p;
    return 0;
}