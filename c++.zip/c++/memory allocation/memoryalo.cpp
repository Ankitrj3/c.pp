#include<iostream>
using namespace std;

int main(){
    int *p= new int[5];
    *p = 10;
    *(p+1)=20;
    *(p+2)=30;
    *(p+3)=40;
    *(p+4)=50;

    cout<<*p<<endl;
    cout<<*(p+1)<<endl;
      cout<<*(p+2)<<endl;
        cout<<*(p+3)<<endl;
          cout<<*(p+4)<<endl;

    // for(int i=0; i<5; i++){
    //     cout<<*(p++)<<endl;
    // }
       
       delete []p;
       return 0;

}