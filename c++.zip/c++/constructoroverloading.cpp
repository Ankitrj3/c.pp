#include<iostream>
#include<cctype>
#include<string>

using namespace std;

class student{
    int roll;
    string name;
public:
    //  student(){
    //      roll = 0;
    //      name ="";
    //  }
     student (int r,string s){
         roll = r;
         name = s;
     }
     void display(){
         cout<<"roll no "<<roll<<endl;
         cout<<"name "<<name<<endl;
     }
};

int main(){
    student s1(10,"rahul");
    // student s2;
    s1.display();
    // s2.display();
    return 0;
}