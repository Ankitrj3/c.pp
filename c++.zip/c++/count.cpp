// You are using GCC
// counting the even numbers of square like 12 x 12 =0, 44 x 44 =1
#include<iostream>
using namespace std;

inline int countEvenNumbers(int num){
    int count=0;
    int sq = num*num;
    
    while(sq>0){
        int digit = sq%10;
        if(digit%2==0){
            count++;
        }
        sq /=10;
    }
    return count;
}

int main(){
    int num;
    cin>>num;
    
    int evencount = countEvenNumbers(num);
    
    cout<<evencount;
    
    return 0;
}