#include<iostream>
using namespace std;
int main(){

    // for (int i=1; i<=3; i++){
    //     for(int j=1; j<=6; j++){
    //         cout<<"*";
    //     }
    //     cout<<endl;
         //it will print like 
                   //******
                   //******
                   //******
    
     
    
   // }
    
    //user input pattern
    // int n,m;
    // cin>>n;
    // cin>>m;

    // for(int i =1 ; i<=n; i++){
    //     for(int j =1; j<=m; j++){
    //         cout<<"$";
    //     }cout<<endl;
    // }


    //hoolow rectriangle

    // int a,b;
    // cin>>a;
    // cin>>b;
    // for(int i=1; i<=a; i++){
    //     for(int j=1; j<=b; j++){
    //         if(i==1 || j==1 || j==b || i==a){
    //             cout<<"*";
    //         }else{
    //             cout<<" ";
    //         }
    //     }cout<<endl;
    // }

   


    // triangular pattern
    // *
    // **
    // ***
    // ****

    // int a;
    // cin>>a;
    // for (int i=1;i<=a; i++){
    //     for(int j=1; j<=i; j++){
    //         cout<<"#";
    //     }
    //     cout<<endl;
    // }



     //***
    // **
    // *

    // int a;
    // cin>>a;
    // for(int j=1;j<=a;j++){
    //     for(int i=1; i<=a-j+1; i++){
    //         cout<<"*";
    //     }cout<<endl;
    // }  

    // triangle



    int a;
    cin>>a;
    for(int i=1; i<=a; i++){
        for(int j=1; j<=(a-i); j++){
            cout<<" ";
        }
        for(int j=1; j<=(2*i-1); j++){
            cout<<"*";
        }
    }cout<<endl;


     return 0;
    }