#include<iostream>
#include<string>
using namespace std;

int main(){
    string s1,s2,s3;
    getline(cin,s1);
    getline(cin,s2);
    getline(cin,s3);
    
    
    
    if(s1.find(s2)!=string::npos){
    s1.replace(s1.find(s2),s2.length(),s3);
    }
    cout<<s1;
    
    return 0;
}