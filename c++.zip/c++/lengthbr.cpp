#include<iostream>
using namespace std;
class l{
    public:
          int l;
          
};
int main(){
    l a;
    
    
    cout<<a.l;
}