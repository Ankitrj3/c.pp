#include<iostream>
using namespace std;

int a =21;//global

int main(){
    int a=89;//LOCAL

    cout<<a<<endl;//local variable calling 
    cout<<::a;//global variable calling
}