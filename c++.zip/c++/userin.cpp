#include<iostream>
using namespace std;

int main(){
int a,b;

cout<<"enter the number to add the two numbers"<<endl;

cout<<"enter 1st number"<<endl;
cin>>a;

cout<<"enter 2nd number"<<endl;
cin>>b;

cout<<"the sum of two numbers is"<<a+b;

}