// #include<iostream>
// using namespace std;
// class item{
//     int number;
//     static int count;
// public:
//      void getdata(int a){
//        number = a;
//        count ++;
//      }
//      void getcount(){
//         cout<<"count:"<<count<<endl;

//      }

// };

// int item:: count;//this is separate variable //called by the class

// int   main(){
//     item a,b,c;
//     a.getcount();
//     b.getcount();
//     c.getcount();

//     a.getdata(200);
//     b.getdata(300);
//     c.getdata(400);
     
//     a.getcount();
//     b.getcount();
//     c.getcount();


// }


