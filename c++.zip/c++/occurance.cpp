// #include<iostream>
// #include<string>
// using namespace std;
// int main(){
//   char str[40],search;
//   int i , count;

//   cout<<"enter any string\n";
//   cin>>str;
//   cout<<"enter any character by which you can find the number of occurance\n";
//   cin>>search;

//   while(str[i]!='\0'){
//     if(str[i]==search){
//       count++;
//     }
//     i++;
//   }
//   cout<<"total occurance of\t";
//   cout<<count;
// }

// You are using GCC
#include<bits/stdc++.h>
#include<string>

using namespace std;

int main(){
    
    string name;
    char target;
    cin>>name;
    cin>>target;
    int count=0;
    
    for(int i=0; i<name.length(); i++){
        if(name[i]==target){
            count++;
        }
    }
    cout<<count;
}