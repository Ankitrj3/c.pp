#include<iostream>
using namespace std;

class st{
    public:
    string ss;
    string kk;
    void getdata(string str ,string str1){
        ss=str;
        kk=str1;
    }
    st operator*(int n){
        string temp,temp1;
        temp = ss;
        temp1=kk;

        for(int i=1; i<n; i++){
            ss+=temp;
            kk+=temp1;
        }
        return *this;
    }
    void put(){
        cout<<ss;
        cout<<kk;
    }
};

int main(){
    st s,s1;
    string str,str1;
    cin>>str;
    cin>>str1;
    int n;
    cin>>n;
    
    s.getdata(str,str1);
    s1=s*n;
    s1.put();
    return 0;
}