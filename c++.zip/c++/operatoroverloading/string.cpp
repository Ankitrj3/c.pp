// Help Aashiq solve the following problem: Create a program that performs string operations using a custom class called MyString.



// The program should read two strings and a number from the user, and then perform concatenation and repetition operations on those strings using overloaded operators. Finally, it should display the results.



// Note: This question helps in clearing HCL tests.

// Input format :
// The input consists of two strings: str1 and str2 in separate lines.

// The last line of the input consists of the number of repetitions, n.

// Output format :
// The output prints the following in each line:

// a) The concatenated string of first and second.

// b) The first string that is repeated n times.

// c) The second string that is repeated n times.

// Code constraints :
// The maximum length of each input string is 100 characters.

// 1 <= n <= 10

// Sample test cases :
// Input 1 :
// Hello
// helllooo
// 5
// Output 1 :
// Hellohelllooo
// HelloHelloHelloHelloHello
// helllooohelllooohelllooohelllooohelllooo
// Input 2 :
// Today
// Today
// 5
// Output 2 :
// TodayToday
// TodayTodayTodayTodayToday
// TodayTodayTodayTodayTodayHelp Aashiq solve the following problem: Create a program that performs string operations using a custom class called MyString.



// The program should read two strings and a number from the user, and then perform concatenation and repetition operations on those strings using overloaded operators. Finally, it should display the results.



// Note: This question helps in clearing HCL tests.

// Input format :
// The input consists of two strings: str1 and str2 in separate lines.

// The last line of the input consists of the number of repetitions, n.

// Output format :
// The output prints the following in each line:

// a) The concatenated string of first and second.

// b) The first string that is repeated n times.

// c) The second string that is repeated n times.

// Code constraints :
// The maximum length of each input string is 100 characters.

// 1 <= n <= 10

// Sample test cases :
// Input 1 :
// Hello
// helllooo
// 5
// Output 1 :
// Hellohelllooo
// HelloHelloHelloHelloHello
// helllooohelllooohelllooohelllooohelllooo
// Input 2 :
// Today
// Today
// 5
// Output 2 :
// TodayToday
// TodayTodayTodayTodayToday
// TodayTodayTodayTodayToday

// You are using GCC
#include<iostream>
#include<string>
#include<cstring>

using namespace std;

class snum{
    char x[1000];
    char y[1000];
   
    public:
    
    void getdata(char * a, char * b){
        strcpy(x,a);
        strcpy(y,b);
       
    }
    snum operator*(int num){
        char temp[1000];
        char temp1[1000];
        strcpy(temp,x);
        strcpy(temp1,y);
        
        for(int i=1;i<num;i++){
            strcat(x,temp);
            strcat(y,temp1);
        }
        return *this;
    }
    void display(){
    cout<<x<<endl;
    cout<<y<<endl;
    }
};

int main(){
    char a[1000];
    char b[1000];
    int num;
    cin>>a;
    cin>>b;
    cin>>num;
    cout<<a<<b<<endl;
    snum ob1,ob2;
    ob1.getdata(a,b);
    ob2=ob1*num;
    ob2.display();
    
    return 0;
}