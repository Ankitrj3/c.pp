#include<iostream>
#include<string>
#include<cstring>
using namespace std;
class String{
    char a[1000];
    public:
       void getdata(char *s){
        strcpy(a,s);
       }
    
    void putdata(){
        cout<<"string="<<a<<endl;
    }

    String operator+(String t){
        strcat(a,t.a);
        return *this;
    }

};

int main(){
    String ob1,ob2,ob3;
    ob1.getdata("happy");
    ob2.getdata("birthday");

    ob3 = ob1+ob2;

    ob1.putdata();
    ob2.putdata();
    ob3.putdata();
}