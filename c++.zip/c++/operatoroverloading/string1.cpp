// In a magical realm, a talented wizard named Merlin crafted a magnificent RepeatableString class with the enchanting ability to replicate strings using the * operator.



// One day, a curious adventurer named Arthur discovered Merlin's creation and decided to test its magical powers. Arthur entered a captivating string into the console and chose a magical number of repetitions.



// As the * operator worked its charm, the string multiplied and unfolded into an extraordinary sequence. Arthur marveled at the operator overloading concept, realizing its potential to create spellbinding patterns and unleash the magic of repetition in their incredible quests through the mystical lands.



// Note: The program has to be implemented using the character array.

// Input format :
// The input consists of a string, followed by the number of repetitions.

// Output format :
// The output displays the result of repeating the input string as per the given number of repetitions.



// Refer to the sample output for further formatting specifications.

// Code constraints :
// The input string can contain any printable ASCII characters except for '\0' (null character).
// The maximum length of the input string is 100 characters.
// The number of repetitions should be a non-negative integer.
// Sample test cases :
// Input 1 :
// this
// 4
// Output 1 :
// Result: thisthisthisthis
// Input 2 :
// S
// 6
// Output 2 :
// Result: SSSSSS

// You are using GCC
#include<iostream>
#include<string>
#include<cstring>

using namespace std;

class ss{
    char x[1000];
    public:
    void getdata(char * a){
        strcpy(x,a);
    }
    ss operator*(int n){
        char temp[1000];
        strcpy(temp,x);
        
        for(int i=1;i<n;i++){
            strcat(x,temp);
        }
        return *this;
    }
    void display(){
        cout<<"Result:"<<x;
    }
};

int main(){
    char a[1000];
    cin>>a;
    int n;
    cin>>n;
    
    ss ob1,ob2;
    ob1.getdata(a);
    ob2 = ob1*n;
    ob2.display();
    return 0;
}