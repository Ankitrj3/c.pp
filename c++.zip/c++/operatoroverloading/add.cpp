#include<iostream>
using namespace std;

class add{
    int x;
    public:
    void getdata(int a){
        x=a;
    }
    add operator+(add t){
        add temp;
         temp.x =x + t.x;
        return temp;
    }
    void putdata(){
        cout<<x;
    }
};

int main(){
    int x;
    int y;
    cin>>x;
    cin>>y;
    
    add a1,a2;
    a1.getdata(x);
    a2.getdata(y);
    add a3 = a1+a2;
    a3.putdata();
    
    
    
    
    return 0;
}