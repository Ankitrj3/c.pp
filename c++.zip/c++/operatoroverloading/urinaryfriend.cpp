#include<iostream>
using namespace std;

class Number{
    int x,y,z;
public:
    Number(int n, int n1, int n2){
        x=n; y=n1; z=n2;
    }

    friend void operator++(Number& ob);//only one parameter we need to define address of object defined

    void show_data(){
        cout<<"\n x="<<x<<"\n";
        cout<<"\n y="<<y<<"\n";
        cout<<"\n z="<<z<<"\n";
    }
};
void operator++(Number& ob){
        ++ob.x; ++ob.y; ++ob.z;
    };
int main(){
    Number N(7,8,9);
    N.show_data();
    ++N;//N.operator++();
    N.show_data();
    return 0;
}