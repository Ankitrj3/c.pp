#include<iostream>
using namespace std;

class complex{
    int real,img;
    public:
        complex(){
            real=0;
            img=0;
        }
        complex(int x, int y){
            real=x; img=y;
        }
        friend complex operator+(complex ob1, complex ob2);
        void show_data(){
            cout<<real<<"+j"<<img<<"\n";
        }
};
complex operator+(complex ob1, complex ob2){
            complex temp;
             temp.real = ob1.real+ob2.real;
             temp.img = ob1.img+ob2.real;
             return temp;
        }
int main(){
    complex ob1(1,2),ob2(3,5),ob3;
    ob1.show_data();
    ob2.show_data();

    ob3=ob1+ob2;
    ob3.show_data();
     
     return 0;
}