#include<iostream>
using namespace std;

class complex {
    int real, img;
public:
    complex() {
        real = 0;
        img = 0;
    }

    complex(int x, int y) {
        real = x;
        img = y;
    }

    complex operator+(complex t) {
        // complex temp;
        int r = real + t.real;
        int i = img + t.img;
        return complex(r,i);
    }

    void show_data() {
        cout << real << "+j" << img << "\n";
    }
};

int main() {
    complex ob1(1, 2), ob2(3, 5), ob3;
    ob1.show_data();
    ob2.show_data();

    ob3 = ob1 + ob2;
    ob3.show_data();

    return 0;
}
