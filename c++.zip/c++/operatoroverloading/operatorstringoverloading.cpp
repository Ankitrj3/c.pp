#include<iostream>
#include<string>
#include<cstring>
using namespace std;
class String{

    char a[1000];
    public:
     void getdata(char *s){
        strcpy(a,s);
     }
     void putdata(){
        cout<<"stirng="<<a<<endl;
     }
     String operator*(int n)
     {
        char temp[100];
        strcpy(temp , a);
        for(int i=1; i<n; i++){
            strcat(a,temp);
        }
        return *this ;
     }
};

int main(){
int n;
char k[20];
cin>>k;
cin>>n;
    String ob1,ob2;
    ob1.getdata(k);
    ob2=ob1*n;
    ob2.putdata();
}

// alternative code by using string

// #include<iostream>
// #include<string>
// #include<cstring>
// using namespace std;

// class smul{
//     string a;
//     public:
//     void getdata(string b){
//         a=b;
//     }
//     void putdata(){
//         cout<<"the string = "<<a;
//     }
//     smul operator*(int n){
//         string temp=a;
//         ;
//         for(int i=1;i<n;i++){
//             a+=temp;
//         }
//         return *this;
//     }
// };
// int main(){
//     string b;
//     int n;
//     cout<<"enter the string\n";
//     getline(cin,b);
//     cout<<"enter the ouccrance how time u want to repeat the string\n";
//     cin>>n;
    
//     smul ob1,ob2;
    
//     ob1.getdata(b);
//     ob2 = ob1*n;
//     ob2.putdata();
    
//     return 0;
// }