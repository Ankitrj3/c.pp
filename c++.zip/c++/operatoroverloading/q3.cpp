
// Once upon a time in a quaint village, there lived a brilliant young programmer named Alice. She was fascinated by the magical world of Programming and decided to create her very own class called CustomString.



// This class had a special power - whenever the ++ operator was applied, it would transform the first letter of the input string into a majestic capital letter. One day, a curious traveler arrived in the village, and Alice eagerly demonstrated the power of her CustomString class.



// The traveler was amazed by the enchanting customization and couldn't help but smile as the modified string was displayed, adding a touch of magic to their conversation.

// Input format :
// The input consists of a string consisting of alphanumeric characters (both uppercase and lowercase) and symbols.



// Refer to the sample input for further formatting specifications.

// Output format :
// The program should display the original and modified strings on separate lines.



// Refer to the sample output for further formatting specifications.

// Code constraints :
// The input string will contain at most 100 characters.

// The input string may consist of spaces, special symbols, and alphanumeric characters.

// The first character of the string may be uppercase or lowercase.

// Sample test cases :
// Input 1 :
// hello World!
// Output 1 :
// Original string: hello World!
// Modified string: Hello World!
// Input 2 :
// Apple
// Output 2 :
// Original string: Apple
// Modified string: Apple
// Input 3 :
// $10000
// Output 3 :
// Original string: $10000
// Modified string: $10000


#include <iostream>
#include <string>
using namespace std;

class CustomString {
private:
    string str;

public:
    CustomString(const string& s) : str(s) {}

    CustomString operator++() {
        if (!str.empty()) {
            str[0] = toupper(str[0]);
        }
        return *this;
    }

    void display() {
        cout  << str << endl;
    }
};

int main() {
    string input;
    getline(cin, input);
    cout<<"Original string: "<<input<<endl;
    CustomString customStr(input);
    
    cout << "Modified string: ";
    ++customStr; 
    customStr.display(); 

    return 0;
}
