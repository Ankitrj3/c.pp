#include<iostream>
using namespace std;

int main(){
    int a,b;
    int c,d;
    
    cin>>a>>b;
    cin>>c>>d;
    
    int x = b/a;
    int y = d/c;
    int k = a/b;
    int j = c/d;
    
    int m=k*j;
    int z=x*y;
    
    if(k==0 && j==0){
        cout<<1<<"/"<<z;
    }else{
         cout<<m<<"/"<<z;
    }
    
   
    
    
}