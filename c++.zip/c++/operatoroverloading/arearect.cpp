#include<iostream>
using namespace std;

class rect{
    int a,b;
    public:
    void getdata(int x,int y){
        this->a=x;
        this->b=y;
    }
    void putdata(){
        int res = a*b;
        cout<<res;
    }
    int operator==(rect t){
        if(this->a==t.a && this->b==t.b){
            return 1;
        }else{
            return 0;
        }
    }
};

int main(){
    rect ob1,ob2;
    int x,y,r,z;
    cin>>x>>y;
    cin>>r>>z;
    ob1.getdata(x,y);
    ob2.getdata(r,z);
    
    if(ob1==ob2){
        cout<<"both rect is same\n";
    }else{
        cout<<"both rect is different\n";
    }
    cout<<"rect 1 area";
    ob1.putdata();
    cout<<"rect 2 area";
    ob2.putdata();
    return 0;
}