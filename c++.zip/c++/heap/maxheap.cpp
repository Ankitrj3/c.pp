#include<iostream>
#include<string>
using namespace std;

int main(){
    
    string n;
    cin>>n;
    char k;
    cin>>k;

    for(int i=0; i<n.length(); i++){
        if(n[i]==k){
            cout<<i<<" ";
        }
    }

    return 0;
}