// Madhu is tasked with developing a program to calculate the total price and discount for a list of discounted items. Each item has the following details:



// Create a base class called ItemDetails that has a method called getDetails(). This method contains details about the name, item number, and price.



// Create a class DiscountedItem that is derived from the class ItemDetails. This class stores the discount percentage and the discounted price of the item.



// A customer purchases n items. Write a program to display the item-wise bill and total amount. The program should also display the total price of all items and the total discount amount.



// Note: This kind of question will help in clearing TCS recruitment.

// Input format :
// The input format consists of the following:



// The first line contains an integer n, representing the number of items.

// For each item, there are three lines of input:

// The first line contains a string name, representing the name of the item.

// The second line contains an integer itemNumber, representing the item number.

// The third line contains a float price, representing the price of the item.

// The fourth line contains a float discountPercent, representing the discount percentage for the item.

// Output format :
// The output format consists of the following:



// The item-wise bill, which includes the details of each item, such as the item name, item number, item price, discount percentage, and discounted price,

// After the item-wise bill, there are two lines:

// The first line displays the total price of all items, rounded to two decimal places.

// The second line displays the total discount amount for all items, rounded to two decimal places.



// Refer to the sample output for the formatting specifications.

// Code constraints :
// The number of discounted items (n) will be between 1 and 1000, inclusive.

// The length of the item name will be between 1 and 100 characters, inclusive.

// The item number will be between 1 and 1,000,000, inclusive.

// The item price will be between 0.01 and 1,000,000, inclusive.

// The discount percentage will be between 0.0 and 100.0, inclusive.

// Sample test cases :
// Input 1 :
// 2
// Pen
// 012
// 120
// 2
// Book
// 023
// 560
// 5
// Output 1 :
// Item-wise bill:
// Item name: Pen
// Item number: 12
// Item price: 120
// Discount percent: 2%
// Discounted price: 117.6
// Item name: Book
// Item number: 23
// Item price: 560
// Discount percent: 5%
// Discounted price: 532

// Total price: 680
// Total discount: 30.4

// You are using GCC
#include<iostream>
using namespace std;

class ItemDetails{
    public:
    string name;
    int itemnum;
    float price;
    
    void getDetails(){
        cin>>name;
        cin>>itemnum;
        cin>>price;
    }
};

class DiscountedItem : public ItemDetails {
    public:
    float dis;
    float discount;
    float finalprice;
    void getDiscount(){
        cin>>dis;
        discount = (price*dis)/100;
        finalprice = price-discount;
    }
    void display(){
        cout<<"Item name: "<<name<<endl;
        cout<<"Item number: "<<itemnum<<endl;
        cout<<"Item price: "<<price<<endl;
        cout<<"Discount percent: "<<dis<<"%"<<endl;
        cout<<"Discounted price: "<<finalprice<<endl;
        cout<<"                    "<<endl;
        
    }
};
class total : public DiscountedItem {
    public:
        int total=0;
        float tdis=0;
       void t(){
        cout<<"Total price: "<<total<<endl;
        cout<<"Total discount: "<<tdis;
    }
};
int main(){
    int k;
    cin>>k;
    
    cout<<"Item-wise bill:\n";
    total d;
    for(int i=0; i<k; i++){
        d.getDetails();
        d.getDiscount();
        d.display();
        d.total+=d.price;
        d.tdis+=d.discount;
    }
    d.t();
}

