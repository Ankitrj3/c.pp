// It is time to file our tax returns. All our tax return forms have various sections or parts to them. You are tasked with creating an object-oriented way of representing the different parts of our tax forms. You have to use the same class names as provided below.



// class partA: This consists of the income tax filer's name and PAN number.



// class partB: This consists of partA along with two important inputs, which are the gross salary and income from other sources of the filer.



// class partC: This consists of partA along with the various deductions that the filer can have.



// class taxComp: This consists of partB and partC as this is the class where the final tax is calculated. The tax is calculated at 30% on the sum of inputs in partB after deducting partC from it.



// You should get the necessary inputs for all these classes from the user and calculate the taxable income and the final tax amount to be paid by the filer.



// Before printing the details, you should show the sequence in which the constructors of each part are being called, and once the details of the tax are printed, you should show the sequence of the destructors of each part are being called.

// Input format :
// The first line consists of the name of the filer.

// The second line consists of the pan details for the filer.

// The third line consists of the gross salary.

// The fourth line consists of income from other sources.

// The fifth line consists of the deductions.

// Output format :
// The output shall show the constructor sequence first, followed by the various inputs provided by the user, along with the taxable income and tax calculated.



// It will then show the sequence in which the destructors are being called for the various classes.



// Refer to the sample output for exact specifications.

// Sample test cases :
// Input 1 :
// ABC
// ABDPD534HF
// 10000
// 10000
// 5000
// Output 1 :
// Creating partA
// Creating partB
// Creating partC
// Creating taxComp
// Account Holder Name: ABC
// PAN: ABDPD534HF
// Gross Salary: 10000
// Income from Other Sources: 10000
// Deductions: 5000
// Taxable Income (computed): 15000
// Tax Payable (computed): 4500
// Deleting taxComp
// Deleting partC
// Deleting partB
// Deleting partA

// You are using GCC
#include<iostream>
using namespace std;

class partA{
    public:
    string name;
    string pan;
    partA(){
        cout<<"Creating partA\n";
        cin>>name;
        cin>>pan;
    }
    ~partA(){
        cout<<"Deleting partA\n";
    }
};
class partB : virtual public partA{
    public:
    int gross;
    int other;
    partB(){
        cout<<"Creating partB\n";
        cin>>gross;
        cin>>other;
    }
    ~partB(){
        cout<<"Deleting partB\n";
    }
};
class partC : virtual public partA{
    public:
    int dec;
    partC(){
        cout<<"Creating partC\n";
        cin>>dec;
    }
    ~partC(){
        cout<<"Deleting partC\n";
    }
};
class taxComp : public partB , public partC{
    public:
    taxComp(){
        cout<<"Creating taxComp\n";
    }
    void putdata(){
        int mainincome=gross+other;
        int sub=mainincome-dec;
        int pay=(sub*30)/100;
       cout<<"Account Holder Name: "<<name<<endl;
       cout<<"PAN: "<<pan<<endl;
       cout<<"Gross Salary: "<<gross<<endl;
       cout<<"Income from Other Sources: "<<other<<endl;
       cout<<"Deductions: "<<dec<<endl;
       cout<<"Taxable Income (computed): "<<sub<<endl;
       cout<<"Tax Payable (computed): "<<pay<<endl;
    }
    
    ~taxComp(){
        cout<<"Deleting taxComp\n";
    }
};
int main(){
    taxComp t;
    t.putdata();
    
    return 0;
}