// In this scenario, we're creating a program to manage a vehicle fleet for a car rental company. The fleet includes cars and bicycles, each with specific attributes like brand; for cars, the number of doors; and for bicycles, the number of gears. To keep our code organized, we use a virtual base class named Vehicle.



// The program allows users to add new vehicles to the fleet, capturing brand and relevant details. It can also display comprehensive information about all fleet vehicles, including brand, type (car or bicycle), and specific attributes.



// The virtual base class, Vehicle, ensures a clean inheritance structure for Car and Bicycle classes. Input validation is in place to handle errors, and the program efficiently manages the diverse fleet of vehicles while promoting code reusability and maintainability.

// Input format :
// The first line of the input consists of a string representing the car brand.

// The second line consists of an integer representing the number of doors in the car.

// The third line consists of a string representing the bicycle brand.

// The last line consists of an integer representing the number of gears in a bicycle.

// Output format :
// The first line of the output displays the car brand.

// The second line displays the number of doors in the car.

// The third line displays the bicycle brand.

// The last line displays the number of gears in a bicycle.



// Refer to the sample output for the formatting specifications.

// Code constraints :
// The test cases will fall under the following constraints:

// Length of string <= 20

// 1 <= number of doors <= 10

// 1 <= Number of gears <= 10

// Sample test cases :
// Input 1 :
// Toyota
// 5
// Yamaha
// 6
// Output 1 :
// Brand: Toyota
// Number of Doors: 5
// Brand: Yamaha
// Number of Gears: 6
// Input 2 :
// Hyundai
// 4
// Bajaj
// 4
// Output 2 :
// Brand: Hyundai
// Number of Doors: 4
// Brand: Bajaj
// Number of Gears: 4

// You are using GCC
#include <iostream>

using namespace std;

class car{
    public:
    string name;
    int doors;
    void getdata(){
        cin>>name;
        cin>>doors;
    }
};
class bike : public car{
    public:
    string name1;
    int gear;
    void get(){
        cin>>name1;
        cin>>gear;
    }
    void dis(){
        cout<<"Brand: "<<name<<endl;
        cout<<"Number of Doors: "<<doors<<endl;
        cout<<"Brand: "<<name1<<endl;
        cout<<"Number of Gears: "<<gear;
    }
};

int main(){
    bike b;
    b.getdata();
    b.get();
    b.dis();
    return 0;
}