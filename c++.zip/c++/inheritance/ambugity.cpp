#include<iostream>
using namespace std;

class A{
    public:
    void show(){
        cout<<"hello mr ankit\n";
    }
};
class B{
    public:
    void show(){
        cout<<"hello world\n";
    }
};
class C : public A,public B{
    public:
    void dis(){
        cout<<"hi\n";
    }
};

int main(){
    C c1;
    c1.dis();
    c1.A::show();
    c1.B::show();
    
    return 0;
}