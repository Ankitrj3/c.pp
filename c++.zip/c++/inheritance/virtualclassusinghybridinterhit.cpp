#include<iostream>
using namespace std;

class student {
    int roll;
    public:
    void get(int a){
        roll=a;
    }
    void put(){
        cout<<"the roll number is "<<roll;
    }
};

class marks: virtual public student{
    public:
    int marks1;
    int marks2;
    void getmarks(int a,int b){
        marks1=a;
        marks2=b;
    }
    void dis(){
        cout<<"marks for sub1 "<<marks1<<endl;
        cout<<"marks for sub2 "<<marks2<<endl;
    }  
};

class sports : virtual public student{
    public:
    int score;
    void getdata(int k){
        score = k;
        cout<<"the cricket score is "<<score<<endl;
    }
};

class result : public marks , public sports{
     int total;
     public:
     void total1(){
         total = marks2+marks1+score;
         cout<<"total marks "<<total<<endl;
     }
};

int main(){
    result r;
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    
    r.get(a);
    r.put();
    r.getmarks(b,c);
    r.dis();
    r.getdata(d);
    r.total1();
    return 0;
}