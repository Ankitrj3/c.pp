// It is time to file our tax returns. All our tax return forms have various sections or parts to them. You are tasked with creating an object-oriented way of representing the different parts of our tax forms. You have to use the same class names as provided below.



// class partA: This consists of the income tax filer's name and PAN number.

// class partB: This consists of partA along with two important inputs, which are the gross salary and income from other sources of the filer.

// class partC: This consists of partA along with the various deductions that the filer can have.

// class taxComp: This consists of partB and partC as this is the class where the final tax is calculated. The tax is calculated at 30% on the sum of inputs in partB after deducting partC from it.



// You should get the necessary inputs for all these classes from the user and calculate the taxable income and the final tax amount to be paid by the filer.

// Input format :
// The first line consists of the name of the filer.

// The second line consists of the pan details for the filer.

// The third line consists of the gross salary.

// The fourth line consists of income from other sources.

// The fifth line consists of the deductions.

// Output format :
// The output displays the various inputs provided by the user, along with the taxable income and tax calculated.



// A new line space is printed after the last statement in the output.



// Refer to the sample output for the formatting specifications.

// Sample test cases :
// Input 1 :
// ABC
// ABDPD534HF
// 10000
// 10000
// 5000
// Output 1 :
// Income Tax Calculation
// Account Holder Name: ABC
// PAN: ABDPD534HF
// Gross Salary: 10000
// Income from Other Sources: 10000
// Deductions: 5000
// Taxable Income (computed): 15000
// Tax Payable (computed): 4500
// You are using GCC
#include<iostream>
using namespace std;

class partA{
    public:
    string name;
    string pan;
    
    void getdata(){
        cin>>name;
        cin>>pan;
    }
    
};

class partB : virtual public partA{
    public:
    int grossal;
    int othersal;
    void get(){
        cin>>grossal;
        cin>>othersal;
    }
};

class partC : virtual public partA{
    public:
    int deduct;
    void dec(){
        cin>>deduct;      
    }
};

class taxComp: public partB , public partC{
    public:
    int amount; 
    int mainamount;
    int maincomp;
    
    void display(){
     amount = grossal + othersal;
     mainamount = amount - deduct;
     maincomp = (mainamount*30)/100;
    
        
        cout<<"Income Tax Calculation\n";
        cout<<"Account Holder Name: "<<name<<endl;
        cout<<"PAN: "<<pan<<endl;
        cout<<"Gross Salary: "<<grossal<<endl;
        cout<<"Income from Other Sources: "<<othersal<<endl;
        cout<<"Deductions: "<<deduct<<endl;
        cout<<"Taxable Income (computed): "<<mainamount<<endl;
        cout<<"Tax Payable (computed): "<<maincomp<<endl;
    }
} ;

int main(){
    taxComp c;
    
    c.getdata();
    c.get();
    c.dec();
    c.display();
}