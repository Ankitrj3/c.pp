#include<iostream>
using namespace std;

class alpha{
    int i;
    public:
    alpha(int k){
        i=k;
        cout<<"alpha intialized\n";
    }
    void show_x(){
        cout<<"alpha is "<<i<<endl;
    }
};
class beta{
    int j;
    public:
    beta(int l){
        j=l;
        cout<<"beta intialized"<<endl;
    }
    void show_y(){
         cout<<"beta is "<<j<<endl;
    }
};

class gamma : public alpha , public beta{
    int m,n;
    public:
    gamma(int a , int b, int c, int d):alpha(a),beta(b){
            m=c;
            n=d;
            cout<<"gamma intailized\n";
    }
    void show_z(){
        cout<<"m= "<<m<<endl;
        cout<<"n= "<<n<<endl;
    }
};

int main(){
   gamma g(12,32,14,67);
   g.show_x();
   g.show_y();
   g.show_z();

   return 0;

}