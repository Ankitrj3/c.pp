#include<iostream>
using namespace std;

class a{
    public:
    a(){
        cout<<"\ncalling default base class constructor\n";
    }
    ~a(){
        cout<<"calling base class destructor\n";
    }
};
class b:public a{
    public:
    b(){
        cout<<"calling default derived constructor\n";
    }
    ~b(){
        cout<<"calling dervied class destructor\n";
    }
};

int main(){
    b ob1;
    return 0;

    return 0;
}