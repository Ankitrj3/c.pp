#include<iostream>
using namespace std;

class k{
    int x;
    public:
    int j;
    void dat(int a,int b){
        x=a;
        j=b;
    }
    void put(){
        return a;
    }
    void dis(){
        cout<<"value of a is"<<x;
    }
};
class fuc : public k{
    int n;
    public:
   
    void mul(){
        n=j*put();
    }
    void display(){
        cout<<"x"<<" "<<dis()<<endl;
        cout<<"j"<<" "<<j<<endl;
        cout<<"n"<<" "<<n<<endl;
    }
};

int main(){
    k k1;
    k1.dat(30,40);
    k1.dis();

    fuc f;
    f.dat(90,20);
    f.dis();
    f.mul();
    f.display();



    return 0;
}