#include<iostream>
using namespace std;

class student{
    protected:
    int roll;
    public:
    
    void getdata(int a){
        roll=a;
    }  
    void put(){
        cout<<"roll no "<<roll<<"\n";
    }
};
class test : public student{
    protected:
    int marks1;
    int marks2;
    public:
    void getmarks(int x, int y){
        marks1=x;
        marks2=y;
    }
    void putmarks(){
        cout<<"sub1 marks is "<<marks1<<endl;
        cout<<"sub2 marks is "<<marks2<<endl;
        cout<<"total "<<marks1+marks2;
    }
};

class result : public test{
};

int main(){
    int a,b,c;
    cin>>a>>b>>c;
    result r1;
    r1.getdata(a);
    r1.put();
    r1.getmarks(b,c);
    r1.putmarks();
    
    return 0;
}