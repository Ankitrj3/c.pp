#include<iostream>
using namespace std;

class M {
protected:
    int x;

public:
    void getdata(int m) {
        x = m;
    }
};

class N {
protected:
    int y;

public:
    void getn(int n) {
        y = n;
    }
};

class P : public M, public N {
public:
    void display() {
        cout << "value of m: " << M::x << endl;
        cout << "value of n: " << N::y << endl;
        cout << "value of m*n: " << M::x * N::y << endl;
    }
};

int main() {
    P p;
    p.getdata(23);
    p.getn(45);
    p.display();

    return 0;
}
