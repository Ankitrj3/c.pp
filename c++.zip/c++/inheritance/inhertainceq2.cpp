// Meera is working in a electronics store where she is given a task and she is required to create a program that manages electronic devices, specifically smartphones and laptops. Three classes are involved: Device (the base class), Smartphone, and Laptop. The order of execution of constructors and destructors is crucial.



// The Device class has a constructor to specify the device type and a destructor to display device destruction messages.
// The Smartphone class, inheriting from Device, constructs a smartphone with a specified brand and displays a corresponding destruction message upon disposal.
// Similarly, the Laptop class, also inheriting from Device, constructs a laptop with a specified brand and displays a destruction message upon recycling.


// In the main function, the program prompts users to input smartphone and laptop brands, creates instances of these devices, and showcases the proper order of constructor and destructor execution, providing a realistic simulation of device lifecycle management.

// Input format :
// The first line of the input consists of a string representing the phone brand.

// The second consists of a string representing the laptop brand.

// Output format :
// The output displays the order of execution of constructor and destructor with brand name.

// A new line space is printed after the last statement in the output.



// Refer to the sample output for the formatting specifications.

// Code constraints :
// Test cases will fall under the following constraints:

// Length of string <= 10

// Sample test cases :
// Input 1 :
// Redmi
// HP
// Output 1 :
// Device Constructor: Initializing a Smartphone
// Smartphone Constructor: Setting up Redmi smartphone
// Device Constructor: Initializing a Laptop
// Laptop Constructor: Booting up HP laptop
// Laptop Destructor: Shutting down HP laptop
// Device Destructor: Destroying a Laptop
// Smartphone Destructor: Turning off Redmi smartphone
// Device Destructor: Destroying a Smartphone

// You are using GCC
#include <iostream>
#include <string>

using namespace std;

class Device {
    //Type your code here
};

class Smartphone : public Device {
    //Type your code here
    public:
    string p;
    Smartphone(string phoneBrand){
        p=phoneBrand;
        cout<<"Device Constructor: Initializing a Smartphone\n";
        cout<<"Smartphone Constructor: Setting up "<<p<<" smartphone\n";
        
    }
    ~Smartphone(){
        cout<<"Smartphone Destructor: Turning off "<<p<<" smartphone\n";
        cout<<"Device Destructor: Destroying a Smartphone\n";
    }
    
};

class Laptop : public Device {
    //Type your code here
    public:
    string n;
    Laptop(string laptopBrand){
        n=laptopBrand;
        cout<<"Device Constructor: Initializing a Laptop\n";
        cout<<"Laptop Constructor: Booting up "<<n<<" laptop\n";
    }
    ~Laptop(){
        cout<<"Laptop Destructor: Shutting down "<<n<<" laptop\n";
        cout<<"Device Destructor: Destroying a Laptop\n";
        
    }
};

int main() {
    string phoneBrand, laptopBrand;

    cin >> phoneBrand;
    Smartphone myPhone(phoneBrand);

    cin >> laptopBrand;
    Laptop myLaptop(laptopBrand);

    return 0;
}
