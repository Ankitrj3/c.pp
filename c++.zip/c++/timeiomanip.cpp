#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int a = 4;
    int b = 4;

    cout << setw(2) << setfill('0') << a << ":";
    cout << setw(2) << setfill('0') << b;
    cout<<"\n";
    return 0;
}
