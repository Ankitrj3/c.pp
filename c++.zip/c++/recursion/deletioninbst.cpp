// Problem statement




// Alex, a computer science student, is working on a project related to binary search trees (BSTs) and needs to implement a program that deletes the root node of a BST.




// He wants to create a program to delete the root node of a given BST and display the in-order traversals.




// Help him to solve this problem.

// Input format :

// The first line of input consists of an integer, N, representing the number of nodes in the BST.

// The second line of input consists of N space-separated integers that represent the values of the BST nodes in the order they were inserted.

// Output format :

// If the root node is successfully deleted, the output will display the updated values of the BST in ascending order (in order).

// If the root node cannot be deleted (i.e., it's the only node in the tree), the program should display "Cannot Delete Root."




// Refer to the sample output for the formatting specifications.

// Code constraints :

// The given test cases will fall under the following constraints:




// The input values are unique integers.
// 1 <= n <= 20
// 1 <= value of node <= 1000
// Sample test cases :
// Input 1 :
// 3
// 10 25 35
// Output 1 :
// 25 35 
// Input 2 :
// 5
// 10 6 15 3 20

// Output 2 :
// 3 6 15 20 
// Input 3 :
// 8
// 15 10 20 5 12 18 25 4

// Output 3 :
// 4 5 10 12 18 20 25 
// Input 4 :
// 1
// 5
// Output 4 :
// Cannot Delete Root

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

// You are using GCC
#include <iostream>
#include <cstdlib> 
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
};

TreeNode* createNode(int value) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->val = value;
    newNode->left = nullptr;
    newNode->right = nullptr;
    return newNode;
}

TreeNode* insert(TreeNode* root, int value) {
    if (root == nullptr) {
        return createNode(value);
    }
    if (value < root->val) {
        root->left = insert(root->left, value);
    } else {
        root->right = insert(root->right, value);
    }
    return root;
}

TreeNode* deleteNode(TreeNode* root, int value)
{
    //Type your code
}

void inOrderTraversal(TreeNode* root) 
{
   //Type your code
}

int main() {
    int N;
    cin >> N;
    TreeNode* root = nullptr;

    for (int i = 0; i < N; i++) {
        int value;
        cin >> value;
        root = insert(root, value);
    }

    if (root->left == nullptr && root->right == nullptr) {
        cout << "Cannot Delete Root" << std::endl;
    } else {
        TreeNode* minRight = root->right;
        while (minRight->left != nullptr) {
            minRight = minRight->left;
        }

        root->val = minRight->val;
        root->right = deleteNode(root->right, minRight->val);
        inOrderTraversal(root);
    }

    return 0;
}
