// Alice is working on a project that requires sorting and displaying the frequency of elements in an array. She needs your help to write a program to sort an array of positive integers and display the elements sorted by frequency in descending order. If two elements have the same frequency, they should be sorted in ascending order of their values.



// For this project, your task is to implement the logic of the merge sort and a recursive function.

// Input format :
// The first line contains an integer n, representing the number of elements in the array.

// The second line contains n space-separated integers, arr[i].

// Output format :
// The output prints a single line containing the sorted elements of the array separated by spaces.

// Code constraints :
// max_n = 100

// 1 ≤ n ≤ 25

// 1 <= arr[i] <= 100

// Sample test cases :
// Input 1 :
// 6
// 1 1 2 3 3 3
// Output 1 :
// 3 3 3 1 1 2 
// Input 2 :
// 7
// 2 2 3 1 3 2 3
// Output 2 :
// 2 2 2 3 3 3 1 
// Input 3 :
// 6
// 1 2 3 1 2 3
// Output 3 :
// 1 1 2 2 3 3 