#include <iostream>
using namespace std;

// Function to find and print duplicate elements in a sorted array
int findAndPrintDuplicates(int arr[], int n, int prev) {
    // Base case: If the array has only one element, it cannot have duplicates
    if (n == 1) {
        if (arr[0] == prev) {
            cout << arr[0] << " ";
            return arr[0];
        }
        return -1;
    }

    // Recursive case
    int current = arr[n - 1];
    int result = findAndPrintDuplicates(arr, n - 1, current);

    // Check if the current element is a duplicate
    if (current == prev) {
        cout << current << " ";
        return current;
    }

    return result;
}

int main() {
    int n;
    //cout << "Enter the number of elements: ";
    cin >> n;

    int arr[n];

    //cout << "Enter " << n << " sorted elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int result = findAndPrintDuplicates(arr, n, -1);

    if (result == -1) {
        cout << "-1";
    }

    return 0;
}
