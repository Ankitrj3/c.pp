// At the "Fresh Mart" grocery store, they recently received a large shipment of various products, and they need to organize their inventory efficiently. They've hired you to help them sort the products in descending order based on their product IDs.



// Develop a program to aid the Fresh Mart team in organizing their inventory using a recursive function and implementing the merge sort logic. Each product in the store is identified by a distinct product ID, and the objective is to present the products to customers in descending order.

// Input format :
// The first line consists of an integer, n, representing the number of products in the inventory.

// The next line consists of n space-separated integers, each representing a unique Product ID.

// Output format :
// The output displays a single line containing the Product IDs sorted in descending order, separated by spaces.

// Code constraints :
// 1 ≤ n ≤ 10

// 1 ≤ Product ID ≤ 1000

// Sample test cases :
// Input 1 :
// 5
// 1 9 7 6 8
// Output 1 :
// 9 8 7 6 1 
// Input 2 :
// 4
// 754 312 505 44
// Output 2 :
// 754 505 312 44 