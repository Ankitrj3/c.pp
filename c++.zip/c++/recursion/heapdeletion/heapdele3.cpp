// Single File Programming Question

// Problem Statement




// Vijay is fascinated by data structures and algorithms, particularly heap data structures. He wants to experiment with a program that implements a max heap and performs heap operations. He wishes to understand how deleting the root element from a max heap works.




// Write a program that defines a max heap and implements the deletion of the root element. The program should receive an array representing the max heap, its size, and delete the root element. After deletion, the program should print the updated array.

// Input format :

// The first line of input contains an integer 'n', the size of the array representing the max heap.

// The second line contains 'n' space-separated integers, representing the elements of the max heap.

// Output format :

// The output prints the updated max heap after deleting the root element, separated by a space.

// Code constraints :

// The test cases will under the following constraints:

// 1 ≤ n ≤ 10

// The input array can have duplicate elements.

// Sample test cases :
// Input 1 :
// 5
// 23 25 2 12 52
// Output 1 :
// 25 23 2 12 
// Input 2 :
// 5
// 10 5 3 2 4
// Output 2 :
// 5 4 3 2 
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

// You are using GCC
#include <iostream>
using namespace std;

#define MAX_SIZE 100

void heapify(int arr[], int n, int i)
{
    //Type your code
    int largest = i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    if(left<n && arr[left]>arr[largest]){
        largest = left;
    }
    if(right<n && arr[right]>arr[largest]){
        largest = right;
    }
    if(largest!=i){
        swap(arr[i],arr[largest]);
        heapify(arr,n,largest);
    }
}

void buildMaxHeap(int arr[], int n)
{
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);
}

void deleteRoot(int arr[], int &n)
{
    //Type your code
    swap(arr[0],arr[n-1]);
    n--;
    heapify(arr,n,0);
}

void printArray(int arr[], int n)
{
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
}

int main()
{
    int n;
    cin >> n;

    int arr[MAX_SIZE];

    for (int i = 0; i < n; ++i)
        cin >> arr[i];

    buildMaxHeap(arr, n);
    deleteRoot(arr, n);
    printArray(arr, n);

    return 0;
}
