// Single File Programming Question

// Problem Statement




// Sandeep Singh is working on a project that requires sorting a list of strings. He has chosen to use the Heap Sort algorithm to accomplish this task.




// Write a program to help Sandeep with his task. Sandeep has provided you with a partially implemented code, and you need to complete it.

// Input format :

// The first line of input consists of an integer N, representing the number of strings to be sorted.

// The second line consists of N space-separated strings, where each string is made up of lowercase and uppercase alphabetical characters. These are the strings that need to be sorted.

// Output format :

// The output displays the sorted list of strings in lexicographic order, separated by a space.

// Code constraints :

// The test cases will fall under the following constraints:

// 1 ≤ N ≤ 15

// The length of each word is at most 100 characters.

// The strings are case-sensitive.

// Sample test cases :
// Input 1 :
// 3
// Cat Ball Apple
// Output 1 :
// Apple Ball Cat 
// Input 2 :
// 5
// Damon Stefan Elena Bonnie Enzo
// Output 2 :
// Bonnie Damon Elena Enzo Stefan 
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.
// You are using GCC
#include <iostream>
#include <string>
using namespace std;

void heapify(string arr[], int n, int i) {
    //Type your code here
    int min = i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    if(left<n && arr[left]>arr[min]){
        min = left;
    }
    if(right<n && arr[right]>arr[min]){
        min = right;
    }
    if(min!=i){
        swap(arr[i],arr[min]);
        heapify(arr,n,min);
    }
    
}

void buildheap(string arr[],int n){
    for(int i=n/2-1; i>=0; i--){
        heapify(arr,n,i);
    }
}

void heapSort(string arr[], int n) {
    //Type your code here
    buildheap(arr,n);
    for(int i=n-1;i>=0;i--){
        swap(arr[0],arr[i]);
        heapify(arr,i,0);
    }
    
}

int main() {
    int size;
    cin >> size;

    string arr[size];
    for (int i = 0; i < size; i++)
        cin >> arr[i];

    heapSort(arr, size);

    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";

    return 0;
}