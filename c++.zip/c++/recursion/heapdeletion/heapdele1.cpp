// Single File Programming Question

// Problem Statement




// ﻿Priya has a garden with different types of flowers, and they are arranged in a max heap based on their height, with the tallest flower at the top. Write a program that helps Priya delete the tallest flower from the garden for pruning and display the remaining heights of the flowers in the garden.

// Input format :

// The first consists of an integer n representing the number of flowers in the garden.

// The second line consists of n space-separated integers representing the heights of each flower.

// Output format :

// After pruning the tallest flower, the program displays the heights of the remaining flowers separated by spaces.

// Code constraints :

// In this scenario, the test cases fall under the following constraints:

// 1 ≤ n ≤ 100

// 1 ≤ Heights ≤ 100

// Sample test cases :
// Input 1 :
// 7
// 90 85 70 60 75 80 95
// Output 1 :
// 90 85 80 60 75 70 

// Input 2 :
// 5
// 80 65 75 90 70
// Output 2 :
// 80 70 75 65 

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

#include<iostream>
using namespace std;

void heapify(int arr[],int n,int i){
    int lar = i;
    int left =2*i+1;
    int right =2*i+2;
    
    if(left<n && arr[left]>arr[lar]){
        lar = left;
    }
    if(right<n && arr[right]>arr[lar]){
        lar = right;
    }
    if(lar!=i){
        swap(arr[i],arr[lar]);
        heapify(arr,n,lar);
    }
}
void bheap(int arr[],int n){
    for(int i=n/2-1;i>=0;i--){
        heapify(arr,n,i);
    }
}

void dele(int arr[], int &n){
    swap(arr[0],arr[n-1]);
    n--;
    heapify(arr,n,0);
}
int main(){
    int n;
    cin>>n;
    
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    bheap(arr,n);
    dele(arr,n);
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    
    return 0;
}