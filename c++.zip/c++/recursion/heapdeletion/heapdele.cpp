// Single File Programming Question

// Problem Statement




// Laxmi is working with a set of integers and wants to filter out even numbers from her data. She's interested in creating a program that can build a max-heap from an array of integers and then efficiently remove all even elements from the heap. Can you help Laxmi by designing a program that accomplishes this task?




// Your task is to create a program that reads an array of integers, builds a max-heap from it, and then deletes all even elements from the max-heap, and display the resulting max-heap.

// Input format :

// The first line of input consists of an integer n, the number of elements in the array.

// The second line of input consists of n elements separated by spaces.

// Output format :

// The output displays the resulting max-heap after deleting all even elements.




// Refer to the sample output for formatting specifications.

// Code constraints :

// The test cases will fall under the following constraints:

// 1 <= n <= 10

// 1 <= elements <= 100

// Sample test cases :
// Input 1 :
// 8
// 50 40 30 45 35 25 15 5
// Output 1 :
// 45 35 25 5 15 
// Input 2 :
// 5
// 10 20 37 40 50
// Output 2 :
// 37 
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.


// You are using GCC
#include <iostream>
using namespace std;
void heapify(int arr[], int n, int i) 
{
    //Type your code
    int lar = i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    if(left<n && arr[left]>arr[lar]){
        lar = left;
    }
    if(right<n && arr[right]>arr[lar]){
        lar = right;
    }
    if(lar!=i){
        swap(arr[i],arr[lar]);
        heapify(arr,n,lar);
    }
}

void buildMaxHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }
}
void deleteEvenElements(int arr[], int& n) 
{
    //Type your code
    int i=0;
    while(i<n){
        if(arr[i]%2==0){
            swap(arr[i],arr[n-1]);
            n--;
            heapify(arr,n,i);
        }
        else{
            i++;
        }
    }
}

void displayHeap(int arr[], int n) {
    
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
}

int main() {
    int n;
    cin >> n;

    int arr[n];

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    buildMaxHeap(arr, n);

    deleteEvenElements(arr, n);

    displayHeap(arr, n);

    return 0;
}