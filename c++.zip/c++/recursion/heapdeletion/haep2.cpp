// Single File Programming Question

// Problem Statement




// Imagine you are building a software application for a prestigious school. The school conducts regular exams, and you need to develop a system to efficiently manage the scores of students in each subject.




// Your task is to create a program to manage student scores using Max Heap. Each student has a unique ID, and for each subject, you need to maintain a Max Heap of their scores. You should implement functions to add scores, remove the highest score, and display the remaining scores for a specific subject while maintaining the Max Heap order.

// Input format :

// The first line contains an integer n, which represents the number of student marks to be entered.

// The second line contains n space-separated integers, representing the unique scores of each student.

// Output format :

// The output displays a single line containing the scores of each student in the final max heap order after deleting the maximum score.




// Refer to the sample output for the exact format.

// Code constraints :

// the test cases will fall under the following constraints:

// 1 ≤ n ≤ 15

// 1 ≤ score ≤ 100

// Sample test cases :
// Input 1 :
// 5
// 12 76 17 34 72
// Output 1 :
// 72 34 17 12 
// Input 2 :
// 8
// 83 78 53 59 51 59 54 30
// Output 2 :
// 78 59 59 30 51 53 54 
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

// You are using GCC
#include <iostream>
using namespace std;

void heapify(int arr[], int n, int i)
{
    //Type your code
    int lar = i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    if(left<n && arr[left]>arr[lar]){
        lar = left;
    }
    if(right<n && arr[right]>arr[lar]){
        lar = right;
    }
    if(lar!=i){
        swap(arr[i],arr[lar]);
        heapify(arr,n,lar);
    }
}

void buildMaxHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }
}

void deleteMax(int arr[], int& n) 
{
    //Type your code
    swap(arr[0],arr[n-1]);
    n--;
    heapify(arr,n,0);
}

void displayHeap(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
}

int main() {
    int n;
    cin >> n;
    int arr[n];

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    buildMaxHeap(arr, n);

    deleteMax(arr, n);

    displayHeap(arr, n);

    return 0;
}
