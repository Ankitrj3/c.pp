// Single File Programming Question

// Problem Statement




// Mythili is currently studying different sorting algorithms in her computer science class. She recently learned about Heap Sort, a popular sorting technique that leverages the properties of max and min heaps. Mythili decided to implement both Max Heap Sort and Min Heap Sort to compare their performance.




// She wants write a program that takes an array of integers as input and provides two sorting options:




// Max Heap Sort: It sorts the array in descending order using a max heap.
// Min Heap Sort: It sorts the array in ascending order using a min heap.
// Input format :

// The first line contains an integer, 'n', representing the size of the array.

// The second line contains 'n' space-separated integers, 'arr[i]', representing the elements of the array.

// The third line contains an integer, 'choice' (1 or 2), representing the user's choice of sorting:

// 1: Perform max-heap sort.

// 2: Perform min-heap sort.

// Output format :

// The output displays the following format:




// If 'choice' is 1, print the sorted array in ascending order after applying max-heap sort.

// If 'choice' is 2, print the sorted array in descending order after applying min-heap sort.

// If 'choice' is not 1 or 2, print "Invalid choice."




// Refer to the sample output for the formatting specifications.

// Code constraints :

// The test cases will fall under the following constriants:

// 1 <= n <= 10

// 1 <= arr[i] <= 100

// Sample test cases :
// Input 1 :
// 5
// 35 89 100 45 91
// 1
// Output 1 :
// 35 45 89 91 100 
// Input 2 :
// 5
// 35 89 100 45 91
// 2
// Output 2 :
// 100 91 89 45 35 
// Input 3 :
// 5
// 35 89 100 45 91
// 3
// Output 3 :
// Invalid choice
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

// You are using GCC
#include <iostream>
using namespace std;
void MaxHeapify(int arr[], int N, int i)
{
    //Type your code
    int largest = i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    if(left<N && arr[left]>arr[largest]){
        largest = left;
    }
    if(right<N && arr[right]>arr[largest]){
        largest = right;
    }
    if(largest!=i){
        swap(arr[i],arr[largest]);
        MaxHeapify(arr,N,largest);
    }
}
void buildheap(int arr[], int N)
{
    //Type your code
    for(int i=N/2-1; i>=0; i--){
        MaxHeapify(arr,N,i);
    }
}
void maxheapsort(int arr[],int N){
    buildheap(arr,N);
    for(int i=N-1; i>0; i--){
        swap(arr[0],arr[i]);
        MaxHeapify(arr,i,0);
    }
    
}
void MinHeapify(int arr[], int n, int i)
{
    //Type your code
    int min = i;
    int left = 2*i+1;
    int right = 2*i+2;
    
    if(left<n && arr[left]<arr[min]){
        min = left;
    }
    if(right<n && arr[right]<arr[min]){
        min = right;
    }
    if(min!=i){
        swap(arr[i],arr[min]);
        MinHeapify(arr,n,min);
    }
}
void bulidminheap(int arr[],int n){
    for(int i=n/2-1;i>=0;i--){
        MinHeapify(arr,n,i);
    }
}
void minheapsort(int arr[],int n){
    bulidminheap(arr,n);
    for(int i=n-1;i>=0;i--){
        swap(arr[0],arr[i]);
        MinHeapify(arr,i,0);
    }
}
void printHeapArray(int arr[], int n)
{
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
}

int main()
{
    int n, i;
    cin >> n;
    int arr[n];
    for (i = 0; i < n; i++) {
        cin >> arr[i];
    }
    int choice;
    cin >> choice;
    if (choice < 1 || choice > 2) {
        cout << "Invalid choice";
        return 0;
    }
    if (choice == 1) {
        maxheapsort(arr, n);
    }
    else if (choice == 2) {
        minheapsort(arr, n);
    }
    printHeapArray(arr, n);
    return 0;
}
