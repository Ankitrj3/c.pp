// Single File Programming Question

// Problem Statement




// Amirtha, a computer science student, is learning about heap data structures and wants to experiment with building a min-heap and deleting the minimum element from it. 




// She decides to write a program that allows her to create a min-heap from an array, build a min-heap from the given array, and delete the minimum element. Finally, it should display the resulting min-heap. Help her to design a program.

// Input format :

// The first line contains an integer, 'n', representing the size of the array.

// The second line contains 'n' space-separated integers, 'arr[i]', representing the elements of the array.

// Output format :

// The output displays the resulting min-heap after deleting the minimum element.




// Refer to the sample output for formatting specifications.

// Code constraints :

// The test cases will fall under the following constriants:

// 1 ≤ n ≤ 12

// 1 ≤ arr[i] ≤ 100

// Sample test cases :
// Input 1 :
// 5
// 12 54 90 21 60
// Output 1 :
// 21 54 90 60 
// Input 2 :
// 8
// 270 210 530 120 890 220 650 560
// Output 2 :
// 210 270 220 560 890 530 650 
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

// You are using GCC
#include <iostream>
using namespace std;

void heapify(int arr[], int n, int i)
{
    //Type your code
    int min = i;
    int left = 2*i+1;
    int right = 2*i+2;
    if(left<n && arr[left]<arr[min]){
        min = left;
    }
    if(right<n && arr[right]<arr[min]){
        min = right;
    }
    if(min!=i){
        swap(arr[i],arr[min]);
        heapify(arr,n,min);
    }
}

void buildMinHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }
}

void deleteMin(int arr[], int& n) 
{
    //Type your code
    swap(arr[0],arr[n-1]);
    n--;
    heapify(arr,n,0);
}

void displayHeap(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
}

int main() {
    int n;
    cin >> n;
    int arr[n];
    
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    
    buildMinHeap(arr, n);
    deleteMin(arr, n);
    displayHeap(arr, n);
    
    return 0;
}
