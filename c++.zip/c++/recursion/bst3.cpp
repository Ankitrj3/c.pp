// You are given a binary tree, and your task is to determine whether the tree contains any duplicate values or not.	

// Input format :
// The first line of input consists of an integer representing the value of the root node.

// For each node in the tree, there are two integers,

// Left child data: an integer representing the value of the left child node. Use -1 to indicate no left child.

// Right child data: an integer representing the value of the right child node. Use -1 to indicate no right child.

// Output format :
// Print "Yes" if the binary tree contains duplicate values.

// Else, print "No".

// Sample test cases :
// Input 1 :
// 1
// 2
// 3
// -1
// 2
// -1
// -1
// -1
// -1
// Output 1 :
// Yes
// Input 2 :
// 1
// 20
// 3
// -1
// 4
// -1
// -1
// -1
// -1
// Output 2 :
// No

// You are using GCC
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Define the structure for a binary tree node
struct Node {
    int data;
    struct Node *left, *right;
};

// Function to count the number of nodes in the binary tree
int nodeCount(struct Node *root) {
    if (root == NULL) {
        return 0;
    }
    return 1 + nodeCount(root->left) + nodeCount(root->right);
}

// Function to create a new binary tree node
struct Node *createNode(int data) {
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Function to build a binary tree 
struct Node *buildBinaryTree() {
    int data;
    scanf("%d", &data);

    if (data == -1) {
        return NULL;  // Return NULL for an empty node
    }

    struct Node *root = createNode(data);

    root->left = buildBinaryTree();
    root->right = buildBinaryTree();

    return root;
}

// Function to check if a binary tree has duplicate values
bool hasDuplicateValues(struct Node *root) {
    static int pre=-1;
    //Type your code here
    if(root==NULL){
        return true;
    }
    if(hasDuplicateValues(root->left)){
        return true;
    }
    if(hasDuplicateValues(root->right)){
        return true;
    }
    if(root->data==pre){
        return true;
    }
    else{
        return false;
    }
    
}

int main() {
    struct Node *root = NULL;

    root = buildBinaryTree();

    if (hasDuplicateValues(root)) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }

    return 0;
}