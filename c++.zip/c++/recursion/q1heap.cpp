// Single File Programming Question

// Problem Statement




// In a gaming tournament, players are awarded scores based on their performance. A gaming organizer wants to keep track of the players' scores efficiently using a max heap. The higher a player's score, the higher their priority in the heap.




// Write a program that helps the gaming organizer insert players scores into a max heap.

// Input format :

// The input consists of a series of space-separated integers, each representing the score of a player.

// Output format :

// The output displays the scores of the players in the max heap, ordered by their scores. The scores are separated by spaces.

// Code constraints :

// The maximum number of players that can be inserted is 100, as the max heap has a maximum capacity of 100.

// Sample test cases :
// Input 1 :
// 10 5 15 20 3
// Output 1 :
// 20 15 10 5 3 

// Input 2 :
// 25 12 18 7 14 21 9
// Output 2 :
// 25 14 21 7 12 18 9 

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.


#include <iostream>
#include <algorithm>
using namespace std;

void maxHeapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
        largest = left;

    if (right < n && arr[right] > arr[largest])
        largest = right;

    if (largest != i) {
        swap(arr[i], arr[largest]);
        maxHeapify(arr, n, largest);
    }
}

void buildMaxHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        maxHeapify(arr, n, i);
    }
}

int main() {
    int arr[100]; // Assuming the maximum number of players is 100
    int n = 0;    // Number of players

    while (cin >> arr[n]) {
        n++;
    }

    buildMaxHeap(arr, n);


for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
