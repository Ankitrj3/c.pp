// Imagine you are working on a coding competition platform where participants are required to solve various algorithmic problems. 



// One of the challenges involves checking whether a given array of integers represents a valid in-order traversal of a Binary Search Tree (BST). 



// Your task is to develop a program that can validate their solutions. Your program should take the input array and determine if it's a valid BST in order traversal.

// Input format :
// The first line of input consists of an integer N, representing the number of elements in the array.

// The second line consists of N space-separated integers, representing the elements of the array.

// Output format :
// Print "Yes" if the array represents an inorder traversal of a BST.

// Otherwise, print "No".

// Sample test cases :
// Input 1 :
// 5
// 2 4 6 8 9
// Output 1 :
// Yes
// Input 2 :
// 5
// 7 4 1 2 5
// Output 2 :
// No

// You are using GCC
#include <iostream>
#include <climits> 

// Function to check if an array represents an inorder traversal of a BST
bool isValidInorder(int arr[], int n, int low = INT_MIN, int high = INT_MAX, int index = 0) {
    if (index == n) {
        return true;
    }

    if (arr[index] <= low || arr[index] >= high) {
        return false;
    }

    return isValidInorder(arr, n, low, arr[index], index + 1) &&
           isValidInorder(arr, n, arr[index], high, index + 1);
}

int main() {
    int n;
    std::cin >> n;

    int arr[n];

    for (int i = 0; i < n; i++) {
        std::cin >> arr[i];
    }

    if (isValidInorder(arr, n)) {
        std::cout << "Yes" << std::endl;
    } else {
        std::cout << "No" << std::endl;
    }

    return 0;
}