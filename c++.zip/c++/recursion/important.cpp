
#include <iostream>
#include <iomanip>
class num{
    virtual void nm(){
        
    }
};
int main() {
    int decimalNumber;

    std::cin >> decimalNumber;

    std::cout << std::setbase(8) << decimalNumber << std::endl;

    return 0;
}
