
#include <iostream>
using namespace std;

void heapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest]) {
        largest = left;
    }
    if (right < n && arr[right] > arr[largest]) {
        largest = right;
    }
    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void buildheap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }
}

int main() {
    int arr[100];
    int n = 0;

    while (cin >> arr[n]) {
        n++;
    }
    buildheap(arr, n);

    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
}
```

With this correction, your code should work as expected, building a max-heap from the input array and then printing the elements.It appears there is a small typo in your code. In the following line:

```cpp
cout<<ai]<<" ";
```

You have a typo, it should be `arr[i]` instead of `ai`. Here's the corrected code:

```cpp
#include<iostream>
using namespace std;

void heapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest]) {
        largest = left;
    }
    if (right < n && arr[right] > arr[largest]) {
        largest = right;
    }
    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void buildheap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }
}

int main() {
    int arr[100];
    int n = 0;

    while (cin >> arr[n]) {
        n++;
    }
    buildheap(arr, n);
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
