// Single File Programming Question

// Problem Statement




// Raj is learning about Binary Search Trees (BSTs) in his computer science class. He's particularly interested in verifying whether a given tree is a Binary Search Tree (BST) or not.




// A Binary Search Tree (BST) is a node-based binary tree data structure that has the following properties:




// The left subtree of a node contains only nodes with keys less than the node’s key. 
// The right subtree of a node contains only nodes with keys greater than the node’s key.
// Both the left and right subtrees must also be binary search trees.
// Each node (item in the tree) has a distinct key.




// Your task is to write a program that will help Raj verify if a given tree is a BST.

// Input format :

// The first line of input consists of an integer N, the number of nodes in the binary search tree.

// The second line of input consists of N space-separated integers, the values of the nodes in the binary search tree.

// Output format :

// The output displays the following format:




// "The tree is a Binary Search Tree" if the given tree is a BST.
// "The tree is not a Binary Search Tree" if the given tree is not a BST.




// Refer to the sample output for the formatting specifications.

// Code constraints :

// The test cases will fall under the following constraints:




// 1 ≤ N ≤ 10

// 1 ≤ value of node ≤ 1000

// Sample test cases :
// Input 1 :
// 5
// 5 3 8 2 4

// Output 1 :
// The tree is a Binary Search Tree
// Input 2 :
// 5
// 9 5 7 5 2
// Output 2 :
// The tree is not a Binary Search Tree
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.


#include <iostream>
#include <climits>

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) : data(value), left(nullptr), right(nullptr) {}
};

Node* insert(Node* root, int value) {
    if (root == nullptr) {
        return new Node(value);
    }

    if (value < root->data) {
        root->left = insert(root->left, value);
    } else {
        root->right = insert(root->right, value);
    }

    return root;
}
bool isBSTUtil(Node* root, int min, int max) {
    if (root == nullptr) {
        return true;
    }

    if (root->data < min || root->data > max) {
        return false;
    }

    return isBSTUtil(root->left, min, root->data - 1) &&
           isBSTUtil(root->right, root->data + 1, max);
}

bool isBST(Node* root) {
    return isBSTUtil(root, INT_MIN, INT_MAX);
}


int main() {
    int N;
    std::cin >> N;

    int rootValue;
    std::cin >> rootValue;
    Node* root = new Node(rootValue);

    for (int i = 1; i < N; i++) {
        int value;
        std::cin >> value;
        root = insert(root, value);
    }

    if (isBST(root)) {
        std::cout << "The tree is a Binary Search Tree" << std::endl;
    } else {
        std::cout << "The tree is not a Binary Search Tree" << std::endl;
    }

    return 0;
}
