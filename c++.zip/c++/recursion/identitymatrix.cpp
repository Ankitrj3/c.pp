
#include <iostream>

class MatrixChecker {
    void readMatrix(){}
public:
    bool isIdentity(int** matrix, int rows, int cols) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if ((i == j && matrix[i][j] != 1) || (i != j && matrix[i][j] != 0)) {
                    return false;
                }
            }
        }
        return true;
    }

    bool isIdentity(double** matrix, int rows, int cols) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if ((i == j && matrix[i][j] != 1.0) || (i != j && matrix[i][j] != 0.0)) {
                    return false;
                }
            }
        }
        return true;
}
};

int main() {
    int rows, cols;
    std::cin >> rows >> cols;

    int** intMatrix = new int*[rows];
    for (int i = 0; i < rows; i++) {
        intMatrix[i] = new int[cols];
        for (int j = 0; j < cols; j++) {
            std::cin >> intMatrix[i][j];
        }
    }

    MatrixChecker checker;
    if (checker.isIdentity(intMatrix, rows, cols)) {
        std::cout << "Identity matrix" << std::endl;
    } else {
        std::cout << "Not an identity matrix" << std::endl;
    }

    for (int i = 0; i < rows; i++) {
        delete[] intMatrix[i];
    }
    delete[] intMatrix;

    return 0;
}
