// Imagine a scenario where you are developing a software system for a company that manages inventory for two different warehouses. Each warehouse's inventory is represented as a Binary Search Tree (BST) containing unique product IDs.



// Your task is to create a program that checks if the inventory in both warehouses is identical. The program should compare the two BSTs and determine whether they contain the same product IDs or not.

// Input format :
// The first line of input consists of the space-separated product IDs for the first warehouse's inventory, terminated by -1.

// The second line consists of the space-separated product IDs for the second warehouse's inventory, terminated by -1.

// Output format :
// If the inventories of both warehouses are identical, print "Both BSTs are identical"

// Otherwise, print "BSTs are not identical"

// Sample test cases :
// Input 1 :
// 5 3 8 2 4 -1
// 5 3 8 2 4 -1
// Output 1 :
// Both BSTs are identical
// Input 2 :
// 10 5 15 -1
// 10 5 20 -1
// Output 2 :
// BSTs are not identical

// You are using GCC
#include <iostream>
#include<bits/stdc++.h>
using namespace std;

// BST node
struct Node {
    int data;
    Node* left;
    Node* right;
};

// Utility function to create a new Node
Node* newNode(int data) {
    Node* node = new Node();
    node->data = data;
    node->left = nullptr;
    node->right = nullptr;
    return node;
}

// Function to insert a node into a BST
Node* insert(Node* root, int data) {
    if (root == nullptr)
        return newNode(data);

    if (data < root->data)
        root->left = insert(root->left, data);
    else if (data > root->data)
        root->right = insert(root->right, data);

    return root;
}

// Function to perform inorder traversal
void inorder(Node* root) {
    if (root == nullptr)
        return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Function to check if two BSTs are identical
bool isIdentical(Node* root1, Node* root2) {
    
    //Type your code here
    if(root1==NULL && root2==NULL){
        return true;
    }
    if(root1==NULL || root2==NULL){
        return false;
    }
    return (root1->data==root2->data)&&isIdentical(root1->left,root2->left)&&isIdentical(root1->right,root2->right);
    
}

int main() {
    Node* root1 = nullptr;
    Node* root2 = nullptr;
    int data;

    while (1) {
        cin >> data;
        if (data == -1)
            break;
        root1 = insert(root1, data);
    }

    while (1) {
        cin >> data;
        if (data == -1)
            break;
        root2 = insert(root2, data);
    }

    if (isIdentical(root1, root2))
        cout << "Both BSTs are identical" << endl;
    else
        cout << "BSTs are not identical" << endl;

    return 0;
}