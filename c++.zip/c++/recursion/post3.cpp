// Venugopal is studying data structures and wants to build a program that can create a binary tree from a list of integers and then perform a postorder traversal on the constructed tree.



// Create a Binary Tree: Venugopal can provide a list of integers to create a binary tree.
// Perform Postorder Traversal: Venugopal can perform a postorder traversal on the constructed binary tree.
// Input format :
// The first line contains an integer n, denoting the number of integers in the list.

// The second line contains 'n' space-separated integers representing the elements of the list.

// Output format :
// The output displays a single line containing space-separated integers representing the postorder traversal of the binary tree.



// Refer to the sample output for formatting specifications.

// Code constraints :
// 1 <= n <= 20

// 1 <= elements <= 1000

// Sample test cases :
// Input 1 :
// 5
// 1 3 4 5 2
// Output 1 :
// 5 2 3 4 1 
// Input 2 :
// 5
// 1 7 9 5 6
// Output 2 :
// 5 6 7 9 1 

