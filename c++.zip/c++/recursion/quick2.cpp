// Imagine you are a teacher preparing the final grades for your class. You have a list of your students' GPAs, and you want to see who performed the best in the class. You decide to use this program to quickly sort and display the GPAs in descending order to identify the top students based on their GPAs.



// Your task is to implement a recursive function using the Quick-Sort algorithm. The program should prompt the user for the number of students, input the GPA, and sort the same in descending order.

// Input format :
// The first line of input consists of an integer N, representing the number of students.

// The second line consists of N floating point numbers, representing the GPA of the students.

// Output format :
// The output prints the sorted GPAs in descending order, from the highest GPA to the lowest, rounded off to one decimal place.

// Code constraints :
// N > 0

// Sample test cases :
// Input 1 :
// 3
// 3.6 4.4 2.9 
// Output 1 :
// 4.4 3.6 2.9 
// Input 2 :
// 6
// 1.2 4.9 3.5 2.7 5.0 3.1
// Output 2 :
// 5.0 4.9 3.5 3.1 2.7 1.2 

// You are using GCC
#include <iostream>
#include <iomanip>

int partition(float arr[],int low, int high){
    float pivot = arr[high];
    int i = (low-1);
    for(int j=low; j<=high-1; j++){
        if(arr[j]>=pivot){
            i++;
            std::swap(arr[i],arr[j]);
        }
    }
    std::swap(arr[i+1],arr[high]);
    return (i+1);
}
void quickSort(float arr[], int low, int high) {
    
    //Type your code here
    if(low<high){
        int pivotindex = partition(arr,low,high);
        quickSort(arr,low,pivotindex-1);
        quickSort(arr,pivotindex+1,high);
    }
}

int main() {
    int numStudents;

    std::cin >> numStudents;

    float* gpa = new float[numStudents];

    for (int i = 0; i < numStudents; i++) {
        std::cin >> gpa[i];
    }

    quickSort(gpa, 0, numStudents - 1);

    for (int i = 0; i < numStudents; i++) {
        std::cout << std::fixed << std::setprecision(1) << gpa[i] << " ";
    }

    delete[] gpa; 

    return 0;
}