// Single File Programming Question

// Problem Statement




// A magician has placed the enchanted gemstones in an array, and your task is to convert the array into a min heap, which will help you identify the gemstone with the kth most potent magic.




// Given an array of elements and an element k, find the kth element after converting the array into a min-heap.




// Note: This question was asked in Cisco recruitment.

// Input format :

// The first line of input is an integer value, representing the number of elements in the array.

// The second line of the input consists of space-separated integer array values.

// The third line of the input is an integer value, k.

// Output format :

// The first line of the output prints the space-separated integer values in the min-heap.

// The second line of the output prints the kth element in the min-heap.

// If k>n, print "Invalid entry".




// Refer to the sample output for formatting specifications.

// Code constraints :

// size of array>0

// k<=size of array

// Sample test cases :
// Input 1 :
// 5
// 2 4 1 5 9
// 3
// Output 1 :
// Min heap is: 1 4 2 5 9 
// Kth element in min heap is 2
// Input 2 :
// 5
// 2 4 1 5 9
// 12
// Output 2 :
// Invalid entry

// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.

#include <iostream>
using namespace std;

void minHeapify(int arr[], int n, int i) {
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] < arr[smallest])
        smallest = left;

    if (right < n && arr[right] < arr[smallest])
        smallest = right;

    if (smallest != i) {
        swap(arr[i], arr[smallest]);
        minHeapify(arr, n, smallest);
    }
}

void buildMinHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        minHeapify(arr, n, i);
    }
}

int main() {
    int n, k;
    cin >> n;
    int arr[n];

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    cin >> k;

    if (k > n) {
        cout << "Invalid entry" << endl;
        return 0;
    }

    buildMinHeap(arr, n);

    cout << "Min heap is: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    cout << "Kth element in min heap is " << arr[k - 1] << endl;

    return 0;
}
