// You are working as a software developer at a language processing company. As part of the company's text processing system, you need to sort a collection of words in reverse lexicographical (dictionary) order using the Quick-Sort algorithm.



// Write a program that takes an array of words as input and uses the QuickSort algorithm to sort the words in reverse lexicographical order.

// Input format :
// The first line of input consists of an integer N, representing the number of strings.

// The second line consists of N strings, separated by space.

// Output format :
// The output displays the words sorted in reverse lexicographical order.

// Code constraints :
// N > 0

// Sample test cases :
// Input 1 :
// 2
// Cap Cat
// Output 1 :
// Cat Cap 
// Input 2 :
// 5
// Chair Door Mouse Keyboard Table
// Output 2 :
// Table Mouse Keyboard Door Chair 

// You are using GCC


// #include <iostream>
// #include <string>

// using namespace std;

int partition(string arr[], int low, int high) {
    string pivot = arr[high];
    int i = (low-1);//these are main logic
    for(int j=low;j<=high-1;j++){
        
        if(arr[j]>=pivot){
            i++;
            swap(arr[i],arr[j]);
        }
    }
    
    swap(arr[i+1],arr[high]);
    return (i+1);
    
}

void quickSort(string arr[], int low, int high) {
    if(low<high){
    int pivotindex= partition(arr,low,high);
    quickSort(arr,low,pivotindex-1);
    quickSort(arr,pivotindex+1,high);
}
}
// int main() {
//     int n;
//     cin >> n;

//     string *words = new string[n];
//     for (int i = 0; i < n; i++) {
//         cin >> words[i];
//     }

//     quickSort(words, 0, n - 1);
   
//     for (int i = 0; i < n; i++) {
//         cout << words[i] << " ";
//     }

//     delete[] words;
//     return 0;
// }