// You are given T test cases, each consisting of two integers, 'a' and 'b'. Your task is to calculate 'a' raised to the power of 'b' and output the result for each test case.



// You need to implement the exponentMod() function that efficiently calculates the modular exponentiation of 'a' raised to the power of 'b', using recursion and modular arithmetic.



// Note: This kind of question will be helpful in clearing Infosys recruitment.

// Input format :
// The first line of input consists of an integer T, representing the number of test cases.

// Each of the following T lines contains two space-separated integers a and b, where a is the base, and b is the exponent.



// Output format :
// For each test case, the output prints a single integer on a new line, representing the result of 'a' raised to the power of 'b'.

// Code constraints :
// 1 ≤ T ≤ 10

// 0 ≤ a ≤ 200

// 0 ≤ b ≤ 10

// Sample test cases :
// Input 1 :
// 2
// 15 5
// 100 5
// Output 1 :
// 759375
// 10000000000
// Input 2 :
// 1
// 7 5
// Output 2 :
// 16807


// You are using GCC
#include <iostream>
using namespace std;

long long power(long long a, long long b) {
    
    if(b==0){
        return 1;
    }
    else{
        return (a*power(a,b-1));
    }
}

int main() {
    int T;
    cin >> T;

    while (T--) {
        long long a, b;
        cin >> a >> b;

        long long result = power(a, b);
        cout << result << endl;
    }

    return 0;
}
