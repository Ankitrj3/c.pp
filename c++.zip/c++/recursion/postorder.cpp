// Vasu is developing a program to manage an online shopping cart. Each item in the cart is identified by a unique product ID, which is a positive integer.



// Your goal is to help him implement a program that reads product IDs as input until a sentinel value (-1) is entered, constructs a binary search tree with the product IDs, and then performs post-order traversal to display the items in the cart.

// Input format :
// The input consists of a series of positive integers representing the product IDs of items added to the shopping cart. The input ends when a negative integer (-1) is entered.

// Output format :
// The post-order traversal of the binary search tree displays the product IDs of items in the shopping cart.



// Refer to the sample output for the formatting specifications.

// Code constraints :
// 1 <= Product ID <= 100

// The input will be terminated by entering '-1'.

// Sample test cases :
// Input 1 :
// 6
// 3
// 1
// 4
// 2
// -1
// Output 1 :
// Post order Traversal:
// 2 1 4 3 6 
// Input 2 :
// 1
// 7
// 9
// 5
// 6
// -1
// Output 2 :
// Post order Traversal:
// 6 5 9 7 1 
// Input 3 :
// 100
// 20
// 200
// 10
// 30
// 150
// 300
// -1
// Output 3 :
// Post order Traversal:
// 10 30 20 150 300 200 100 

#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *left;
    struct node *right;
    
    node(int value){
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

void insert(node * &root, int value){
    if(root==nullptr){
        root = new node(value);
        return ;
    }
    if(value<root->data){
        insert(root->left,value);
    }else{
        insert(root->right,value);
    }
}
void postorder(node* &root){
    if(root!=nullptr){
        postorder(root->left);
        postorder(root->right);
        cout<<root->data<<" ";
    }
}
int main(){
    struct node * root = nullptr;
    int value;
    while(cin>>value){
        if(value==-1){
            break;
        }else{
            insert(root,value);
        }
        
    }
    cout<<"Post order Traversal: \n";
    postorder(root);
}