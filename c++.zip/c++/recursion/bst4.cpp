// You are tasked with developing a software module for a critical application that involves binary trees. Your objective is to create a program that determines whether a given binary tree adheres to the Binary Search Tree (BST) property.



// In a Binary Search Tree (BST):

// Each node in the tree has a unique integer value.
// For any given node,
// All nodes in its left subtree have values less than the node's value.
// All nodes in its right subtree have values greater than the node's value.


// Your task is to implement a program that can take as input a binary tree and determine whether it is a valid BST according to the rules mentioned above.

// Input format :
// The first line of input consists of the root node's value as an integer.

// For each non-null node, there will be two inputs: the value of the left child (if exists) or -1 if there is no left child, the value of the right child (if exists) or -1 if there is no right child.

// Output format :
// Print "The given binary tree is a BST" if the input binary tree satisfies the BST properties.

// Otherwise, print "The given binary tree is not a BST".

// Sample test cases :
// Input 1 :
// 2 1 -1 -1 3 -1 -1
// Output 1 :
// The given binary tree is a BST
// Input 2 :
// 5 2 1 0 -1 -1 -1 4 3 -1 -1 6 -1 -1 7 -1 -1
// Output 2 :
// The given binary tree is not a BST
// Note :
// The program will be evaluated only after the “Submit Code” is clicked.
// Extra spaces and new line characters in the program output will result in the failure of the test case.
// Marks : 10
// Negative Marks : 0

// You are using GCC
#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

   
    Node(int data) {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

/* Function to check if the given tree is a binary search tree */
int isBST(Node* node) {
    
    //Type your code here
    if(node == 0){
        return 1;
    }
    if(!node->left){
        return 0;
    }
    if(!node->right){
        return 0;
    }
    return isBST(node->right);
}

Node* buildTree() {
    int data;
    cin >> data;

    if (data == -1)
        return NULL;

    Node* root = new Node(data);

    root->left = buildTree();
    root->right = buildTree();

    return root;
}

int main() {
    Node* root = buildTree();

    if (isBST(root))
        cout << "The given binary tree is a BST" << endl;
    else
        cout << "The given binary tree is not a BST" << endl;

    return 0;
}