#include<iostream>
using namespace std;

void TOH(int n, char s, char a, char d,int &count ){
    if(n==1){
        cout<<"Move disk 1 from "<<s<<" to "<<d<<endl;
        count++;
        return ;
    }
    TOH(n-1,s,d,a,count);
    cout<<"Move disk "<<n<<" from "<<s<<" to "<<d<<endl;
    count++;
    TOH(n-1,a,s,d,count);
}

int main(){
    int n;
    cin>>n;
    
    int count = 0;
    TOH(n,'A','B','C',count);
    
    cout<<"Total number of times the disk is moved:"<<count<<endl;
    
    return 0;
}