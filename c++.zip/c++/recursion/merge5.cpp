// You are developing a leaderboard system for an online game. The scores of the players are stored in an array of integers. To display the leaderboard, you need to sort the scores in ascending order.



// Write code to implement a recursive merge sort algorithm for sorting the scores.



// Note: This kind of question will help in clearing Wipro recruitment.

// Input format :
// The first line of input consists of an integer n, representing the number of scores in the array.

// The second line of input consists of n space-separated integers, representing the scores of the players.

// Output format :
// The first line of output displays the initial array of scores before sorting.

// The second line of output displays the sorted array of scores after applying the merge sort algorithm.



// Refer to the sample output for the formatting specifications.

// Code constraints :
// 1 <= n <= 10

// 0 <= scores <= 100

// Sample test cases :
// Input 1 :
// 5
// 3 1 4 2 5
// Output 1 :
// 3 1 4 2 5 
// 1 2 3 4 5 
// Input 2 :
// 3
// 9 7 8
// Output 2 :
// 9 7 8 
// 7 8 9 