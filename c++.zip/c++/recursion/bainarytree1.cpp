#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *left;
    struct node *right;
    
    node(int value){
        data = value;
        left = NULL;
        right = NULL;
    }
};

void insert(node * &root , int value){
    if(root == NULL){
        root = new node(value);
        return;
    }
    
    if(value<root->data){
        insert(root->left,value);
    }else{
        insert(root->right,value);
    }
};

void traverse(node * &root){
    if(root!=NULL){
        cout<<root->data<<" ";
        traverse(root->left);
        traverse(root->right);
    }
}

int main(){
    struct node *root = NULL;
    int n,value;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>value;
        insert(root,value);
    }
    cout<<"the value after tarverse\n";
    traverse(root);
    
    return 0;
}