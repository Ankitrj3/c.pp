#include <iostream>
using namespace std;

void maxHeapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
        largest = left;

    if (right < n && arr[right] > arr[largest])
        largest = right;

    if (largest != i) {
        swap(arr[i], arr[largest]);
        maxHeapify(arr, n, largest);
    }
}

void buildMaxHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--)
        maxHeapify(arr, n, i);
}

void heapsort(int arr[], int n) {
    buildMaxHeap(arr, n);

    for (int i = n - 1; i > 0; i--) {
        swap(arr[0], arr[i]);  // Move the maximum element to the end of the array
        maxHeapify(arr, i, 0);  // Call heapify on the reduced heap
    }
}
void deleteMax(int arr[], int& n) {
    if (n <= 1) {
        n = 0; // The heap is empty or has only one element, so set its size to 0.
    } else {
        // Swap the root (maximum) with the last element.
        std::swap(arr[0], arr[n - 1]);
        // Reduce the size of the heap.
        n--;
        // Heapify the root to maintain the max-heap property.
        maxHeapify(arr, n, 0);
    }
}

int main() {
    int arr[] = {4, 10, 3, 5, 1};
    int n = sizeof(arr) / sizeof(arr[0]);

    cout << "Original array: ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";

    // Convert the array into a max-heap
    heapsort(arr, n);
    deleteMax(arr,n);
    cout << "\nMax heap: ";
    for (int i = n-1; i >=0; i--)
        cout << arr[i] << " ";

    return 0;
}
