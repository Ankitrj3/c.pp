#include <iostream>
using namespace std;

// Define the structure of a binary tree node
struct Node {
    struct Node* left;
    int data;
    struct Node* right;
};

// Function to create a new binary tree node with the given data
Node* newNode(int data) {
    Node* node = new Node();
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return (node);
}

// Function to perform a preorder traversal of the binary tree
void preorder(struct Node* temp) {
    if (temp != NULL) {
        cout << " " << temp->data;
        preorder(temp->left);
        preorder(temp->right);
    }
}

// Function to perform an inorder traversal of the binary tree
void inorder(struct Node* temp) {
    if (temp != NULL) {
        inorder(temp->left);
        cout << " " << temp->data;
        inorder(temp->right);
    }
}

// Function to perform a postorder traversal of the binary tree
void postorder(struct Node* temp) {
    if (temp != NULL) {
        postorder(temp->left);
        postorder(temp->right);
        cout << " " << temp->data;
    }
}

int main() {
    // Create a binary tree
    Node* root = newNode(1);
    root->left = newNode(2);
    root->right = newNode(3);
    root->left->left = newNode(4);

    cout << "Preorder\n";
    preorder(root);
    cout << endl;

    cout << "Inorder\n";
    inorder(root);
    cout << endl;

    cout << "Postorder\n";
    postorder(root);
    cout << endl;

    return 0;
}
