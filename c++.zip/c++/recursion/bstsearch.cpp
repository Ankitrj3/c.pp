#include <iostream>
using namespace std;

struct node {
    int data;
    struct node* left;
    struct node* right;

    node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

node* insert(node* &root, int value) {
    if (root == nullptr) {
        return new node(value);
    }
    if (value < root->data) {
        root->left = insert(root->left, value);
    } else {
        root->right = insert(root->right, value);
    }
    return root;
}

node* search(node* &root, int key) {
    if (root == nullptr) {
        return nullptr;
    }
    if (root->data == key) {
        return root;
    }
    if (root->data > key) {
        return search(root->left, key);
    } else {
        return search(root->right, key);
    }
}

void inorder(node* &root) {
    if (root != nullptr) {
        inorder(root->left);
        cout << root->data << " ";
        inorder(root->right);
    }
}

int main() {
    struct node* root = nullptr;
    int n;
    int value;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> value;
        root=insert(root, value);
    }
    inorder(root);
    int key;
    cout<<"enter the key which u want to search\n";
    cin>>key;

    if(search(root,key)==nullptr){
        cout<<"element not found\n";
    }else{
        cout<<"element found\n";
      
    }
    return 0;
}
