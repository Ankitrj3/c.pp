#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * left;
    struct node * right;
    
    node(int value){
        data=value;
        left=NULL;
        right=NULL;
    }
};

void insert(node* &root , int value){
    if(root==NULL){
        root = new node(value);
        return;
    }
    
    if(value<root->data){
        insert(root->left,value);
    }else{
        insert(root->right,value);
    }
};

void preorder(node* &root){
    if(!root==NULL){
        cout<<root->data<<" ";
        preorder(root->left);
        preorder(root->right);
    }
}
void inorder(node* &root){
    if(!root==NULL){
        inorder(root->left);
        cout<<root->data<<" ";
        inorder(root->right);
    }
}
void postorder(node* &root){
    if(!root==NULL){
        postorder(root->left);
        postorder(root->right);
        cout<<root->data<<" ";
    }
}

int main(){
    struct node *root = NULL;
    
    int n,value;
    cin>>n;
    
    for(int i=0; i<n; i++){
        cin>>value;
        insert(root,value);
    }
    cout<<"preorder\n";
    preorder(root);
    cout<<endl;
    
    cout<<"inorder\n";
    inorder(root);
    cout<<endl;
    
    cout<<"postorder\n";
    postorder(root);
    cout<<endl;
    
    
    
    return 0;
}