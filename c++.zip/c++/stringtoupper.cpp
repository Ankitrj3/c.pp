#include<bits/stdc++.h>
#include<string>
using namespace std;

int main(){
    int age;
    string name;
    string sex;
    cin>>age;
    cin>>name;
    
    cin>>sex;
    transform(name.begin(),name.end(),name.begin(),::toupper);
    transform(sex.begin(),sex.end(),sex.begin(),::toupper);
    
    cout<<age<<" "<<name<<" "<<sex;
}