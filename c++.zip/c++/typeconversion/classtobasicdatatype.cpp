// we use operator function 
#include<iostream>
using namespace std;

class fuc{
    int hrs;
    int min;
    public:
    fuc(int a, int b){
       hrs = a;
       min = b;
    }
    operator int(){
        return hrs*60+min;
    }
    void display(){
        cout<<hrs<<":"<<min;
    }
};

int main(){
    int t;
    fuc j(12,3);
    j.display();
    cout<<"\n";
    t=j;
    cout<<t;


    return 0;
}