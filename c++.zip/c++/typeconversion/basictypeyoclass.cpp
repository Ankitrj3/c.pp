#include<iostream>
using namespace std;

class time1{
    int hrs;
    int min;
    public:
    time1(int x){
        hrs=x/60;
        min=x%60;
    }
    void display(){
        cout<<hrs<<"hrs"<<" "<<min<<"min"<<endl;
    }
};

int  main(){
    int n;
    cin>>n;
    time1 ob = n;
    ob.display();

    return 0;
}