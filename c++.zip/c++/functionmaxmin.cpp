// You are using GCC
#include<iostream>
#include<iomanip>
using namespace std;
void calculations(int arr[], int n){
    double sum=0;
    for(int i=0; i<n; i++){
        sum+=arr[i];
    }
    
    double average = sum/n;
    
    cout<<"Average: "<<fixed<<setprecision(2)<<average<<endl;
    double minnum=arr[0];
    for(int k=0; k<n; k++){
        if(arr[k]<minnum){
            minnum=arr[k];
        }
    }
    cout<<"Minimum Value: "<<fixed<<setprecision(2)<<minnum;
    cout<<endl;
    
    double maxnum=arr[0];
    for(int i=0; i<n; i++){
        if(arr[i]>maxnum){
            maxnum=arr[i];
        }
    }
    cout<<"Maximum Value: "<<fixed<<setprecision(2)<<maxnum;
    cout<<endl;
    
}

int main(){
    int n;
    cin>>n;
    
    int arr[n];
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    calculations(arr,n);
    
    
    return 0;
}