#include<iostream>
#include<iomanip>
using namespace std;

int main(){
    int d,s,i;
    cout<<"enter the dead humans:"<<endl;
    cin>>d;
    cout<<"enter the injured humans:"<<endl;
    cin>>i;
    cout<<"enter the safe humans:"<<endl;
    cin>>s;

    cout<<"Dead:"<<""<<d<<endl;
    cout<<"Injured:"<<""<<i<<endl;
    cout<<"Safe:"<<""<<s<<endl;
    cout<<"Please help the people who are suffering!";

    return 0;
}