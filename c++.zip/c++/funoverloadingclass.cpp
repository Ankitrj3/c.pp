// You are using GCC
#include<iostream>
#include <iomanip>
using namespace std;

class volume{
    private:
          int num;
          int r,h;
          const double M_PI=3.14159265359;
    
    public:
          double Quantity(int r){
             return r*r*r;
          }
          double Quantity(int r, int h){
              return 0.33*M_PI*r*r*h;
          }
          double putdata(){
              cin>>num;
              double r;
              if(num==1){
                  cin>>r;
                  return Quantity(r);
                  
              }else{
                  cin>>r>>h;
                  return Quantity(r,h);
              }   
            
          }
};
int main(){
    
    volume v1;
    
    cout<<fixed<<setprecision(2)<<v1.putdata();

}