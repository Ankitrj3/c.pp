#include<iostream>
using namespace std;

struct node {
    int data;
    int priority;
    struct node* next;
};

struct node* head = NULL;

void enqueue() {
    struct node* newnode = new node();
    cout << "ENTER DATA: ";
    cin >> newnode->data;

    cout << "ENTER PRIORITY: ";
    cin >> newnode->priority;
    newnode->next = NULL;

    if (head == NULL || newnode->priority > head->priority) {
        newnode->next = head;
        head = newnode;
    } else {
        struct node* temp = head;
        while (temp->next != NULL && newnode->priority <= temp->next->priority) {
            temp = temp->next;
        }
        newnode->next = temp->next;
        temp->next = newnode;
    }
}

void display() {
    struct node* temp = head;
    while (temp != NULL) {
        cout << "Data: " << temp->data << " Priority: " << temp->priority << endl;
        temp = temp->next;
    }
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;
    
    for (int i = 0; i < n; i++) {
        enqueue();
    }
    
    cout << "Priority Queue Contents:" << endl;
    display();

    return 0;
}
