#include<iostream>
using namespace std;

struct node {
    int data;
    struct node *next;
};
struct node *head = NULL;
struct node *temp = NULL;

void enqueue(){
    struct node *newnode =  new node();
    cout<<"enter the data\n";
    cin>>newnode->data;
    newnode->next=NULL;
    if(head==NULL){
        head = temp = newnode;
    }else{
        temp->next=newnode;
        temp=newnode;
    }
}

void dequeue(){
    if(head == NULL){
        cout<<"queue is empty\n";
    }else{
    struct node * top = head;
    int element = head->data;
    head = head -> next;
    delete top;
    cout<<"dequeued element "<<element;
    }
}

void display(){
    struct node *current = head;
    while(current!=NULL){
        cout<<current->data<<" ";
        current=current->next;
    }
}


int main(){

    int n;
    while(cin>>n){
        
        switch(n){
            case 1:
            enqueue();
            break;

            case 2:
            dequeue();
            break;

            case 3:
            display();
            break;

            case 4:
            return 0;

            default :
            cout<<"invalid\n";
        }
    }
}