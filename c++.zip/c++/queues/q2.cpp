// You've been assigned the challenge of developing a queue data structure using a linked list.



// The program should allow users to interact with the queue by enqueuing positive integers and subsequently dequeuing and displaying elements.

// Input format :
// The input consists of a series of integers, one per line.

// Enter positive integers into the queue.

// Enter -1 to terminate input.

// Output format :
// The output prints the space-separated dequeued elements in the format:

// "Dequeued elements: <<value 1>> <<value 2>> <<value 3>> ......... <<value n>>



// Refer to the sample output for the exact text and format.

// Sample test cases :
// Input 1 :
// 1
// 2
// 3
// 4
// -1
// Output 1 :
// Dequeued elements: 1 2 3 4 
// Input 2 :
// 56
// 74
// 36
// 94
// 15
// 34
// -1
// Output 2 :
// Dequeued elements: 56 74 36 94 15 34 

#include<iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};
struct node *head = NULL;
struct node *temp = NULL;

void enqeue(int n){
     struct node *newnode = new node();
     newnode->data=n;
     
     if(head == NULL){
         head=newnode;
         temp=newnode;
         newnode->next=NULL;
     }else{
         temp->next=newnode;
         temp=newnode;
     }
}

void dequeue(){
    cout<<"Dequeued elements: ";
    struct node *temp1 = head;
    while(temp1!=NULL){
        cout<<temp1->data<<" ";
        temp1=temp1->next;
    }
}

int main(){
    int n;
    while(cin>>n){
        switch(n){
        case -1:
        dequeue();
        return 0;
        break;
        
        default:
        enqeue(n);
        }
    }
    
    
    return 0;
}