#include<iostream>


class Queue
{
    private:
        int *data;
        int firstIndex;
        int lastIndex;
        int size;
    
    public:
    
        Queue()
        {
            data = new int[5];
            firstIndex = -1;
            lastIndex = 0;
            size = 0;
        }
    
     
        
        bool isEmpty()
        {
            return size == 0;
        }
        
        void enqueue(int element)
        {
            if(lastIndex == 5)
            {
                std::cout << "Queue is full.\n";
                return;
            }
            
            data[lastIndex++] = element;
            std::cout << "Order ID " << element << " is inserted in the queue.\n";
            if(firstIndex == -1)
                firstIndex = 0;
            
            size++;
            
        }
        
        void dequeue()
        {
            if(isEmpty())
            {
                std::cout << "Queue is empty.\n";
                return;
            }
            
            std::cout << "Processed Order ID: " << data[firstIndex] << '\n';
            firstIndex++;
            size--;
        }
        
        
        void display()
        {
            if(isEmpty())
            {
                std::cout << "Queue is empty.\n";
            }
            else
                std::cout << "Order IDs in the queue are: " << data[firstIndex] << '\n';
        }
};



int main()
{
    Queue q;
    
    
    int userChoice; 
    while(std::cin >> userChoice)
    {
        if(userChoice == 1)
        {
            int val; std::cin >> val;
            q.enqueue(val);
        }
        else if(userChoice == 2)
        {
            q.dequeue();
        }
        else if(userChoice == 3)
        {
            q.display();
        }
        else
        {
            std::cout << "Invalid option.\n";
        }
    }
    
    
    return 0;
}