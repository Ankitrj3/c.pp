#include<iostream>

using namespace std;

struct node{
    int priority;
    struct node * next;
};
struct node * head = NULL;

void enqueue(){
    struct node *newnode = new node();
    cout<<"enter data \n";
    cin>>newnode->priority;
    
    if(head == NULL || newnode->priority > head->priority){
        newnode->next=head;
        head = newnode;
    }
    else{
        struct node *temp = head;
        while(temp->next!=NULL && newnode->priority <= temp->next->priority){
            temp=temp->next;
        }
        newnode->next = temp->next;
        temp->next = newnode;
    }
}

void traverse(){
    struct node *temp = head;
    while(temp!=NULL){
        cout<<temp->priority<<" ";
        temp=temp->next;
    }
}  
    int main()
    {
        int n;
        cin>>n;
        
        for(int i=0; i<n; i++){
            enqueue();
        }
        traverse();
        return 0;
    }
