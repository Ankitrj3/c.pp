// You are assigned to design and implement a program that simulates a customer queue system for a business. The program should allow users to enqueue customer IDs, dequeue customer IDs, and display the current customer queue.



// Implement the queue using linked lists to manage the customers in line at the counter.

// Input format :
// The input consists of integer values, each representing an action to be taken:

// Option 1: Enqueue a new customer with a given customer ID.

// If option 1 is chosen, then the next line of input is the customer ID, which is a positive integer.

// Option 2: Dequeue the customer at the front of the line.

// Option 3: Display the current customer IDs in the line.

// Any option other than 1, 2, or 3 will be considered invalid.

// Output format :
// The program provides appropriate outputs based on the choice:

// When enqueuing a customer (option 1), the program outputs the customer ID that is added to the line in the format:

// "Customer ID <<value>> is enqueued."



// When dequeuing a customer (option 2), the program outputs the customer ID that is dequeued in the format:

// "Dequeued customer ID: <<value>>"

// If a dequeue operation is attempted when the queue is empty, the program outputs "Queue is empty."



// When displaying the customer IDs (option 3), the program shows the customer IDs currently in the line in the format:

// "Customer IDs in the queue are: <<value 1>> <<value 2>> .... <<value n>>

// If display operation is attempted when the queue is empty, the program outputs "Queue is empty."



// If the user provides any option other than 1, 2, or 3 then the program outputs "Invalid option."



// Refer to the sample output for the exact text and format.

// Code constraints :
// Each customer is represented by a unique customer ID, which is a positive integer.

// Sample test cases :
// Input 1 :
// 1
// 3
// 1
// 5
// 1
// 9
// 2
// 3
// Output 1 :
// Customer ID 3 is enqueued.
// Customer ID 5 is enqueued.
// Customer ID 9 is enqueued.
// Dequeued customer ID: 3
// Customer IDs in the queue are: 5 9 
// Input 2 :
// 1
// 10
// 1
// 20
// 3
// 2
// 3
// Output 2 :
// Customer ID 10 is enqueued.
// Customer ID 20 is enqueued.
// Customer IDs in the queue are: 10 20 
// Dequeued customer ID: 10
// Customer IDs in the queue are: 20 
// Input 3 :
// 1
// 5
// 3
// 2
// 3
// 9
// Output 3 :
// Customer ID 5 is enqueued.
// Customer IDs in the queue are: 5 
// Dequeued customer ID: 5
// Queue is empty.
// Invalid option.
// Input 4 :
// 2
// Output 4 :
// Queue is empty.

