#include<iostream>
using namespace std;

#define N 6
int queue[N];
int front = -1;
int rear = -1;
int i=0;

void enqueue() {
    int x;
    
    if (rear == N - 1) {
        cout << "Queue is overflow." << endl;
    }
    cout<<"enter the data\n";
    cin>>x;
    rear++;
    queue[rear]=x;
    if(front == -1){
        front++;
    }
}

void dequeue() {
    if (front == -1 && front>rear) {
        cout << "Queue is underflow." << endl;
    }
    else {
        front = front + 1;
    }
}

void display() {
    if (front == -1 && front>rear) {
        cout << "Queue is empty." << endl;
    }
    else {
        for (int i = front; i <= rear; i++) {
            cout << queue[i] << " ";
        }
        cout << endl;
    }
}

void peek() {
    if (front == -1 && front>rear) {
        cout << "Queue is empty." << endl;
    }
    else {
        cout << "Front element: " << queue[front] << endl;
    }
}

void insertAtfront(){
    if(rear==N-1){
        cout<<"queue is overflow\n";
    }
    else{
        cout<<"enter data\n";
        int x;
        cin>>x;
        for( i=N; i>0; i--){
            queue[i]=queue[i+1];
        }
        queue[rear]=x;
    }
}

void deleteFromend(){
    if (front == -1 && front>rear) {
        cout << "Queue is empty." << endl;
    }else{
        rear--;
    }
}


int main() {
    int n;
    while (1) {
        cout << "Enter choice:\n";
        cout << "1. Enqueue\n";
        cout << "2. Dequeue\n";
        cout << "3. Display\n";
        cout << "4. Peek\n";
        cout << "0. Exit\n";
        cin >> n;

        switch (n) {
            case 0:
                return 0;
            case 1:
                enqueue();
                break;
            case 2:
                dequeue();
                break;
            case 3:
                display();
                break;
            case 4:
                peek();
                break;
            case 5:
                insertAtfront();
                break;
            case 6:
                deleteFromend();
                break;
            default:
                cout << "Invalid choice." << endl;
        }
    }

    return 0;
}
