#include<iostream>
using namespace std;

#define N 5

int queue[N];
int front = -1;
int back = -1;

void enqueue(){
    if(back == N-1){
        cout<<"Queue is full\n";
    }
    int x;
    cin>>x;
    cout<<"Order ID "<<x<<" is inserted in the queue.\n";
    back++;
    queue[back]=x;
    if(front == -1){
        front++;
    }
}

void dequeue(){
    if(front == -1 && front>back){
        cout<<"Queue is full\n";
    }else{
        cout<<"Processed Order ID: "<<queue[front];
        front++;
        
    }
}

void display(){
    cout<<"Order IDs in the queue are: ";
    for(int i=front; i<=back; i++){
        cout<<queue[i]<<" ";
        break;
    }
}

int main(){
    
    int choice ;
    while(1){
    cin>>choice;
        switch(choice){
            case 0:
            return 0;
            break;
            
            case 1:
            enqueue();
            break;
            
            case 2:
            dequeue();
            break;
            
            case 3:
            display();
            break;

            default:
            cout<<"Invaild option\n";
        }
    }
    return 0;
}