// You are assigned to develop a program that manages customer orders in a restaurant using a queue data structure. The restaurant can handle a limited number of orders at a time, and the orders will be stored in an array-based queue.



// Your task is to implement the Queue data structure and the associated functions, which will provide the necessary operations to manage the queue of customer orders using an array. 



// The main functionalities of the queue include:

// Enqueue: Adding a customer order to the end of the queue.
// Get Front: Retrieve the details of the first customer order in the queue.
// Get Rear: Retrieve the details of the last customer order in the queue.
// Input format :
// The first line of input consists of an integer N, which represents the capacity of the queue.

// The second line consists of N space-separated integers, representing the customer orders.

// Output format :
// The output displays the front and rear elements in the queue in the following format:

// "Front element: <<front_value>>"

// "Rear element: <<rear_value>>"



// Refer to the sample output for the exact text and format.

// Code constraints :
// The customer order values are positive integers.

// Sample test cases :
// Input 1 :
// 5
// 10 20 30 40 50
// Output 1 :
// Front element: 10
// Rear element: 50
// Input 2 :
// 3
// 5 8 2
// Output 2 :
// Front element: 5
// Rear element: 2

#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *next;
};
struct node *head;
struct node *tail;

void ihead(){
    struct node *newnode = new node();
    cin>>newnode->data;

    if(head == nullptr){
     head = tail = newnode;
}else{
    tail ->next = newnode;
    tail = newnode;
}
}

void display(){
    struct node *temp = head;
    cout<<"queue\n";
    while(temp!=nullptr){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}
void top(){
     struct node *temp = head;
     cout<<"top of element \n";
     cout<<temp->data<<endl;

     cout<<"rear of the element\n";
     while(temp->next!=nullptr){
        temp = temp->next;
     }
     cout<<temp->data;
}

int main(){
    int n;
    cin>>n;

    for(int i=0; i<n; i++){
        ihead();
    }
    display();
    top();
    return 0;
}