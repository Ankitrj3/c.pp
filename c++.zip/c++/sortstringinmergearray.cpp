// // You are using GCC
// #include<iostream>
// #include<algorithm>
// #include<string>
// using namespace std;

// int main(){
//     int a;
//     cin>>a;
//     string arr[a];
//     for(int i=0; i<a; i++){
//         cin>>arr[i];
//     }
//     int b;
//     cin>>b;
//     string arr1[b];
//     for(int i=0; i<b; i++){
//         cin>>arr1[i];
//     }
//     int s,s1;
//     s=a;
//     s1=b;
//     int s3=s+s1;
    
//     string arr2[s3];
    
//     for(int i=0; i<s; i++){
//         arr2[i]=arr[i];
//     }
//     for(int i=0; i<s1; i++){
//         arr2[s+i]=arr1[i];
//     }
    
//     sort(arr2,arr2+s3);
//     cout<<"Merged and sorted array: ";
//     for(int i=0; i<s3; i++){
//         cout<<arr2[i]<<" ";
//     }
    
//     return 0;
// }

// You are using GCC
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int a;
    cin >> a;
    int arr[a];
    for (int i = 0; i < a; i++) {
        cin >> arr[i];
    }

    int n;
    cin >> n;
    int arr1[n];
    for (int i = 0; i < n; i++) {
        cin >> arr1[i];
    }

    int s1 = a;
    int s2 = n;
    int s3 = s1 + s2;
    int arr2[s3];

    for (int i = 0; i < s1; i++) {
        arr2[i] = arr[i];
    }

    for (int i = 0; i < s2; i++) {
        arr2[s1 + i] = arr1[i];
    }

    sort(arr2, arr2 + s3);

    cout << arr2[0] << " ";
    for (int i = 1; i < s3; i++) {
        if (arr2[i] != arr2[i - 1]) {
            cout << arr2[i] << " ";
        }
    }

    return 0;
}
