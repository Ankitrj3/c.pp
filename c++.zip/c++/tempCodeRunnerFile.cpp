test :: showcount();
    // test t3;
    // t3.setcode();