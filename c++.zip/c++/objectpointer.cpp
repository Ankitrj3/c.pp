#include<bits/stdc++.h>
using namespace std;

class fuc{
    int a;

public:
     void getdata(){
         cin>>a;
     }
     
     void display(){
         cout<<a<<endl;
     }
};

int main(){
    fuc f;//object declaration
    fuc *p;//pointer declaration
    p = &f;//assigning the address of f object in pointer variable
    p->getdata();
    p->display();
    (*p).getdata();
    (*p).display();
    
}