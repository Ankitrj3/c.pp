#include<iostream>
using namespace std;

int sum(int x , int y){
    return x+y;
}
double sum(double x , double y){
    return x+y;
}
int sum(int x , int y, int z){
    return x+y+z;
}
void sum(char x, char y){
    cout<<x<<y;
}
double sum(double x , double y, double z){
    return x+y+z;
}
int main(){
    cout<<sum(10,20)<<endl;
    cout<<sum(2.5,6.3)<<endl;
    sum('A','B');

    return 0;
}