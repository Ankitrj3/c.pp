// resultAnalysis
// Result & Analysis
// of 02
// Student
// :
// Ankit Ranjan
// Email id
// :
// ankit.12000777@lpu.in
// Test
// :
// DSA_Unit 3_Lecture 18_RB_COD
// Course
// :
// CSE205_Data Structures and Algorithms Course
// stats-icon
// IP Address
// :
// 210.89.61.6
// stats-icon
// Tab Switches
// :
// --
// stats-icon
// OS Used
// :
// MacOS
// stats-icon
// Browser Used
// :
// Chrome
// stats-icon
// Test Duration
// :
// 00:09:58
// stats-icon
// Test Start Time
// :
// Sep 23, 2023 | 06:48 PM
// stats-icon
// Test Submit Time
// :
// Sep 23, 2023 | 06:58 PM
// Summary
// Sections
// filterIcon
// Filters
// 1
// Coding
// (4)
// Question No: 1
// reportIcon
// Single File Programming Question
// Problem Statement



// You are tasked with implementing a program to simulate multiple queues using linked lists. The program should allow enqueue and dequeue operations on the queues and display the contents of each queue. 



// The program should prompt the user for the number of queues (k) and the total number of customers (n). Then, for each customer, the program should prompt for the item and the queue number the customer wants to join. 



// After enqueuing all the customers, the program should print the contents of each queue in order, indicating the queue number and the items in each queue.

// Input format :
// The input begins with two integers k and n separated by a newline character.

// Then, n lines follow, each containing two integers: item and qn, separated by space.

// Output format :
// The output consists of k lines.

// Each line represents a queue and contains the elements in that queue after dequeuing, separated by space.



// Refer to the sample output for the exact text and format.

// Sample test cases :
// Input 1 :
// 2
// 5
// 1 0
// 2 1
// 3 0
// 4 1
// 5 0
// Output 1 :
// Queue 0: 1 3 5 
// Queue 1: 2 4 
// Input 2 :
// 3
// 8
// 10 2
// 20 1
// 30 0
// 40 2
// 50 1
// 60 0
// 70 2
// 80 0
// Output 2 :
// Queue 0: 30 60 80 
// Queue 1: 20 50 
// Queue 2: 10 40 70 
// Fill your code here
// C++ (17)
// theme
// instruction
 
// Recommended Learning Content :
// Lecture 17_DSA_Queue_Introduction
// Lecture 17_DSA_Queue_Using_Array
// Lecture 17_DSA_Queue_Using_LinkedList_Final
// Status
// Correct
// Mark obtained
// 10/10
// Hints used
// 0
// Times compiled
// 1
// Times submitted
// 1
// Level
// Easy
// Question type
// Single File Programming
// Subject
// Data Structure
// Topic
// Queue
// Sub Topic
// Queue
// Blooms taxonomy
// Apply
// Question No: 2
// reportIcon
// Single File Programming Question
// Problem Statement



// You are tasked with developing a simple inventory management system for a bookstore. The system should allow the bookstore staff to manage the inventory of books, prioritize restocking, and efficiently handle restocking operations.



// The program uses a priority queue to manage the inventory. Each book in the inventory is represented by its title, the current quantity available, and a restock priority. 



// The book is restocked using restock priority. The restock priority is a value between 1 and 5, a low value indicating a higher priority. In the order of priority, 1 has high priority, the level gets reduced as the priority value increases, and 5 has low priority.



// Include the following options:

// 1 - Add book to inventory

// 2 - Restock book

// 3 - View the next book to restock

// 4 - Exit

// Input format :
// The input consists of integers representing the choice from the menu.



// For choice 1 (Add book to inventory), the following lines of input consists of:

// Book title (string with spaces allowed)
// Current quantity (integer)
// Restock priority (integer between 1 and 5, inclusive)


// For choices 2 (Restock book) and 3 (View next book to restock), no additional input is required.



// For choice 4 (Exit), no additional input is required.

// Output format :
// For choice 1, the program prints: "Book added to the inventory."

// For choice 2, the program prints: "Restocked book: [Book Title]"

// For choice 3, the program prints after restocking the book: "Next book to restock: [Book Title]"

// For choice 4, the program prints: "Exiting the application."



// If the choices are not 1, 2, 3, or 4:

// For invalid choices, the program prints: "Invalid choice. Please enter a valid option."



// For choice 3:

// When there are no books in the inventory, the program prints: "No books in the inventory."

// Code constraints :
// 1 <= restock priority <= 5

// The book title can include spaces and should be non-empty.

// The choice entered by the user should be an integer corresponding to the available menu options.

// Sample test cases :
// Input 1 :
// 1
// Wings of Fire
// 5
// 4
// 1
// Harry Potter and the Sorcerer's Stone
// 7
// 2
// 2
// 3
// 4
// Output 1 :
// Book added to the inventory.
// Book added to the inventory.
// Restocked book: Harry Potter and the Sorcerer's Stone
// Next book to restock: Wings of Fire
// Exiting the application.
// Input 2 :
// 1
// The Great Mocking Bird
// 3
// 4
// 2
// 3
// 4
// Output 2 :
// Book added to the inventory.
// Restocked book: The Great Mocking Bird
// No books in the inventory.
// Exiting the application.
// Input 3 :
// 6
// 4
// Output 3 :
// Invalid choice. Please enter a valid option.
// Exiting the application.
// Input 4 :
// 2
// 4
// Output 4 :
// No books in the inventory.
// Exiting the application.
// Fill your code here
// C++ (17)
// theme
// instruction
 
// Recommended Learning Content :
// DSA_LECTURE 18
// Status
// Correct
// Mark obtained
// 10/10
// Hints used
// 0
// Times compiled
// 0
// Times submitted
// 1
// Level
// Medium
// Question type
// Single File Programming
// Subject
// Data Structure
// Topic
// Queue
// Sub Topic
// Priority Queue
// Blooms taxonomy
// Apply
// Question No: 3
// reportIcon
// Single File Programming Question
// Problem Statement



// You are given a series of integers, and your task is to process them using a Queue data structure. 



// Implement a program to perform the following operations:

// Initialize an empty queue.
// Read an integer N from the standard input. This integer represents the number of elements to be processed.
// Read N integers from the standard input and enqueue them into the queue one by one.
// Calculate the sum of all the elements in the queue.
// Output the sum to the standard output.
// Input format :
// The first line of input consists of an integer N, representing the number of elements in the queue.

// The second line consists of N space-separated integers, each representing an element of the queue.

// Output format :
// If the queue is empty, print "Queue is empty." on a new line.

// Otherwise, print the sum of the numbers in the queue.

// Code constraints :
// -102 ≤ element ≤ 102 (the value of an element in the queue)

// The maximum capacity of the queue is 100.

// Sample test cases :
// Input 1 :
// 5
// 1 2 3 4 5
// Output 1 :
// 15
// Input 2 :
// 3
// 10 -20 30
// Output 2 :
// 20
// Input 3 :
// 0
// Output 3 :
// Queue is empty.
// Fill your code here
// C (17)
// theme
// instruction
 
// Recommended Learning Content :
// Lecture 17_DSA_Queue_Introduction
// Lecture 17_DSA_Queue_Using_Array
// Lecture 17_DSA_Queue_Using_LinkedList_Final
// Status
// Correct
// Mark obtained
// 10/10
// Hints used
// 0
// Times compiled
// 1
// Times submitted
// 1
// Level
// Easy
// Question type
// Single File Programming
// Subject
// Data Structure
// Topic
// Queue
// Sub Topic
// Queue
// Blooms taxonomy
// Apply
// Question No: 4
// reportIcon
// Single File Programming Question
// Problem Statement



// Write a program to implement a priority queue using an array-based approach. 



// The priority queue should support the following operations:

// Enqueue: Insert an element into the priority queue with a specified priority.
// Dequeue: Remove the element with the highest priority from the priority queue.
// isEmpty: Check if the priority queue is empty.
// isFull: Check if the priority queue is full.
// printPriorityQueue: Print the elements of the priority queue in the order of their priorities.


// Note: This kind of question will be helpful in clearing Wipro recruitment.

// Input format :
// The first line of input consists of an integer N, representing the number of elements to be inserted into the priority queue.

// This is followed by N lines, each containing two space-separated integers: element and priority.

// The element represents the value to be inserted, and priority represents its priority. The priorities are non-negative integers.

// Output format :
// The first line of output prints the initial state of the priority queue after inserting all the elements, based on priority.

// The second line prints the state of the priority queue after performing the dequeue operation.



// Refer to the sample output for the exact text and format.

// Code constraints :
// The priority queue can store up to 100 elements (MAX_SIZE = 100).

// Each element value is an integer ranging from −102 to 102

// Each priority value is an integer ranging from 1 to 100.

// Sample test cases :
// Input 1 :
// 5
// 4 2
// 3 1
// 6 4
// 2 3
// 1 5
// Output 1 :
// Priority Queue: 3 4 2 6 1 
// Priority Queue: 4 2 6 1 
// Input 2 :
// 3
// 9 1
// 2 2
// 7 3
// Output 2 :
// Priority Queue: 9 2 7 
// Priority Queue: 2 7 
// Fill your code here
// C (17)
// theme
// instruction
 
// Recommended Learning Content :
// DSA_LECTURE 18
// Status
// Correct
// Mark obtained
// 10/10
// Hints used
// 0
// Times compiled
// 1
// Times submitted
// 1
// Level
// Medium
// Question type
// Single File Programming
// Subject
// Data Structure
// Topic
// Queue
// Sub Topic
// Priority Queue
// Blooms taxonomy
// Apply
