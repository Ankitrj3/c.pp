#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *next;
};
struct node *top=NULL;

void push(){
    struct node *newnode = new node();
    cout<<"enter data to push element\n";
    cin>>newnode->data;
    
        newnode->next=top;
        top=newnode;
    
}

void pop(){
    struct node *temp = top;
    if(top==NULL){
        cout<<"stack is empty";
    }else{
        int element = top->data;
        top=top->next;
        delete temp;
        cout<<"pop out "<<element;
    }
}

void display(){
    struct node *temp = top;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
    int n;
    
    while(cin>>n){
         switch(n){
            case 1:
            push();
            break;

            case 2:
            pop();
            break;

            case 3:
            display();
            break;

            case 4:
            return 0;

            default:
            cout<<"invalid";
         }
    }

    return 0;
}