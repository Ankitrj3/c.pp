#include<iostream>
using namespace std;

struct node {
    int data;
    struct node* next;
};

struct node* top = NULL;

void push() {
    struct node* newnode = new node();
    cout << "Enter the data to push onto the stack: ";
    cin >> newnode->data;
    newnode->next = top;
    top = newnode;
    cout << newnode->data << " is pushed onto the stack." << endl;
}

void pop() {
    if (top == NULL) {
        cout << "Stack is underflow." << endl;
    }
    else {
        struct node* temp = top;
        int element = top->data;
        top = top->next;
        delete temp;
        cout << element << " is popped from the stack." << endl;
    }
}

void display() {
    if (top == NULL) {
        cout << "Stack is empty." << endl;
    }
    else {
        struct node* temp = top;
        cout << "Stack: ";
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
}

void peek() {
    if (top == NULL) {
        cout << "Stack is empty." << endl;
    }
    else {
        cout << "Top element of the stack: " << top->data << endl;
    }
}

int main() {
    int choice;
    int n;

    cout << "Enter 1 to start and 0 to end the program: ";
    cin >> n;

    while (n == 1) {
        cout << "Enter 1 for push()" << endl;
        cout << "Enter 2 for pop" << endl;
        cout << "Enter 3 for display" << endl;
        cout << "Enter 4 for peek" << endl;
        cout << "Enter 0 to end the program" << endl;

        cin >> choice;

        switch (choice) {
        case 0:
             cout<<"your program is terminated\n";
            return 0;
        case 1:
            push();
            break;
        case 2:
            pop();
            break;
        case 3:
            display();
            break;
        case 4:
            peek();
            break;
        default:
        cout<<"invalid\n";
        }
    }

    return 0;
}
