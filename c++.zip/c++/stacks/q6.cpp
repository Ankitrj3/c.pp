// You are designing an event registration system for a conference. 



// As part of the system, you need to implement a Queue data structure using an array that stores only the even numbers representing the registration IDs of the participants. 



// The queue will be used to keep track of the order in which participants register for the event.

// Input format :
// The first line of input consists of an integer N, representing the number of participants to register.

// The following N lines consist of integers, representing the registration IDs of the participants.

// Output format :
// The output prints only the even number registration IDs of the participants in the order they registered, separated by space.

// For odd registration IDs, print "Invalid element <element> Only even numbers can be enqueued".

// Code constraints :
// 1 <= N <= 100

// Sample test cases :
// Input 1 :
// 6
// 2
// 4
// 6
// 8
// 10
// 12
// Output 1 :
// 2 4 6 8 10 12 
// Input 2 :
// 4
// 14
// 36
// 55
// 48
// Output 2 :
// Invalid element 55, only even numbers can be enqueued
// 14 36 48 


#include<iostream>
using namespace std;

struct node{
    int data;
    struct node *next;
};
struct node *head = NULL;
struct node *temp = NULL;

void enqueue(){
    struct node *newnode = new node();
    cin>>newnode->data;
    
    if(newnode->data%2==0){

    if(head==NULL){
        head = temp = newnode;
    }else{
        temp -> next = newnode;
        temp = newnode;
    }
    
}else{
    cout<<"Invalid element "<<newnode->data<<", only even numbers can be enqueued\n";
    return ;
}
}

void display(){
    temp = head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
    int n;
    
    cin>>n;
    
    for(int i=0; i<n; i++){
        enqueue();
    }
    display();    
    return 0;
}







