// Alice and Bob are working on a programming project where they need to reverse a given string using the Last-In-First-Out (LIFO) stack method. They want to create a program that accomplishes this task efficiently. They have asked for your help with this task.



// Write a program that takes a string as input, uses a LIFO (Last-In-First-Out) stack to reverse the characters in the string, and then prints the reversed string.



// Note: This is a sample question asked in a Capgemini recruitment.

// Input format :
// The input consists of a string s, representing the single line of text as input.

// Output format :
// The output prints the reversed string on a single line.

// Code constraints :
// 1 <= s <= 100

// Sample test cases :
// Input 1 :
// JNCAB
// Output 1 :
// BACNJ

// DEFG CVDF
// Output 2 :
// FDVC GFED
// Input 3 :
// Talk is cheap.
// Output 3 :
// .paehc si klaT

#include <iostream>
#include <cstring>

using namespace std;

const int MAX_SIZE = 100;

char stack[MAX_SIZE];
int top = -1;

void push(char data) {
    top++;
    stack[top] = data;
}

char pop() {
    char data = stack[top];
    top--;
    return data;
}

void reverse_string(char *str) {
    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        push(str[i]);
    }
    for (int i = 0; i < len; i++) {
        str[i] = pop();
    }
}

int main() {
    char text[MAX_SIZE];
    cin.getline(text, MAX_SIZE); // Read an entire line
    
    reverse_string(text);
    
    cout << text << endl;
    
    return 0;
}
