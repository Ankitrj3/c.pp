#include<iostream>
using namespace std;

#define n 20

char stack[n];
int top = -1;

void push(char x){
 
    if(top==n-1){
        cout<<"stack overflow\n";
    }else{
        top = top+1;
        stack[top]=x;
    }
}

void display(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        for(int i=top; i>=0; i--){
            cout<<stack[i]<<" ";
        }
    }
}

int main(){
    cout<<"enter the number of string you want to enter\n";
    int z;
    cin>>z;
    string x;
    cout<<"enter the string\n";
    for(int i=0; i<z; i++){
        cin>>x;
       for(char c : x){
           push(c);
       }
    }
    display();
    return 0;
}