#include<iostream>
using namespace std;
#define N 5 

int stack[N];
int top = -1;

void push(){
    int x;
    if(top==N-1){
       cout<<"STACK IS OVERFLOW\n";
    }else{
        cout<<"enter the data in stack\n";
        cin>>x;
        top=top+1;
        stack[top]=x;
    }

}
void pop(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        int element = stack[top];
        top = top - 1;
        cout<<element<<" is deleted\n ";
    }

}
void peek(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        cout<<stack[top];
    }cout<<endl;

}
void display(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        int i;
        for(i=top;i>=0;i--){
            cout<<stack[i]<<" ";
        }
    }
cout<<endl;
}

int main(){
     int n;
     cout<<"enter 1 to start program :\n";
     cin>>n;
     while(n){
        int choice;
        cout<<"1: PUSH\n";
        cout<<"2: POP\n";
        cout<<"3: DISPLAY\n";
        cout<<"4: PEEK\n";
        cout<<"0: END THE PROGRAM\n";
        cout<<"select choice from list:\n";
        cin>>choice;

        switch(choice){
            case 0:
            return 0;
            case 1:
            push();
            break;
            case 2:
            pop();
            break;
            case 3:
            display();
            break;
            case 4:
            peek();
            break;
            default:
            cout<<"INVAILD\n";
        }

     }
    
    return 0;
}