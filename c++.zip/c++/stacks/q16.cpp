// Michael is developing a stock market analysis tool that processes historical stock prices. As part of his task, he needs to find and display the minimum stock price using a double-ended queue (deque).



// Michael has a deque that stores a collection of stock prices. The deque is initially empty. Write a program that Michael can use to find and print the minimum stock price from the deque. 

// Input format :
// The input consists of the elements of the dequeue.

// The input is terminated by entering -1.

// Output format :
// The output prints the minimum element in the given queue.

// Sample test cases :
// Input 1 :
// 345
// 287
// 166
// 747
// -1
// Output 1 :
// 166
// Input 2 :
// 711
// 298
// -1
// output
// 298

