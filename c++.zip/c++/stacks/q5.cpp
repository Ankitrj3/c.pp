// Thiru is a software engineer who loves to work with data structures. Recently, he has been learning about stacks and wants to implement a stack that not only allows him to push and pop elements but also quickly find the maximum element in the stack.



// Write a program that simulates a stack with the following operations:



// Push: Insert an element into the stack.
// Pop: Remove the top element from the stack. If stack is empty, It prints "stack is empty".
// Get Maximum: Find and print the maximum element currently in the stack. If stack is empty, it displays "-1".
// Print Stack: Display all elements currently in the stack. If the stack is empty, it displays the "stack is empty".
// Exit: Terminate the program.
// Input format :
// The input consists of a single integer. Each integer corresponds to a choice in the menu for interacting with the stack. The choices are as follows:

// 1: Push an element onto the stack. The next input is the element to push, separated by a space.

// 2: Pop the top element from the stack.

// 3: Find and print the maximum element in the stack.

// 4: Print all elements currently in the stack.

// 5: Exit the program.

// Output format :
// The program performs various actions based on the user's choices and prints messages accordingly.

// If an element is pushed onto the stack, no specific message is printed.

// If an element is popped from the stack, no specific message is printed unless the stack is empty, in which case it prints "Stack is empty."

// If the maximum element in the stack is queried, it prints "Maximum element: <max_element>" where <max_element> is the maximum element in the stack. If the stack is empty when querying the maximum, it prints "Maximum element: -1".

// If the elements in the stack are printed, they are separated by spaces. If the stack is empty, it prints, "Stack is empty."

// If an invalid choice is made, it prints "Invalid choice."



// Refer to the sample output for the formatting specifications.

// Code constraints :
// max_n = 10

// 1 <= elements <= 100

// Sample test cases :
// Input 1 :
// 1 2
// 1 3
// 1 5
// 1 7
// 1 9
// 1 10
// 2 
// 3
// 4
// 5
// Output 1 :
// Maximum element: 9
// 2 3 5 7 9 
// 1 2
// 1 4
// 6
// 2
// 2
// 2
// 3
// 4
// 5
// Output 2 :
// Invalid choice
// Stack is empty
// Maximum element: -1
// Stack is empty
