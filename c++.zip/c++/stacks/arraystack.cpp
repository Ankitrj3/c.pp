#include<iostream>

using namespace std;

#define n 5

int arr[n];

int top = -1;

void push(){
    int x;
    if(top==n-1){
        cout<<"stack is overflow \n";
    }else{
        cout<<"enter data in stack\n";
        cin>>x;

        top = top+1;
        arr[top]=x;
        
    }
}

void pop(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        int element = arr[top];
        top = top - 1;
        cout<<element<<" element is deleted\n";
    }
}

void peek(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }
    else{
        cout<<arr[top]<<" the top of the array\n";
    }
}

void display(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        for(int i=top; i>=0; i--){
            cout<<arr[i]<<" ";
        }
    }
}

int main(){
    
    while(1){
    int k;
    cout<<"enter 1 to push the data and enter 0 to end the program\n";
    cout<<"enter 2 to pop the data\n";
    cout<<"enter 3 to peek the data\n";
    cout<<"enter 4 to display the data\n";
    cin>>k;
    switch(k){
         case 0:
         return 0;
         break;

         case 1:
         push();
         break;

         case 2:
         pop();
         break;

         case 3:
         peek();
         break;

         case 4:
         display();
         break;

    }  
    }
    return 0;
}