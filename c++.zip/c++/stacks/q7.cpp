// You are assigned to develop a program that manages customer orders in a restaurant using a queue data structure. The restaurant can handle a limited number of orders at a time, and the orders will be stored in an array-based queue.



// Your task is to implement the Queue data structure and the associated functions, which will provide the necessary operations to manage the queue of customer orders using an array. 



// The main functionalities of the queue include:

// Enqueue: Adding a customer order to the end of the queue.
// Get Front: Retrieve the details of the first customer order in the queue.
// Get Rear: Retrieve the details of the last customer order in the queue.
// Input format :
// The first line of input consists of an integer N, which represents the capacity of the queue.

// The second line consists of N space-separated integers, representing the customer orders.

// Output format :
// The output displays the front and rear elements in the queue in the following format:

// "Front element: <<front_value>>"
// "Rear element: <<rear_value>>"



// Refer to the sample output for the exact text and format.

// Code constraints :
// The customer order values are positive integers.

// Sample test cases :
// Input 1 :
// 5
// 10 20 30 40 50
// Output 1 :
// Front element: 10
// Rear element: 50
// Input 2 :
// 3
// 5 8 2
// Output 2 :
// Front element: 5
// Rear element: 2


#include<iostream>
#define N 20
using namespace std;

int front = -1;
int rear = -1;

int queue[N];

void enqueue(){
    int x;
    
    if(rear==N-1){
        cout<<"queue is empty\n";
    }
    cin>>x;
    rear++;
    queue[rear]=x;
    
    if(front == -1){
        front++;
    }
    
}

void display(){
    cout<<queue[front]<<" ";
    cout<<queue[rear]<<" ";
}

int main(){
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        enqueue();
    }
    display();
    
    
    
    return 0;
}

