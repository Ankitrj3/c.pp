// Bindu is working on a program to convert decimal numbers to binary representation using a stack data structure implemented with a linked list. She needs your help in designing and implementing this program.



// Your task is to design and implement the stack with the specified push and pop operations to support this conversion.

// Input format :
// The input consists of an integer d, representing the decimal number to be converted into binary.

// Output format :
// The output is a single line containing the binary representation of the input decimal number in the format "Binary representation: [binary]".



// Refer to the sample output for formatting specifications.

// Code constraints :
// The stack used for the conversion can have a maximum size of 32.

// 1 <= d <= 512

// Sample test cases :
// Input 1 :
// 10
// Output 1 :
// Binary representation: 1010
// Input 2 :
// 37
// Output 2 :
// Binary representation: 100101


#include <iostream>
#include <string>

using namespace std;

struct Stack {
    int stackArray[32];  // Maximum size of the stack (assuming 32-bit integers)
    int top;
};

void initialize(Stack* stack) {
    stack->top = -1;
}

void push(Stack* stack, int value) {
    if (stack->top < 31) {
        stack->stackArray[++(stack->top)] = value;
    }
}

int pop(Stack* stack) {
    if (stack->top >= 0) {
        return stack->stackArray[(stack->top)--];
    } else {
        return -1;
    }
}

string decimalToBinary(int decimal) {
    Stack stack;
    initialize(&stack);

    while (decimal > 0) {
        int remainder = decimal % 2;
        push(&stack, remainder);
        decimal /= 2;
    }

    string binary = "";
    while (stack.top >= 0) {
        int bit = pop(&stack);
        binary += to_string(bit);
    }

    return binary;
}

int main() {
    int decimal;
    cin >> decimal;

    string binary = decimalToBinary(decimal);
    cout << "Binary representation: " << binary << endl;

    return 0;
}
