// Single File Programming Question
// Problem Statement



// Bob is a software developer working on a project that involves processing data using a double-ended queue.  As part of his task, he needs to count the number of elements in the deque and display the result to the user.



// Write a program that Bob can use to count the number of elements in the deque and print the result.

// Input format :
// The input consists of the elements of the dequeue.

// The input is terminated by entering -1.

// Output format :
// The output prints the count of the elements in the deque.



// Refer to the sample output for the exact text and format.

// Sample test cases :
// Input 1 :
// 1
// 2
// 3
// 4
// -1
// Output 1 :
// Number of elements in the deque: 4
// Input 2 :
// 17
// 29
// 36
// -1
// Output 2 :
// Number of elements in the deque: 3

