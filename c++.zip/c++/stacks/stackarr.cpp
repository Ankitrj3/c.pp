#include<iostream>
#define N 20
using namespace std;

int stack[N];
int top = -1;

void push(){
    if(top==N-1){
    cout<<"stack is overflow\n";
    }else{
        int k;
        cout<<"enter the data\n";
        cin>>k;
        top = top+1;
        stack[top]=k;
    }
}

void pop(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        int element = stack[top];
        top= top-1;
        cout<<"element"<<" "<<element<<endl;
    }
}

void peek(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        cout<<stack[top]<<endl;
    }
}

void display(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        for(int i=top; i>=0; i--){
            cout<<stack[i]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    cout<<"enter 1 to start and enter 0 to end the program\n";
    int n;
    cin>>n;
    cout<<"1: push\n";
        cout<<"2: pop\n";
        cout<<"3: peek\n";
        cout<<"4: display\n";
        cout<<"5: Teminate the program\n";
    while(n==1){
        cout<<"choice the operation\n";
        int choice;
        cin>>choice;
       
        
        switch(choice){
            case 1: 
            push();
            cout<<endl;
            break;
            
            case 2: 
            pop();
            cout<<endl;
            break;
            
            case 3: 
            cout<<endl;
            peek();
            break;
            
            case 4: 
            display();
            cout<<endl;
            break;
            
            case 5: 
            cout<<"program has been terminated\n";
            return 0;
            
            default:
            cout<<"your entered number is invalid\n";
        }
    }
    
    return 0; 
}