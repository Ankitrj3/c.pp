// You are developing a food delivery platform that handles orders from two different regions. The system uses two queues implemented using linked lists to manage incoming orders from each region. 



// Your task is to implement a program that checks if the two queues have the same order sequence.

// Input format :
// The first line consists of an integer N1, representing the number of orders for the first queue.

// The second line consists of N1 space-separated integers, representing the order details for the first queue.

// The third line consists of an integer N2, representing the number of orders for the second queue.

// The fourth line consists of N2 space-separated integers, representing the order details for the second queue.

// Output format :
// The output prints whether the queues have the same elements or different elements.



// Refer to the sample output for the exact text and format.

// Code constraints :
// The order numbers are integers.

// The number of orders for each queue is non-negative.
// 3
// 1 2 3
// 3
// 1 2 3
// Output 1 :
// The queues have the same elements in the same order.
// Input 2 :
// 1
// 2 
// 4
// 8 3 9 6
// Output 2 :
// The queues do not have the same elements in the same order.

#include <iostream>
#include <queue>

using namespace std;

int main() {
    int N1, N2;
    cin >> N1;
    queue<int> queue1;
    for (int i = 0; i < N1; i++) {
        int order;
        cin >> order;
        queue1.push(order);
    }

    cin >> N2;
    queue<int> queue2;
    for (int i = 0; i < N2; i++) {
        int order;
        cin >> order;
        queue2.push(order);
    }

    if (queue1 == queue2) {
        cout << "The queues have the same elements in the same order." << endl;
    } else {
        cout << "The queues do not have the same elements in the same order." << endl;
    }

    return 0;
}
