#include<iostream>
using namespace std;
#define N 5


int stack[N];
int top = -1;

void push(){
    int x;
    if(top==N-1){
       cout<<"STACK IS OVERFLOW\n";
    }else{
        cout<<"enter the data in stack\n";
        cin>>x;
        top=top+1;
        stack[top]=x;
    }

}

void display(){
    if(top==-1){
        cout<<"stack is underflow\n";
    }else{
        int i;
        for(i=top;i>=0;i--){
            cout<<stack[i]<<" ";
        }
    }
cout<<endl;
}

int main(){
     int n;
     cout<<"enter 1 to start program :\n";
     cin>>n;
     while(n){
        int choice;
        cout<<"1: PUSH\n";
        
        cout<<"2: DISPLAY\n";

        cout<<"3: TERMINATE THE PROGRAM\n";
       
        cout<<"select choice from list:\n";
        cin>>choice;

        switch(choice){
            case 0:
            cout<<"your program is terminated\n";
            return 0;
            case 1:
            push();
            break;
            case 2:
            display();
            break;
            default:
            cout<<"invalid data\n";
            
            cout<<"INVAILD\n";
        }

     }
    
    return 0;
}
