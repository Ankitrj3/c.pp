// Nandha is learning about data structures and wants to implement a stack data structure using linked lists. He seeks your help in writing a program that can perform stack operations like push and pop as well as display the top element of the stack. Can you help him write this program?



// push (int data): Add an integer element to the top of the stack.
// pop(): Remove the top element from the stack.
// display(): Display all elements in the stack.
// The program should also display the top element of the stack or indicate if the stack is empty.



// Note: This is a sample question asked in TCS recruitment.

// Input format :
// The first line contains an integer n, representing the number of elements Nandha wants to push onto the stack.

// The next line contains n space-separated integers, each representing the elements to be pushed onto the stack.

// Output format :
// The output displays the following format:



// The first line of the output prints the stack elements.

// The next line prints the top element of the stack.

// The third line prints the result of the pop operation.

// The next line prints the top element of the stack after performing the pop operation.

// If the stack is empty after popping an element, display "Stack is empty."

// Refer to the sample output for the formatting specifications.

// Code constraints :
// max_size = 20

// 1 <= n <= 15

// 1 <= elements <= 1000

// Sample test cases :
// Input 1 :
// 5
// 12 89 45 32 65
// Output 1 :
// 65 32 45 89 12 
// Top element is 65
// 32 45 89 12 
// Top element is 32
// Input 2 :
// 0
// Output 2 :
// Stack is empty
// Input 3 :
// 1
// 90
// Output 3 :
// 90 
// Top element is 90
// Stack is empty

