// Kamali loves playing with stacks using linked lists, but she has a new challenge for herself. She wants to sort a stack of integers in ascending order using only the operations push and pop. Can you help her achieve this?



// Write a program that accepts a stack of integers and sorts them in ascending order using only the given operations. Kamali knows that the stack can have a maximum of 10 elements.



// Note: This is a sample question asked during Infosys recruitment.

// Input format :
// The first line contains an integer,n , representing the number of elements in the initial stack.

// The second line contains n space-separated integers, each denoting an element in the stack.

// Output format :
// The output displays the following format:



// If the input stack is empty (n = 0), print "Stack is empty."

// If the input stack is full (n > 10), print "Stack is full."

// Otherwise, print two lines:

// "Original stack: " followed by a space-separated list of integers representing the initial stack.

// "Sorted stack: " followed by a space-separated list of integers representing the sorted stack in ascending order.
// Refer to the sample output for the formatting specifications.

// Code constraints :
// 1 <= n <= 10

// 1 <= elements <= 100

// Sample test cases :
// Input 1 :
// 5
// 4 5 6 3 2
// Output 1 :
// Original stack: 4 5 6 3 2 
// Sorted stack: 2 3 4 5 6 
// Input 2 :
// 0
// Output 2 :
// Stack is empty
// Input 3 :
// 11
// 3 2 4 5 6 9 8 7 1 2 3 
// Output 3 :
// Stack is full

#include<iostream>
#include<algorithm>
using namespace std;

#define N 5

int stack[N];
int top = -1;

void push(){
    if(top==N-1){
        cout<<"stack is overflow\n";
    }else{
        int x;
        cin>>x;
        top = top+1;
        stack[top]=x;
    }
}
void display(){
    for(int i=top; i>=0; i--){
        cout<<stack[i]<<" ";
    }
}


int main(){
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        push();
    }
       if (n > 0) {
        sort(stack, stack + n); 
        cout << "Sorted stack: ";
        reverse(stack,stack+n);
        display();
    } 
    else {
        cout << "Stack is empty" << endl;
    }
    
    
    return 0;
}