#include<iostream>
#include<string>
#include<cctype>
using namespace std;

int haslower(string s);
int hasupper(string s);
int hasdigit(string s);
int hasSpecialchar(string s);
int main(){
    string s;
    getline(cin,s);
    // cout<<haslower(s)<<endl;
    // cout<<hasupper(s)<<endl;
    // cout<<hasdigit(s)<<endl;
    
    if(s.length()>=8 && hasupper(s) &&haslower(s) && hasdigit(s) &&hasSpecialchar(s)){
        cout<<"strong";
    }
    else if(s.length()>=6 && (hasupper(s)) || haslower(s) ){
        cout<<"medium";
    }
    else{
        cout<<"weak";
    }
    return 0;
}

int haslower(string s){
    for(int i=0; i<s.length(); i++){
        if(islower(s[i])) return 1;
    }
    return 0;
}

int hasupper(string s){
    for(int i=0; i<s.length(); i++){
        if(isupper(s[i])) return 1;
    }
    return 0;
}

int hasdigit(string s){
    for(int i=0; i<s.length(); i++){
        if(isdigit(s[i])) return 1;
    }
    return 0;
}

int hasSpecialchar(string s){
    for(int i=0; i<s.length(); i++){
        if(!islower(s[i]) && !isupper(s[i]) && !isdigit(s[i])){
            return 1;
        }
    }
    return 0;
}



