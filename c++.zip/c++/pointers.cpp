#include<iostream>
using namespace std;

int main() {
    int a = 34;
    int *ank;
    ank = &a;
    cout << "The value is " << a << endl;
    cout << "The address of 'a' is " << &a << endl;
    cout << "The address stored in 'ank' is " << ank << endl;
    cout << "The value pointed to by 'ank' is " << *ank << endl;
    
    cout << "The address of 'ank' is " << &ank;

    return 0;
}
