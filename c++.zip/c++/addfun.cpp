#include<iostream>
using namespace std;


int add(int a , int b){
    static int c = 20;
    int result = a + b + c;

    a += 20;
    b += 20;
    c += 20;
    return result;
}



int main(){
     
      std::cout << add(20, 20) << '\n';
      std::cout << add(20, 20) << '\n';
      std::cout << add(20, 20) << '\n';
      return 0;
}