#include<iostream>
#include<iomanip>
using namespace std;

int main(){
    cout<<left;
    cout<<setw(20)<<"Name"<<setw(20)<<"marks"<<endl;
    cout<<setw(20)<<"ankit"<<setw(20)<<"23"<<endl;
    cout<<setw(20)<<"shasi"<<setw(20)<<"56.34"<<endl;
    cout<<setw(20)<<"udit"<<setw(20)<<"34.3"<<endl;
    cout<<setw(20)<<"guddu"<<setw(20)<<"45.3"<<endl;



    int s=1000;

    cout<<oct<<s<<endl;
    cout<<hex<<s<<endl;
    cout<<dec<<s<<endl;
    return 0;


}